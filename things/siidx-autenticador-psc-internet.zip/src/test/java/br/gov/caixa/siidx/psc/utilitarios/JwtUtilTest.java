package br.gov.caixa.siidx.psc.utilitarios;

import br.gov.caixa.siidx.psc.dto.output.GovBrTokenRetornoDTO;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
//@DisplayNameGeneration(DisplayNameGenerator.ReplaceUnderscores.class)
@DisplayName("Operações com JWT")
class JwtUtilTest {
    SiidxTokenPscDTO tokenGerado;

    @BeforeEach
    void eDeveGerarUmToken() {
        String secret_token = "12345678901234567890123456789012";
        Map<String, Object> claims = new HashMap<>();
        claims.put("cpf", "30030030030");
        SiidxTokenPscDTO token = new SiidxTokenPscDTO();
        String tokenJwt = JwtUtil.jwtEncode("teste", claims,3600000, secret_token);
        token.setToken(tokenJwt);
        tokenGerado = token;
    }

    @Nested
    @DisplayName("Dado atributos a serem inseridos em um token JWT")
    public class dadoUmaMensagem {
        @Test
        @DisplayName("Codificar um token JWT a partir de atributos definidos")
        void eDeveGerarUmToken() {
            String secret_token = "12345678901234567890123456789012";
            Map<String, Object> claims = new HashMap<>();
            claims.put("cpf", "30030030030");
            SiidxTokenPscDTO token = new SiidxTokenPscDTO();
            String tokenJwt = JwtUtil.jwtEncode("teste", claims,3600000, secret_token);
            token.setToken(tokenJwt);
            tokenGerado = token;
            assertEquals(tokenJwt, token.getToken());
        }
    }

    @Nested
    @DisplayName("Dado um token JWT")
    public class dadoUmToken {

        @Test
        @DisplayName("Decodificar o Token JWT e verificar seu conteúdo")
        void eDeveRetornarUmToken() {
            String tokenJwt = JwtUtil.jwtDecode(tokenGerado.getToken());
            assertEquals("{\"sub\":\"teste\",\"cpf\":\"30030030030\"", tokenJwt.substring(0,34));
        }
    }

}