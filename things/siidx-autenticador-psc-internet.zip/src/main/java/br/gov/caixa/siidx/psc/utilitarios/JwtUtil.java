package br.gov.caixa.siidx.psc.utilitarios;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.interfaces.RSAPublicKey;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

import javax.crypto.SecretKey;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.ws.rs.WebApplicationException;

public class JwtUtil {
    public static String jwtDecode(String token) {
        String[] parts = token.split("\\.");
        String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
        return payload;
    }

    public static String jwtDecode(String token, String key) {
        String[] parts = token.split("\\.");
        String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
        return payload;
    }

    public static String jwtEncode(String subject, Map<String, Object> claims, long expirationMillis,
                                   String secretKey) {
        SecretKey key = getSigningKey(secretKey);
        return Jwts.builder()
                .setSubject(subject)
                .addClaims(claims)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationMillis))
                .signWith(key)
                .compact();
    }

    public static SecretKey getSigningKey(String secret) {
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public static boolean verify(String token, String url) throws Exception {
        // Endpoint JWKS do emissor do token
        URL jwksUrl = new URL(url);

        JWKSource<SecurityContext> keySource = new RemoteJWKSet<>(jwksUrl);
        ConfigurableJWTProcessor<SecurityContext> jwtProcessor = new DefaultJWTProcessor<>();

        JWSKeySelector<SecurityContext> keySelector = new JWSVerificationKeySelector<>(JWSAlgorithm.RS256, keySource);

        jwtProcessor.setJWSKeySelector(keySelector);

        // Processa e verifica o token
        SecurityContext ctx = null;
        JWTClaimsSet claimsSet = jwtProcessor.process(token, ctx);

        return true;
    }

    public static boolean validarToken(String token, String jwksUrl) throws Exception {
        // 1. Baixa o JWK Set do endpoint
        JWKSet jwkSet = JWKSet.load(new URL(jwksUrl));

        // 2. Extrai o JWT
        SignedJWT signedJWT = SignedJWT.parse(token);

        // 3. Obtém o 'kid' do token
        String kid = signedJWT.getHeader().getKeyID();

        // 4. Busca a chave correspondente no JWK Set
        JWK jwk = jwkSet.getKeyByKeyId(kid);
        if (jwk == null || !(jwk instanceof RSAKey)) {
            throw new WebApplicationException("Token não pode ser validado!", new Exception("Token não pode ser validado!"));
        }

        // 5. Converte para chave pública RSA
        RSAPublicKey publicKey = ((RSAKey) jwk).toRSAPublicKey();

        // 6. Verifica a assinatura
        JWSVerifier verifier = new RSASSAVerifier(publicKey);
        return signedJWT.verify(verifier);
    }

    public static boolean validarTokenComSecret(String token, String secret) {
        try {
            SecretKey key = getSigningKey(secret);

            // Faz o parse e validação do token
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody(); // Lança exceção se o token for inválido
            Date dtVenc = claims.getExpiration();
            return dtVenc.after(new Date());
            //return true; // Token válido
        } catch (Exception e) {
            // Token inválido ou assinatura incorreta
            return false;
        }
    }
}
