package br.gov.caixa.siidx.psc.dto.output;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GovBrNiveisConfiabilidadesDTO {
	private long id;
    private String dataAtualizacao;
	

	
}
