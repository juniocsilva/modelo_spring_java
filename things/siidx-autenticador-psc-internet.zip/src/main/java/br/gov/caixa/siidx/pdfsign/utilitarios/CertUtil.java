package br.gov.caixa.siidx.pdfsign.utilitarios;
import br.gov.caixa.siidx.pdfsign.dto.AssinanteDTO;
import org.bouncycastle.asn1.*;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class CertUtil {

    private CertUtil() {}

    // OIDs ICP-Brasil relevantes
    private static final String OID_PF   = "2.16.76.1.3.1"; // Pessoa Física (data + CPF + ... )
    private static final String OID_RESP = "2.16.76.1.3.4"; // Dados do responsável (em cert PJ; inclui CPF)
    private static final Pattern ONLY_DIGITS = Pattern.compile("\\d+");

    // ==== API pública (compatível com sua classe original) ====

    /** Retorna o CPF (11 dígitos) contido no certificado (PEM). */
    public static AssinanteDTO getAssinante(String certPem) throws Exception {
        X509Certificate certificado = convertPemToX509(certPem);
        Map<String, String> oids = getOID(certificado);

        String cpf = getCpf(oids);
        AssinanteDTO retorno = new AssinanteDTO();
        retorno.setCpf(cpf);
        retorno.setNome(certificado.getIssuerX500Principal().getName());
        return retorno;
    }

    /** Converte PEM (com cabeçalhos -----BEGIN/END CERTIFICATE-----) em X509Certificate. */
    public static X509Certificate convertPemToX509(String pemString) throws Exception {
        String cleanPem = pemString
                .replace("-----BEGIN CERTIFICATE-----", "")
                .replace("-----END CERTIFICATE-----", "")
                .replaceAll("\\s+", "");
        byte[] decoded = Base64.getDecoder().decode(cleanPem);
        CertificateFactory factory = CertificateFactory.getInstance("X.509");
        return (X509Certificate) factory.generateCertificate(new ByteArrayInputStream(decoded));
    }

    /**
     * Extrai pares OID->valor dos OtherName na SAN e (fallback) atributos no Subject.
     * Retorna um mapa possivelmente vazio (nunca null).
     */
    public static Map<String, String> getOID(X509Certificate cert) throws Exception {
        Map<String, String> valoresOids = new LinkedHashMap<>();

        // 1) SAN (Subject Alternative Name) via extensão X.509
        X509CertificateHolder holder = new JcaX509CertificateHolder(cert);
        Extension sanExt = holder.getExtension(Extension.subjectAlternativeName);
        if (sanExt != null) {
            GeneralNames gns = GeneralNames.getInstance(sanExt.getParsedValue());
            for (GeneralName gn : gns.getNames()) {
                if (gn.getTagNo() != GeneralName.otherName) continue;

                // otherName ::= SEQUENCE { type-id OBJECT IDENTIFIER, value [0] EXPLICIT ANY DEFINED BY type-id }
                ASN1Sequence seq = ASN1Sequence.getInstance(gn.getName());
                ASN1ObjectIdentifier typeId = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
                Pair<ASN1ObjectIdentifier, String> other = getOtherName(seq);
                if (other != null && other.second != null) {
                    valoresOids.putIfAbsent(other.first.getId(), other.second);
                }
            }
        }

        // 2) Fallback: alguns emissores replicam os OIDs também no Subject
        //    (não sobrescreve o que já veio da SAN).
        X500Name subject = new JcaX509CertificateHolder(cert).getSubject();
        // Se quiser capturar mais OIDs, adicione aqui.
        for (String oid : new String[]{OID_PF, OID_RESP}) {
            var rdnArr = subject.getRDNs(new ASN1ObjectIdentifier(oid));
            if (rdnArr != null) {
                for (var rdn : rdnArr) {
                    var atv = rdn.getFirst();
                    if (atv == null) continue;
                    String v = IETFUtils.valueToString(atv.getValue());
                    valoresOids.putIfAbsent(oid, v);
                }
            }
        }

        return valoresOids;
    }

    // ==== Implementação de parsing robusto ====

    /**
     * Decodifica um OtherName já como SEQUENCE { oid, [0] EXPLICIT any }.
     * Retorna Pair<OID, valorString>.
     */
    private static Pair<ASN1ObjectIdentifier, String> getOtherName(ASN1Sequence seq) throws IOException {
        ASN1ObjectIdentifier oid = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
        ASN1Encodable any = seq.getObjectAt(1);

        // [0] EXPLICIT ANY
        ASN1TaggedObject tagged = ASN1TaggedObject.getInstance(any);
        ASN1Encodable explicit;
        try {
            // BC 1.70+
            explicit = tagged.getExplicitBaseObject();
        } catch (NoSuchMethodError e) {
            // compat com versões anteriores do BC
            explicit = tagged.getObject();
        }

        String conteudo = decodeToString(explicit);
        return new Pair<>(oid, conteudo);
    }

    /** Converte um ASN1Encodable em String, lidando com UTF8/Printable/IA5 e OCTET STRING com DER aninhado. */
    private static String decodeToString(ASN1Encodable obj) throws IOException {
        if (obj instanceof ASN1String) {
            return ((ASN1String) obj).getString();
        }
        if (obj instanceof ASN1OctetString) {
            byte[] oct = ((ASN1OctetString) obj).getOctets();
            // Muitos certificados colocam um DER inteiro DENTRO do OCTET STRING
            try {
                ASN1Primitive inner = ASN1Primitive.fromByteArray(oct);
                if (inner instanceof ASN1String) {
                    return ((ASN1String) inner).getString();
                }
                if (inner instanceof ASN1OctetString) {
                    return new String(((ASN1OctetString) inner).getOctets(), StandardCharsets.UTF_8);
                }
                return inner.toString();
            } catch (IOException ex) {
                // Não era DER; assume UTF-8 "cru"
                return new String(oct, StandardCharsets.UTF_8);
            }
        }
        // Último recurso
        return obj.toString();
    }

    // ==== Extração do CPF (compatível com sua API original) ====

    /** Extrai o CPF dos OIDs 2.16.76.1.3.1 / 2.16.76.1.3.4 contidos no mapa. Retorna "" se não encontrar. */
    private static String getCpf(Map<String, String> oids) {
        if (oids == null || oids.isEmpty()) return "";
        for (Map.Entry<String, String> e : oids.entrySet()) {
            String k = e.getKey();
            if (OID_PF.equals(k) || OID_RESP.equals(k)) {
                String valor = e.getValue();
                String digits = onlyDigits(valor);
                // Leiaute ICP-Brasil: ddmmaaaa (8) + CPF (11) = 19 dígitos mínimos
                if (digits.length() >= 19) {
                    return digits.substring(8, 19);
                }
                // Fallback: se por algum motivo vier só o CPF
                Matcher m = Pattern.compile("(\\d{11})").matcher(digits);
                if (m.find()) return m.group(1);
            }
        }
        return "";
    }

    /** Mantida por compatibilidade: retorna substring(8,19) do valor (após normalizar dígitos). */
    private static String processa_2_16_76_1_3_1(String valor) {
        String digits = onlyDigits(valor);
        return digits.length() >= 19 ? digits.substring(8, 19) : "";
    }

    // ==== Utilitários ====

    private static String onlyDigits(String s) {
        if (s == null || s.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(s.length());
        Matcher m = ONLY_DIGITS.matcher(s);
        while (m.find()) sb.append(m.group());
        return sb.toString();
    }

    // Implementação simples de Pair para não depender de outras libs
    private static final class Pair<A, B> {
        final A first;
        final B second;
        Pair(A a, B b) { this.first = a; this.second = b; }
    }

    /** Converte Base64/PEM para DER binário quando necessário. */
    public static byte[] normalizePkcs7ToDer(byte[] maybeText) {
        String s = new String(maybeText).trim();
        boolean looksPem = s.startsWith("-----BEGIN") && s.contains("PKCS7");
        boolean looksB64 = s.matches("^[A-Za-z0-9+/=\\r\\n]+$");
        if (looksPem) {
            s = s.replaceAll("-----BEGIN[^-]+-----", "")
                    .replaceAll("-----END[^-]+-----", "")
                    .replaceAll("\\s+", "");
            return Base64.getDecoder().decode(s);
        } else if (looksB64) {
            try {
                return Base64.getDecoder().decode(s.replaceAll("\\s+", ""));
            } catch (IllegalArgumentException ignore) {}
        }
        return maybeText; // já era DER
    }

}
