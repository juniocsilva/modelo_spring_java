package br.gov.caixa.siidx.pdfsign.service.impl;

import br.gov.caixa.siidx.exceptions.DetalheException;
import br.gov.caixa.siidx.exceptions.enums.ErrosComunsEnum;
import br.gov.caixa.siidx.pdfsign.dto.AssinanteDTO;
import br.gov.caixa.siidx.pdfsign.dto.ItiHashParaAssinarDTO;
import br.gov.caixa.siidx.pdfsign.dto.ItiTokenRetornoDTO;
import br.gov.caixa.siidx.pdfsign.dto.SiidxTokenIti;
import br.gov.caixa.siidx.pdfsign.resources.restclient.AssinadorItiAssinatura;
import br.gov.caixa.siidx.pdfsign.resources.restclient.AssinadorItiCertificado;
import br.gov.caixa.siidx.pdfsign.resources.restclient.AssinadorItiToken;
import br.gov.caixa.siidx.pdfsign.service.AssinadorPdfGovBrService;
import br.gov.caixa.siidx.pdfsign.utilitarios.CertUtil;
import br.gov.caixa.siidx.pdfsign.utilitarios.PDFBoxUtil;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import br.gov.caixa.siidx.psc.utilitarios.JwtUtil;
import br.gov.caixa.siidx.psc.utilitarios.Util;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.ExternalSigningSupport;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.SignatureOptions;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Slf4j
@ApplicationScoped
public class AssinadorPdfGovBrServiceImpl implements AssinadorPdfGovBrService {
    @ConfigProperty(name = "iti.clientId")
    String clientId;

    @ConfigProperty(name = "iti.secret")
    String itiPass;

    @ConfigProperty(name = "iti.redirectUri")
    String redirectUri;

    @Inject
    @RestClient
    AssinadorItiToken assinadorItiToken;

    @Inject
    @RestClient
    AssinadorItiCertificado assinadorIticertificado;

    @Inject
    @RestClient
    AssinadorItiAssinatura assinadorItiAssinatura;

    @Inject
    ObjectMapper mapper;

    @ConfigProperty(name = "secret.token.siidx")
    String secret_token;

    @ConfigProperty(name = "secret.dados_token.siidx")
    String secret_dados_token;

    public byte [] assinar(MultipartFormDataInput inputForm) throws Exception {
        try {
            var map = inputForm.getFormDataMap();
            //RECUPERA OS DADOS DO FORM DA REQUISIÇÃO
            //=====================================================================================
            var arq = map.get("arquivo").get(0);
            var tokenMap = map.get("token").get(0);
            var signer = map.get("assinante").get(0);
            var page = map.get("pagina").get(0);
            var x = map.get("coordx").get(0);
            var y = map.get("coordy").get(0);
            var pagina = page.getBody(String.class, String.class);
            var coordX = x.getBody(String.class, String.class);
            var coordY = y.getBody(String.class, String.class);
            byte[] arquivoPdf = arq.getBody(byte[].class, byte[].class);
            var tokenSiidx = tokenMap.getBody(String.class, String.class);
            var assinante = signer.getBody(String.class, String.class);

            //FAZ A VERIFICAÇÃO DO TOKEN ENVIADO PELO FRONT
            //========================================================================================
            if (!JwtUtil.validarTokenComSecret(tokenSiidx, secret_token)) {
                throw new DetalheException(ErrosComunsEnum.ERRO_VALIDACAO_TOKEN);
            }
            //========================================================================================

            //=====================================================================================
            //DECODIFICA O TOKEN DO SIIDX ENVIADO PELO FRONT E DECRIPTOGRAFA O TOKEN DE ASSINATURA
            //DO ITI QUE ESTÁ INSERIDO NELE
            //=====================================================================================
            String payload = JwtUtil.jwtDecode(tokenSiidx);
            SiidxTokenIti tokenCriptografado = mapper.readValue(payload, SiidxTokenIti.class);
            var token = Util.decrypt(tokenCriptografado.getAccess_token(), secret_dados_token);
            //=====================================================================================
            //PAGINA - 1, PORQUE O PDDocument começa as páginas em zero.
            //=====================================================================================
            byte[] pdfAssinado = assinarPdf(arquivoPdf, assinante, token, Integer.parseInt(pagina) - 1, Float.parseFloat(coordX), Float.parseFloat(coordY));

            return pdfAssinado;
        } catch (Exception e) {
            throw new DetalheException(ErrosComunsEnum.ERRO_ASSINATURA_DIGITAL);
        }
    }

   public SiidxTokenPscDTO getTokenIti(String code) throws Exception{
        String retorno = acessarTokenIti(code);
        ItiTokenRetornoDTO resposta = mapper.readValue(retorno, ItiTokenRetornoDTO.class);
        try {

            String certtificado = acessarCertificadoUsuario("Bearer " + resposta.getAccess_token());
            AssinanteDTO assinante = CertUtil.getAssinante(certtificado);
            Map<String, Object> claims = new HashMap<>();
            claims.put("access_token", Util.encrypt(resposta.getAccess_token(), secret_dados_token));
            claims.put("cpf", Util.encrypt(assinante.getCpf(), secret_dados_token));
            claims.put("nome_assinante", Util.encrypt(assinante.getNome(), secret_dados_token));

            SiidxTokenPscDTO token = new SiidxTokenPscDTO();
            String jwtSiidx = JwtUtil.jwtEncode("iti", claims,3600000, secret_token);
            token.setToken(jwtSiidx);
            return token;
        } catch (Exception e) {
            throw new DetalheException( ErrosComunsEnum.ERRO_AUTENTICACAO_USUARIO);
        }

    }

    private String acessarTokenIti(String code) throws Exception {
        String grantType = "authorization_code";
        String retorno = assinadorItiToken.getToken(
                URLEncoder.encode(code, StandardCharsets.UTF_8),
                URLEncoder.encode(clientId, StandardCharsets.UTF_8),
                URLEncoder.encode(grantType, StandardCharsets.UTF_8),
                URLEncoder.encode(itiPass, StandardCharsets.UTF_8),
                redirectUri);
        return retorno;
    }

    private String acessarCertificadoUsuario(String token) throws Exception {
       return assinadorIticertificado.getCertificado(
                token);
    }

    private byte [] assinarNoIti(ItiHashParaAssinarDTO hash, String token) {
        byte [] retorno = assinadorItiAssinatura.getAssinar("Bearer " + token, hash);
        return  retorno;
    }

    public byte[] assinarPdf(byte[] pdfBytes, String nomeAssinante, String token, int pagina, float coordX, float coordY) {
        try (PDDocument doc = Loader.loadPDF(pdfBytes);
            SignatureOptions opts = new SignatureOptions();
            ByteArrayOutputStream out = new ByteArrayOutputStream(pdfBytes.length + 131072)) {

            // 1) Dicionário de assinatura: PAdES = CAdES no PDF
            PDSignature sig = new PDSignature();
            sig.setFilter(PDSignature.FILTER_ADOBE_PPKLITE);
            // Tente primeiro ETSI (PAdES). Se seu validador reclamar, teste adbe.pkcs7.detached.
            sig.setSubFilter(PDSignature.SUBFILTER_ETSI_CADES_DETACHED); // ou: PDSignature.SUBFILTER_ADBE_PKCS7_DETACHED
            if (nomeAssinante != null && !nomeAssinante.isBlank()) {
                sig.setName(nomeAssinante);
            }

            //PREPARAÇÃO DA ASSINATURA VISUAL
            //**************************************
            PDRectangle rect = PDFBoxUtil.rectTopLeft(doc, pagina, 160f, 65f, coordX, coordY);

            // 2) Placeholder generoso (PDF armazena DER como HEX -> ~2x bytes)
            opts.setPreferredSignatureSize(120_000);
            opts.setVisualSignature(PDFBoxUtil.createVisualSignatureTemplate(doc, pagina,rect, sig, nomeAssinante));
            doc.addSignature(sig, opts);


            // 3) Gera o conteúdo dos ByteRanges e calcula SHA-256 EXATO disso
            ExternalSigningSupport signing = doc.saveIncrementalForExternalSigning(out);
            byte[] hash = PDFBoxUtil.sha256Of(signing.getContent());
            String hashBase64 = Base64.getEncoder().encodeToString(hash);

            // 4) ITI (use HOMOLOG se vai validar em h-validar)
            //    assinarNoIti deve devolver o PKCS#7 do ITI (DER ou Base64/PEM).
            ItiHashParaAssinarDTO dto = new ItiHashParaAssinarDTO();
            dto.setHashBase64(hashBase64);
            //CHAMA O ASSINADOR DO ITI
            //*********************************************
            byte[] pkcs7 = assinarNoIti(dto, token);
            //*********************************************

            // 4.1) Normalize para DER binário (PDFBox espera DER cru)
            byte[] pkcs7Der = CertUtil.normalizePkcs7ToDer(pkcs7);

            // 5) Injeta o CMS no /Contents. PDFBox cuida de HEX + padding + ByteRange.
            signing.setSignature(pkcs7Der);

            byte[] signedPdf = out.toByteArray();

            return signedPdf;
        } catch (Exception e) {
            log.error("Falha ao assinar PAdES (verifique causa no stacktrace)" +  e.getMessage());
            throw new DetalheException(ErrosComunsEnum.ERRO_ASSINATURA_DIGITAL);
        }
    }

}





