package br.gov.caixa.siidx.pdfsign.dto;


import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.core.MediaType;
import lombok.Getter;
import org.jboss.resteasy.annotations.providers.multipart.PartType;

@Getter
public class PdfUploadDTO {
    @FormParam("file")
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    public byte[] file;

}
