package br.gov.caixa.siidx.exceptions;

import br.gov.caixa.siidx.exceptions.dto.MensagemErroDTO;
import br.gov.caixa.siidx.exceptions.dto.RetornoErroDTO;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.ext.ExceptionMapper;
import lombok.extern.slf4j.Slf4j;

/**
 * Mapper para tratar exceptions de {@link DetalheException}. Faz log do máximo de informação
 * possível dos problemas e retorna uma mensagem mais amigável.
 * 
 * DetalheException, usada quando a aplicação quer retornar algum detalhe explicativo para o usuário
 * e também quer retornar um status HTTP também específico Parecida com a NegocioException, porém
 * aceita mensagens customizadas e possui um campo adicional, "detalhe".
 * 
 * @author c134596
 *
 */
// @Provider
@Slf4j
public class TratadorExceptionDetalhe implements ExceptionMapper<DetalheException> {
    @Override
    public Response toResponse(DetalheException exc) {
        return tratarDetalheException(exc);
    }

    /**
     * Este método é estático package&dash;private, para possibiltar que outros tratadores de
     * exception possam utiliza&dash;lo.
     * 
     * @param excDet
     * @return
     */
    static Response tratarDetalheException(DetalheException excDet) {

        // log.error(excDet.getMessage() + ". Detalhe: " + excDet.getDetalhe(), excDet);
        Status status = excDet.getStatus();

        // Caso a causa da exceção seja um ResteasyWebApplicationException, registra
        // informações em log relacionadas com o response da API
        // if (excDet.getCause() instanceof ResteasyWebApplicationException) {
        // TratadorExceptionResteasy.logExtrairInfoResteasy((ResteasyWebApplicationException)
        // excDet.getCause());
        // }

        // String detalhe = excDet.getDetalhe() != null ? " - " + excDet.getDetalhe() : "";

        // Response.status(500).entity(new
        // ErrorResponseDTO(ErrosComunsEnum.ERRO_INTERNO_SERVIDOR)).build();

        return Response.status(status.getStatusCode())
                .entity(new RetornoErroDTO(new MensagemErroDTO(excDet))).build();
    }
}
