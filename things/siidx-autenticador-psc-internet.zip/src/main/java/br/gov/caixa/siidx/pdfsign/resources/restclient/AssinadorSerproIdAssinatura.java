package br.gov.caixa.siidx.pdfsign.resources.restclient;

import br.gov.caixa.siidx.pdfsign.dto.ItiHashParaAssinarDTO;
import br.gov.caixa.siidx.pdfsign.dto.SerproIdHashParaAssinarDTO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "serproid.token")
@RegisterProvider(WebApplicationException.class)
public interface AssinadorSerproIdAssinatura {
    @POST
    @Path("/signature")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({"application/pkcs7-signature", MediaType.APPLICATION_JSON})
    String getAssinar(
            @HeaderParam(value="Authorization")  String authorizationHeader,
            SerproIdHashParaAssinarDTO hashes);

}
