package br.gov.caixa.siidx.psc.resources.restclient;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "syngular.token")
@RegisterProvider(WebApplicationException.class)
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public interface SyngularToken {
    @POST
    @Path("/token")
    String getToken(
            @FormParam("grant_type") String grantType,
            @FormParam("code") String code,
            @FormParam("code_verifier") String codeVerifier,
            @FormParam("redirect_uri") String redirectUri,
            @FormParam("client_id") String clientId,
            @FormParam("client_secret") String secret
    );
}
