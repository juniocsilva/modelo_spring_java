package br.gov.caixa.siidx.psc.service;

import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;

public interface SyngularService {
    public SiidxTokenPscDTO getToken(String code, String codeVerifier) ;
}
