package br.gov.caixa.siidx.pdfsign.resources.impl;

import br.gov.caixa.siidx.exceptions.dto.MensagemErroDTO;
import br.gov.caixa.siidx.pdfsign.dto.SolicitaTokenItiDTO;
import br.gov.caixa.siidx.pdfsign.resources.AssinadorPdfGovBrResource;
import br.gov.caixa.siidx.pdfsign.resources.AssinadorPdfSerproIdResource;
import br.gov.caixa.siidx.pdfsign.service.AssinadorPdfGovBrService;
import br.gov.caixa.siidx.pdfsign.service.AssinadorPdfSerproIdService;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

@Slf4j
@ApplicationScoped
@Path("/api/assinador/serproid")
public class AssinadorPdfSerproIdResourceImpl implements AssinadorPdfSerproIdResource {

    @Inject
    private AssinadorPdfSerproIdService servico;



    @POST
    @Path("/assinar")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces("application/pdf")
    @Operation(summary = "End point utilizado para fazer assinatura em pdf no SerproId")
    @APIResponse(responseCode = "200", description = "Assinatura realizada com sucesso.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = SiidxTokenPscDTO.class)))
    @APIResponse(responseCode = "400", description = "Parâmetros informados estão inválidos.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MensagemErroDTO.class)))

    public Response assinaSerproId(MultipartFormDataInput  corpo) throws Exception {

        byte [] pdfAssinado = servico.assinar(corpo);

        return Response
                .ok(pdfAssinado)
                .type("application/pdf")
                .header("Content-Disposition", "attachment; filename=\"documento-assinado.pdf\"")
                .build();


    }
}


