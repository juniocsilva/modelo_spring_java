export enum Ambiente {
    LOCAL, DES, TQS, HMP, PLT, PRD
  }

export enum DnsSSO {
    LOCAL = "https://login.des.caixa/auth",
    DES = "https://login.des.caixa/auth",
    TQS = "https://login.des.caixa/auth",
    HMP = "https://login.des.caixa/auth",
    PLT = "https://login.des.caixa/auth",
    PRD = "https://login.prd.caixa/auth"
}

export function getKEYCLOAK_ROOT_URL(ambiente: Ambiente): any {
    //@ts-ignore
    return DnsSSO[Ambiente[ambiente]];
}

// https://random-data-api.com/documentation
export function getRandomDataAPI(): string {
    return 'https://random-data-api.com/api/v2';
}

// https://jsonplaceholder.typicode.com/guide/
export function getJsonPlaceholderAPI(): string {
    return 'https://jsonplaceholder.typicode.com';
}