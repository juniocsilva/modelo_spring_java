import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { KeycloakService } from './app/services/keycloak-service/keycloak.service';

const tokenSessionStorage = window.sessionStorage.getItem("token");
const idTokenSessionStorage = window.sessionStorage.getItem("idToken");
const refreshTokenSessionStorage = window.sessionStorage.getItem("refreshToken");

let kcInitOptions;
if (tokenSessionStorage) {
  kcInitOptions = {
    onLoad: "login-required",
    checkLoginIframe: false,
    promiseType: "native",
    token: tokenSessionStorage,
    idToken: idTokenSessionStorage,
    refreshToken: refreshTokenSessionStorage
  }
} else {
  kcInitOptions = {
    onLoad: "login-required",
    checkLoginIframe: false,
    promiseType: "native"
  }
}


KeycloakService.init(kcInitOptions)
  .then(() => {
    platformBrowserDynamic()
      .bootstrapModule(AppModule)
      .catch(err => console.log(err));
  })
  .catch((e: any) => {
    console.log("Error in bootstrap: " + e);
  });

KeycloakService.keycloakAuth.onTokenExpired = () => {
  KeycloakService.keycloakAuth.updateToken(5).then((refreshed: any) => {
    changeStoragedToken();
    if (refreshed) {
      console.log("Token was successfully refreshed");
    } else {
      console.log("Token is still valid");
    }
  }, (error: any) => {
    console.log("Failed to refresh the token, or the session has expired", error);
  });
};

function changeStoragedToken() {
  // console.log("Token expiration", moment(
  //   new Date(KeycloakService.keycloakAuth.tokenParsed.exp * 1000)).format("YYYY-MM-DD HH:mm:ss")
  // );
  sessionStorage.setItem("token", KeycloakService.keycloakAuth.token);
  sessionStorage.setItem("idToken", KeycloakService.keycloakAuth.idToken);
  sessionStorage.setItem("refreshToken", KeycloakService.keycloakAuth.refreshToken);
  sessionStorage.setItem("tokenParsed", JSON.stringify(KeycloakService.keycloakAuth.tokenParsed));
}