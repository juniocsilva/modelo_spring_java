import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule, provideHttpClient } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { DscAlertComponent } from 'sidsc-components/dsc-alert';
import { DscBreadcrumbComponent } from 'sidsc-components/dsc-breadcrumb';
import { DscButtonComponent } from 'sidsc-components/dsc-button';
import { DscHeaderComponent } from 'sidsc-components/dsc-header';
import { DscSidenavComponent } from 'sidsc-components/dsc-sidenav';
import { DscSnackbarModule, DscSnackbarService } from 'sidsc-components/dsc-snackbar';
import { AppComponent } from './app.component';
import { HttpsRequestInterceptor } from './interceptors/request.interceptor';
import { HomeComponent } from './pages/home/home.component';
import { KeycloakService } from './services/keycloak-service/keycloak.service';
import { LoadingService } from './services/loading.service';
import { UserService } from './services/user.service';
import { LoadingCaixaComponent } from './shared/loading-caixa/loading-caixa.component';
import { GlobalErrorHandler } from './handlers/global-error.handler';
import { DscDialogModule } from 'sidsc-components/dsc-dialog';
import { InclusaoFluxoAssinaturaComponent } from './pages/inclusao-fluxo-assinatura/inclusao-fluxo-assinatura.component';




/**
 * Define as rotas da aplicação
 * 
 * O objeto data é utilizado para construir os items do menu lateral, o breadcrumb, e os cards do dashboard na tela inicial
 * As propriedades mínimas definidas são title, description, icon, breadcrumb e order, mas podem ser adicionadas outras propriedades livremente
 * 
 * A rota de início não necessita de propriedades por ser injetada manualmente nos items de menu e nos cards
 */
export const appRoutes: Routes = [
  { 
    path: '', component: HomeComponent, 
    data: { 
      titulo: "Início",
      breadcrumb: "Início",
    } 
  }, 
  
  { 
    path: 'workflow-assinatura', component: InclusaoFluxoAssinaturaComponent, 
    data: { 
      title: "Inclusão workflow assinatura", 
      //description: "Inclusão workflow assinatura",
      //icon: "double_arrow",
      //breadcrumb: "Inclusão workflow assinatura",
      order: 1
    } 
  }, 
  
  { 
    path: '*', redirectTo: '' 
  }
];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
    LoadingCaixaComponent,
    MatIconModule,
    DscHeaderComponent,
    DscSidenavComponent,
    DscBreadcrumbComponent,
    DscBreadcrumbComponent,
    DscSnackbarModule,
    DscDialogModule,
    DscHeaderComponent,
    DscSidenavComponent,
    DscButtonComponent,
    DscAlertComponent
  ],
  providers: [
    LoadingService,
    DscSnackbarService,
    provideHttpClient(),
    KeycloakService,
    UserService,
    {
      provide: ErrorHandler, 
      useClass: GlobalErrorHandler
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpsRequestInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
