import { finalize, map } from "rxjs/operators";
import { Injectable, ExistingProvider } from "@angular/core";
import { Observable } from "rxjs";
import { HTTP_INTERCEPTORS, HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpHeaders, HttpResponse } from "@angular/common/http";
import { LoadingService } from "../services/loading.service";
import { Utils } from "../utils/utils";
import { environment } from '../../environments/environment';

/**
* Intercepta todas as requisições HTTP para efetuar alguns tratamentos.
* 
* - Insere Headers específicos padrões, como Access-Control-Allow-Origin e Authorization
* - Converte datas no formato string ISO para Date
* - Gerencia o total de requisições pendentes de conclusão para definir se o ícone de loading deve ser exibido
*/
@Injectable()
export class HttpsRequestInterceptor implements HttpInterceptor {

  requisicoesPendentes = 0;

  constructor(
    //private readonly keycloak: KeycloakService,
    private readonly loadingService: LoadingService
  ) { }

  /**
   * Método que intercepta todas as requisições HTTP para inserir Headers específicos
   * 
   * Caso a requisição possua o header "X-Skip-Interceptor", a requisição será enviada sem a inserção de Headers
   * 
   * @param req Requisição HTTP atual
   * @param next Próximo manipulador de requisição
   * @returns 
   */
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (req.headers.has("X-Skip-Interceptor")) {
      const headers = req.headers.delete("X-Skip-Interceptor");
      const dupReq = req.clone({ headers });
      return this.handle(dupReq, next);
    }
    const token: any = window.sessionStorage.getItem("token")
    const headers = new HttpHeaders({
      //"Content-Type": 'multipart/form-data',
      "Access-Control-Allow-Origin": "*",
      "apikey": environment.API_SICLI.apiKey,
      "Authorization": 'Bearer ' + token
    });       
    const dupReq = req.clone({ headers });
    return this.handle(dupReq, next);
  }

  handle(req: HttpRequest<any>, next: HttpHandler) {
    this.requisicoesPendentes++;
    if (this.requisicoesPendentes > 0) {
      this.loadingService.setHasReqHttpPendente(true);
    }
    return next.handle(req).pipe(map((val: HttpEvent<any>) => {
      if (val instanceof HttpResponse) {
        const body = val.body;
        this.convert(body);
      }
      return val;
    }), finalize(() => {
      this.requisicoesPendentes--;
      if (this.requisicoesPendentes <= 0) {
        this.requisicoesPendentes = 0;
      } else {
        this.loadingService.setHasReqHttpPendente(true);
      }

      if (this.requisicoesPendentes === 0) {
        this.loadingService.setHasReqHttpPendente(false);
      }
    }));
  }

  convert(body: any) {
    if (body === null || body === undefined) {
      return body;
    }
    if (typeof body !== "object") {
      return body;
    }
    for (const key of Object.keys(body)) {
      const value = body[key];
      if (Utils.isIsoDateString(value)) {
        const date = value as string;
        if (date.indexOf("+") !== -1) {
          body[key] = new Date(date.split("+")[0]);
        } else {
          body[key] = new Date(date);
        }
      } else if (typeof value === "object") {
        this.convert(value);
      }
    }
    return body;
  }
}

export const Interceptor: ExistingProvider[] = [
  {
    provide: HTTP_INTERCEPTORS,
    useExisting: HttpsRequestInterceptor,
    multi: true
  }
];
