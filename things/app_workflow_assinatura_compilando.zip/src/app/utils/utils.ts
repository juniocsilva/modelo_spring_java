import { environment } from "src/environments/environment";
import { SessionStorageValues } from "../models/enums/session-storage.enum";
import { ActivatedRoute } from "@angular/router";
import { DscBreadcrumbItem } from "sidsc-components/dsc-breadcrumb";
import { DscAlertVariant } from "sidsc-components/dsc-alert";

export abstract class Utils {

  public static isUndefined(value: any): boolean {
    return typeof value === "undefined";
  }

  public static isNull(value: any): boolean {
    return value === null;
  }

  public static isEmpty(value: any): boolean {
    return value === "";
  }

  public static isNullOrEmpty(value: string | undefined | null): boolean {
    return this.isNull(value) || this.isEmpty(value);
  }

  public static isFunction(value: any): boolean {
    return typeof value === "function";
  }

  public static isNumber(value: any): boolean {
    return typeof value === "number";
  }

  public static isString(value: any): boolean {
    return typeof value === "string";
  }

  public static isBoolean(value: any): boolean {
    return typeof value === "boolean";
  }

  public static isNonNullObject(value: any): boolean {
    return value !== null && typeof value === "object";
  }

  public static isIsoDateString(value: any): boolean {
    if (value === null || value === undefined) {
      return false;
    }
    if (typeof value === "string") {
      return /^(\d{4})-(\d{2})-(\d{2})T(\d{2})\:(\d{2})\:(\d{2})\.(\d{3})[+-](\d{4})/.test(value);
    } return false;
  }

  public static extractDeepPropertyByMapKey(obj: any, map: string): any {
    const keys = map.split(".");
    const head = keys.shift();

    return keys.reduce((prop: any, key: string) => {
      return !this.isUndefined(prop) && !this.isNull(prop) && !this.isUndefined(prop[key])
        ? prop[key]
        : undefined;
    }, obj[head ?? ""]);
  }

  public static getPropriedade(item: Record<string, any>, propriedade: string): string {
    return item[propriedade];
  }

  public static removeAccents(text: string): string {
    text = text?.toLowerCase();
    text = text?.replace(new RegExp(/[\xE0-\xE6]/g), "a");
    text = text?.replace(new RegExp(/[\xE8-\xEB]/g), "e");
    text = text?.replace(new RegExp(/[\xEC-\xEF]/g), "i");
    text = text?.replace(new RegExp(/[\xF2-\xF6]/g), "o");
    text = text?.replace(new RegExp(/[\xF9-\xFC]/g), "u");
    text = text?.replace(new RegExp(/\xE7/g), "c");
    text = text?.replace(new RegExp(/\xF1/g), "n");

    return text;
  }

  public static enumKeys<O extends object, K extends keyof O = keyof O>(obj: O): K[] {
    return Object.keys(obj) as K[]
  }

  public static onlyStrNumbersFromString(str: string): string {
    return (str && typeof str === "string")
      ? str?.replace(/\D/g, "")
      : "";
  }

  public static formatarMoeda(valor: string): string {
    const numero = parseFloat(valor);
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(numero);
  }

  public static formatarData(data: string): string {
    const [ano, mes, dia] = data.split('-');
    return `${dia}/${mes}/${ano}`;
  }

  public static padLeft(valueToPad: string, valueToBePadded: string, desiredLength: number): string {
    if (typeof valueToBePadded === "undefined") {return valueToPad;}

    return (valueToPad + valueToBePadded).slice(-desiredLength);
  }

  public static extractOnlyNumbers(str: string): string {
    if (!str) {return "";}
    return str.replace(/\D/g, "");
  }

  public static onlyNumbersFromString(str: string): number {
    if (!str || typeof str != "string") {return 0;}
    const onlyNumbers = this.extractOnlyNumbers(str);
    return Number(onlyNumbers);
  }

  public static getDDD(celular: string): number {
    return parseInt(celular.substring(2, 0));
  }

  public static getCelular(celular: string): number {
    return parseInt(celular.substring(2));
  }

  public static getNomeClientePnc(): string {
    const cssSelectorExpandido = ".tab-clientes-wrapper .aba-cliente .aba-ativa .dados .nome-cliente strong";
    const cssSelectorReduzido = ".tab-clientes-wrapper .aba-cliente-reduzido .aba-ativa .dados .nome-cliente-reduzido strong";
    let nome = this.getNome(cssSelectorExpandido) || this.getNome(cssSelectorReduzido) || "CLIENTE";
    return nome;
  }
  
  private static getNome(cssSelector: string): string | null {
    const regexSoLetras = /[^A-Za-z ]+/g;
    return document?.querySelector(cssSelector)?.innerHTML?.replace(regexSoLetras, "")?.trim() || null;
  }

  public static getOperacaoSiapiSiapx(contrato: string): string {
    const partesContrato = contrato.split(".");
    return partesContrato.length > 2 ? partesContrato[2] : "";
  }

  public static getAgenciaContratoSiapiSiapx(contrato: string): string {
    const partesContrato = contrato.split(".");
    return partesContrato.length > 2 ? partesContrato[1] : "";
  }

  public static getNumeroContratoSiapiSiapx(contrato: string): string {
    const partesContrato = contrato.split(".");
    return partesContrato.length > 2 ? partesContrato[3] : "";
  }

  public static sortStringArray(): any {
    return (a: string, b: string) => a.localeCompare(b);
  }

  public static getApiUrlByAmbiente(): string {
    if (environment.production) {
      return environment.API_DES_URL;
    } else {
      return environment.API_LOCAL_URL;
    }
  }

  public static getAuthorizationHeader(): string {
    return sessionStorage.getItem(SessionStorageValues.ACCESS_TOKEN)!;
  }

  public static buildBreadcrumb(route: ActivatedRoute, url: string = '', breadcrumbs: DscBreadcrumbItem[] = []): DscBreadcrumbItem[] {
    const children: ActivatedRoute[] = route.children;

    if (children.length === 0) {
      return breadcrumbs;
    }

    for (const child of children) {
      const routeURL: string = child.snapshot.url.map(segment => segment.path).join('/');

      /**
       * caso este segmento da url seja o último, 
       * exibe apenas o nome da página atual como texto, sem estar em formato de link
       */
      if (children.indexOf(child) === children.length - 1) {
        breadcrumbs.push({ label: child.snapshot.data['breadcrumb'] || routeURL, url: '' });
        return breadcrumbs;
      }

      if (routeURL !== '') {
        url += `/${routeURL}`;
      }

      const label = child.snapshot.data['breadcrumb'] || routeURL;
      breadcrumbs.push({ label, url });

      return this.buildBreadcrumb(child, url, breadcrumbs);
    }

    return breadcrumbs;
  }

  public static getMaterialIconByVariant(variant: DscAlertVariant): string {
    switch (variant) {
      case "danger":
        return "error";
      case "success":
        return "check_circle";
      case "warning":
        return "warning";
      default:
        return "info";
    }
  }

}