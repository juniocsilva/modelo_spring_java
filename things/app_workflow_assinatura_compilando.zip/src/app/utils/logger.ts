/**
 * Modelo básico de log customizado para o console, permitindo detalhar ou resumir informações relevantes.
 */
export abstract class Logger {

    public static readonly CUSTOM_LOG_SYMBOL = (variant: string) => `#[${variant}]`;

    private static log(variant: string, message: string, ...data: any): void {
        let consoleMessage = "";

        consoleMessage = `${this.CUSTOM_LOG_SYMBOL(variant)}: ${new Date().toLocaleTimeString()}\n`;
        consoleMessage += `${message}`;

        console.log(consoleMessage, data);
    }

    public static info(message: string, ...data: any) {
        this.log("INFO", message, data);
    }

    public static error(message: string, ...data: any) {
        this.log("ERRO", message, data);
    }
}