export interface BankDetails {
    id: number;
    uid: string;
    account_number: string;
    iban: string;
    bank_name: string;
    routing_number: string;
    swift_bic: string;
}

export interface Photo {
    albumId: number;
    id: number;
    title: string;
    url: string;
    thumbnailUrl: string;
}

export interface Assinante {
    nome: string,
    cpf: string,
    telefone: string,
    email: string,
    papel: string
    
}

export interface Documento {
    nome?: string,
    mimeType?: string,
    tamanho?: number
    conteudo?: string
    arquivo?: any
    
}