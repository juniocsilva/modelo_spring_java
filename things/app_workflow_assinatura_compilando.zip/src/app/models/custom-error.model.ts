export class AlertException extends Error {

    constructor(
        msg: string,
        error?: Error
    ) {
        super(msg);
        Object.setPrototypeOf(this, AlertException.prototype);
    }
}