export enum DscTableColumnAlign {
    LEFT = 'left',
    CENTER = 'center',
    RIGHT = 'right'
}