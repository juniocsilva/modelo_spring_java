export enum SessionStorageValues {
    CPF_CNPJ = "cpfCnpj",
    TOKEN_MATRICULA = "tokenParsed",
    ACCESS_TOKEN = "token"
}
