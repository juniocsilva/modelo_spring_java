import { TemplateRef } from "@angular/core";
import { DscTableColumnAlign } from "sidsc-components/dsc-table";

/**
 * Propriedades normalmente utilizadas para criar colunas do DSC-Table
 */
export interface DscCustomTableColumn {
    property: string;
    title: string;
    value?: (obj: any) => any;
    template?: TemplateRef<any>;
    bodyCellAlign?: DscTableColumnAlign;
    width?: number;
}
