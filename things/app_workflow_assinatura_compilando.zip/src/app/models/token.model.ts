export interface DecodedToken {
    jti?: string;
    exp?: number;
    nbf?: number;
    iat?: number;
    iss?: string;
    sub?: string;
    typ?: string;
    azp?: string;
    nonce?: string;
    auth_time?: number;
    session_state?: string;
    acr?: string;
    allowed_origins?: string[];
    realm_access?: {
        roles?: string[];
    };
    scope?: string;
    segmento_sistema?: string;
    "2f_cert"?: string;
    "co-unidade"?: string;
    cert_obr?: boolean;
    name?: string;
    preferred_username?: string;
    given_name?: string;
    clientAddress?: string;
    family_name?: string;
    email?: string;
}