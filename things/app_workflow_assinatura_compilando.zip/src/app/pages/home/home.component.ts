import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Route, Router, RouterModule } from '@angular/router';
import { appRoutes } from 'src/app/app.module';
import { DscModule } from 'src/app/shared/dsc.module';
import { PageHeaderComponent } from 'src/app/shared/page-header/page-header.component';

/**
 * Tela inicial com cards que representam as rotas/funcionalidades da aplicação.
 */
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  standalone: true,
  imports: [CommonModule, PageHeaderComponent, DscModule, RouterModule]
})
export class HomeComponent implements OnInit {

  /**
   * Rotas definidas no app.module
   */
  public appRoutes = appRoutes;

  public cards: Route[] = [];

  constructor(
    private readonly router: Router
  ) { }

  ngOnInit() {
    this._criaCards();
  }

  private _criaCards(): void {
    this.appRoutes.forEach(route => {
      if (route.path !== '' && route.path !== '*') {
        this.cards.push(route);
      }
    });
  }

  goTo(card: Route) {
    this.router.navigateByUrl(card.path!);
  }

}