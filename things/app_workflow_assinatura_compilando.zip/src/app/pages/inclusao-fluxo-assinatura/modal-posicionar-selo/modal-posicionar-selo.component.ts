import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DscCrudModule } from 'src/app/shared/dsc-crud.module';
import { Option } from 'sidsc-components/dsc-select';
import { MatDialogRef } from '@angular/material/dialog';

import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';


/**
 * Componente criado para isolar o formulário de criação/edição de itens
 */
@Component({
  selector: 'app-modal-assinante',
  templateUrl: './modal-posicionar-selo.component.html',
  styleUrls: ['./modal-posicionar-selo.component.scss'],
  standalone: true,
  imports: [CommonModule, DscCrudModule, NgxExtendedPdfViewerModule]
})
export class ModalPosicionarSeloComponent {
  @Output() salvarEvent = new EventEmitter<any>();
  @Output() cancelarEvent = new EventEmitter<void>();

  public readonly BTN_SALVAR_TEXT = "Salvar";
  public readonly BTN_CANCELAR_TEXT = "Cancelar";

  public documento:string = ''
  public nomeDocumento: string = ''
  public dados 
  public alturaViewer = '250px'
  public assinantes: Option[] = [];
  public desabilitarSalvar = true
  public assinanteSelecionado = ''
  
  private assinaturas = new Map();
  private coordenadas = {
    assinante: '',
    pagina: -1,
    x: 0,
    y:0
  }

  public annotationLayer: any;

  constructor(private dialogRef: MatDialogRef<ModalPosicionarSeloComponent>, 
   @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.dados = data.dados
    
    this.assinantes = this.dados.assinantes.map((item:any) => {
      return {
        value: item.cpf,
        label: item.nome
      }
    })
    this.documento = this.dados.documentos[0].conteudo
    this.nomeDocumento = this.dados.documentos[0].nome
    
  }

  desenharRetangulo() {
    console.log('desenhando retangulo...')
    console.log(this.annotationLayer)
      const rect = document.createElement('div');
      rect.style.position = 'absolute';
      rect.style.left = `${this.coordenadas.x}px`;
      rect.style.top = `${this.coordenadas.y}px`;
      rect.style.width = '200px';
      rect.style.height = '100px';
      rect.style.border = '2px solid red';
      rect.style.pointerEvents = 'none';
      this.annotationLayer?.appendChild(rect);
    
  }
    

  changeAssinante(evento:any) {
    
      this.coordenadas.assinante = evento.value
      this.desabilitarSalvar = false
     
   
  }

  onAnnotationLayerRendered(event: any) {
    console.log(event)
    this.annotationLayer = event.source.annotationLayer?.div;
  }

  onTextLayerRendered(event: any) {
  
    const pageDiv:any = document.querySelector(
     `.page[data-page-number='${event.pageNumber}'] .textLayer`
    );
    if (pageDiv && !pageDiv.hasAttribute('data-listener-attached')) {
      pageDiv.setAttribute('data-listener-attached', 'true');
      pageDiv.addEventListener('click', (e: MouseEvent) => this.handleClick(e, event.pageNumber));
    }
  }

  handleClick(event: MouseEvent, pageNumber: number) {
   
    const bounds = (event.target as HTMLElement).getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    
    this.coordenadas.pagina = pageNumber
    this.coordenadas.x = Math.round(x)
    this.coordenadas.y = Math.round(y)

    let z = {
      assinante: this.coordenadas.assinante,
      pagina: this.coordenadas.pagina,
      x: this.coordenadas.x,
      y: this.coordenadas.y
    }
    console.log(z)
    let assinantes:any = ''
    z.assinante  = 'Teste'
    if (z.assinante != '') {
      this.assinaturas.set(this.coordenadas.assinante, z)
      
      for(const [key, value] of this.assinaturas) {

        assinantes += `Assinante ${value.assinante} / Página ${value.pagina} / x: ${value.x} / y: ${value.y}\n`
      }
      //this.desenharRetangulo()
     alert(assinantes)
    }
    
  }

  public salvar(): void {
    let assinantes:any = []
    for(const [key, value] of this.assinaturas) {
      
      assinantes.push(value)
    }
    this.dados.documentos[0].assinantes = assinantes
    this.salvarEvent.emit(this.dados);
    this.cancelar()
  }

  public cancelar(): void {
    this.dialogRef.close()
  }

  public consultar(): void {
    
  }

}
