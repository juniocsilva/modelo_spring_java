import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DscCrudModule } from 'src/app/shared/dsc-crud.module';
import { Option } from 'sidsc-components/dsc-select';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { InclusaoFluxoAssinaturaService } from '../inclusao-fluxo-assinatura.service';
import { LoadingService } from 'src/app/services/loading.service';
import { Observable } from "rxjs";

/**
 * Componente criado para isolar o formulário de criação/edição de itens
 */
@Component({
  selector: 'app-modal-assinante',
  templateUrl: './modal-assinante.component.html',
  styleUrls: ['./modal-assinante.component.scss'],
  standalone: true,
  imports: [CommonModule, DscCrudModule]
})
export class ModalAssinanteComponent {
  @Output() salvarEvent = new EventEmitter<FormGroup>();
  @Output() cancelarEvent = new EventEmitter<void>();

  public readonly BTN_SALVAR_TEXT = "Salvar";
  public readonly BTN_CANCELAR_TEXT = "Cancelar";
  public exibirMensagem = false
  public mensagemErro = ''
  public form = new FormGroup<any>({});
  public loading: boolean = false;
  public loading$ = new Observable<boolean>()
  public clienteEncontrado = false;
  public papeis: Option[] = [
    {
      label: 'Assinante', value: 'Assinante'
    },
    
  ];


  constructor(private dialogRef: MatDialogRef<ModalAssinanteComponent>, 
    private readonly loadingService: LoadingService,

    private service: InclusaoFluxoAssinaturaService,
     @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.form = data.form
    
  }

  ngOnInit() {
    this.loading$ = this.loadingService.hasToShowLoading$;
  }

  public salvar(): void {
    this.salvarEvent.emit(this.form);
    this.cancelar()
  }

  public cancelar(): void {
    this.dialogRef.close()
  }

  public consultar(): void {
    let retorno = this.buscarCliente(this.form.controls['cpf'].value)
    console.log(retorno)
  }

  public buscarCliente(cpfcnpj: string): void {
    this.loadingService.setIsCustomLoading(true);
    this.mensagemErro = 'Aguarde ...'
    //this.exibirMensagem = true
    this.loading = true
    this.service.buscarCliente(cpfcnpj).subscribe({
      next: (pesquisaGeral: any) => this.trataRetornoConsultaDadosSICLI(pesquisaGeral, cpfcnpj, true),
      error: (erro) => this.trataErroConsultaDadosSICLI(erro)
    });
  }

  
  private trataRetornoConsultaDadosSICLI(dadosBasicos:any, cpfCnpj: string, sicli: boolean): void {
    //if (!dadosBasicos) return this.mensagemService.exibirMensagem(MessageType.ERROR, "Dados inválidos");
    this.loadingService.setIsCustomLoading(false)
    this.clienteEncontrado = true;
    let dados:any = {
      nome: dadosBasicos.dadosPessoais.nome,
      telefone: dadosBasicos.meioComunicacao.celular.ddd + dadosBasicos.meioComunicacao.celular.numero,
      email: dadosBasicos.meioComunicacao.email.email,
      cpf: cpfCnpj,
      papel: 'Assinante'
      
    }
    this.mensagemErro = ''
    this.exibirMensagem = false
    this.loading = false
    this.salvarEvent.emit(dados)
    this.cancelar()
  }

  private trataErroConsultaDadosSICLI(error: any): void {
    console.log(error.error)
    if (error.error.retorno) {
      this.mensagemErro = error.error.retorno.mensagem;
      
    } else {
      this.mensagemErro = "Não foi possível acessar a API do SICLI. Contate o administrador.";
    }
    this.loading = false
    this.exibirMensagem = true
    this.loadingService.setIsCustomLoading(false)
  }

}
