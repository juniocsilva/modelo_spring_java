import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {} from '@angular/common/http'
import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';

import { Observable, of, BehaviorSubject, timeout } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class InclusaoFluxoAssinaturaService {
  
  private headers = new HttpHeaders();
  private timeOut: number = 20000;
  private token: any = ''

  constructor(
    private http: HttpClient,
   ) {
      this.token =  window.sessionStorage.getItem("token") ;
      
     }

  /* SICLI */
  public buscarCliente(cpfCnpj: string): Observable<any> {
    this.headers = new HttpHeaders({
        "apikey": environment.API_SICLI.apiKey,
        "client-id": environment.API_SICLI.clientId,
        'rejectUnauthorized': 'false',
        'Authorization': 'Bearer ' + environment.API_SICLI.token
      });
    //let url = `https://api.operacao360.caixa:3050/api/v1/siidx-sicli/${cpfCnpj}`;
    let url = `https://api.des.caixa:8443/cadastro/v2/clientes?cpfcnpj=${cpfCnpj}&classe=1&campos=precarga`;
    //let url = environment.URL_SICLI.replace('${cpfCnpj}', cpfCnpj)
    
    return this.http.get<any>(
      url, 
      { headers: this.headers }
    ).pipe(
      timeout(this.timeOut)
    );
  }

  /* SIIDX */
  public incluirFluxoAssinatura(form: any): Observable<any> {
    // let headers = new HttpHeaders({
    //     "apikey": environment.API_SICLI.apiKey,
    //     //'rejectUnauthorized': 'false',
    //     'Authorization': 'Bearer ' + this.token
    //   });
    let url = `https://api.des.caixa:8443/identidade-digital/assinador-documentos/solicitarassinatura/solicitar-assinatura`;
    return this.http.post<any>(
      url, form
      
    ).pipe(
      timeout(this.timeOut)
    );
  }
  //

  public getNomeUsuario() {
    let tokenDecodificado:any = jwtDecode(this.token)
    return tokenDecodificado.given_name
  }
}
