import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DscCrudModule } from 'src/app/shared/dsc-crud.module';
import { Option } from 'sidsc-components/dsc-select';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { InclusaoFluxoAssinaturaService } from '../inclusao-fluxo-assinatura.service';
import { LoadingService } from 'src/app/services/loading.service';
import { Observable } from "rxjs";

/**
 * Componente criado para isolar o formulário de criação/edição de itens
 */
@Component({
  selector: 'app-modal-erro-inclusao',
  templateUrl: './modal-erro-inclusao.component.html',
  styleUrls: ['./modal-erro-inclusao.component.scss'],
  standalone: true,
  imports: [CommonModule, DscCrudModule]
})
export class ModalErroInclusaoComponent {
  
  @Output() cancelarEvent = new EventEmitter<void>();

  public readonly BTN_CANCELAR_TEXT = "Fechar";
  public exibirMensagem = false
  public mensagemErro = ''
  public erro:any;

  constructor(private dialogRef: MatDialogRef<ModalErroInclusaoComponent>, 
    private readonly loadingService: LoadingService,

    private service: InclusaoFluxoAssinaturaService,
     @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.erro = data.dados.error
    console.log('dados recebidos no modal',data)
    
  }

  public cancelar(): void {
    this.dialogRef.close()
  }

}
