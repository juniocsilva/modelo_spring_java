import { CommonModule, DatePipe  } from '@angular/common';
import { AfterViewInit, Component, OnDestroy, OnInit, TemplateRef, ViewChild, ChangeDetectorRef, ElementRef } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Option } from 'sidsc-components/dsc-select';
import { DscStepperComponent, DscStepperModel } from 'sidsc-components/dsc-stepper';

import { LoadingService } from 'src/app/services/loading.service';
import { MessageService } from 'src/app/services/message.service';
import { DscCrudModule } from 'src/app/shared/dsc-crud.module';
import { PageHeaderComponent } from 'src/app/shared/page-header/page-header.component';
import { StepperNavButtonsComponent } from 'src/app/shared/stepper-nav-buttons/stepper-nav-buttons.component';
import { DscModule } from 'src/app/shared/dsc.module';
import { Assinante, Documento } from 'src/app/models/random-api-data.model';
import { DscTableColumn, DscTableColumnBuilder, DscTableComponent } from 'sidsc-components/dsc-table';
import { DscCustomTableColumn } from 'src/app/models/dsc-helpers.model';
import { ModalAssinanteComponent } from "./modal-assinante/modal-assinante.component";
import { ModalAlterarAssinanteComponent } from "./modal-alterar-assinante/modal-alterar-assinante.component";

import { MatIconModule } from '@angular/material/icon';

import { MatDialog } from '@angular/material/dialog';
import { ModalPosicionarSeloComponent } from './modal-posicionar-selo/modal-posicionar-selo.component';
import { UserService } from 'src/app/services/user.service';
import { SessionStorageValues } from 'src/app/models/enums/session-storage.enum';
import { InclusaoFluxoAssinaturaService } from './inclusao-fluxo-assinatura.service';
import { ModalSucessoInclusaoComponent } from './modal-sucesso-inclusao/modal-sucesso-inclusao.component';
import { ModalErroInclusaoComponent } from './modal-erro-inclusao/modal-erro-inclusao.component';


/**
* Template de formulário extenso, dividido em múltiplas etapas.
*
* Utiliza o componente DSC-Stepper para gerenciar o fluxo e um FormGroup pai (completeForm) que armazena o status do preenchimento total.
*/
@Component({
  selector: 'app-workflow-assinatura',
  templateUrl: './inclusao-fluxo-assinatura.component.html',
  styleUrls: ['./inclusao-fluxo-assinatura.component.scss'],
  standalone: true,
  imports: [CommonModule, PageHeaderComponent, DscCrudModule, DscStepperComponent, DscModule, StepperNavButtonsComponent, ModalAssinanteComponent, ModalPosicionarSeloComponent]
})
export class InclusaoFluxoAssinaturaComponent implements OnInit, OnDestroy, AfterViewInit {

  private readonly subscription = new Subscription();
  @ViewChild('btnExcluir', { static: true }) btnExcluir!: TemplateRef<any>;
  @ViewChild('tblAssinantes', { static: true }) tblAssinantes!: DscTableComponent<any>;
  @ViewChild('statusAssinatura', { static: true }) statusAssinatura!: TemplateRef<any>;
  @ViewChild('inputFile', { static: true }) inputFile!: ElementRef<any>;
  
  
  @ViewChild('btnsEditarExcluirAssinantes', { static: true }) btnsEditarExcluirAssinantes!: TemplateRef<any>;
  @ViewChild('btnsEditarExcluirDocumentos', { static: true }) btnsEditarExcluirDocumentos!: TemplateRef<any>;
  @ViewChild('posicionarSelo', { static: true }) posicionarSelo!: TemplateRef<any>;
  @ViewChild('modalAssinantes', { static: true }) modalAssinantes!: TemplateRef<any>; 
  @ViewChild('modalDocumentos', { static: true }) modalDocumentos!: TemplateRef<any>; 
  
  @ViewChild('firstStep', { static: true })
  private readonly firstStep!: TemplateRef<any>;

  @ViewChild('secondStep', { static: true })
  private readonly secondStep!: TemplateRef<any>;

  @ViewChild('thirdStep', { static: true })
  private readonly thirdStep!: TemplateRef<any>;

  public stepperHorizontal!: DscStepperModel;
  public selectedIndex: number = 0;

  public completeForm = this._formBuilder.group({});
  public firstFormGroup!: FormGroup;
  public secondFormGroup!: FormGroup;
  public thirdFormGroup!: FormGroup;
  public fourthFormGroup!: FormGroup;

  public tooltipFormAtual = "";

  public options: Option[] = [
    {
      label: 'Contrato Minha Casa Minha Vida', value: 'Contrato Minha Casa Minha Vida'
    },
    
  ];

  public papeis: Option[] = [
    {
      label: 'Assinante', value: 'assinante'
    },
    
  ];

  public titulo = "Salvar Fluxo"

  public assinantes: Assinante[] = []
  public documentos: Documento[] = []
  public tableAssinantesColumns: DscTableColumn[] = [];
  public tableAssinantesResumoColumns: DscTableColumn[] = [];
  public tableDocumentosColumns: DscTableColumn[] = [];
  public tableDocumentosResumoColumns: DscTableColumn[] = [];
  public labelBotaoAssinantes:string = 'Adicionar assinantes'
  public labelBotaoDocumentos:string = 'Adicionar documentos'
  public assinantesSelecionados: any = []
  private hoje: Date = new Date()
  public validadeAssinatura: any = this.formatarData(this.getDataValidade())
  public documentoSelecionado: any
  public frame_label = 'Inclusão de Fluxo de Assinatura'
  public produtoSelecionado = ''
  public numeroContrato = ''

  public modalIncluirAssinante = new FormGroup({
    papel: new FormControl('', [Validators.required, Validators.maxLength(20)]),
    cpf: new FormControl('', [Validators.required, Validators.maxLength(20)]),
  
  });

  public modalSelecionarDocumento = new FormGroup({
    documento: new FormControl('', [Validators.required, Validators.maxLength(256)]),
  });

  public modalPosicionarSelo = {
    documentos: this.documentos,
    assinantes: this.assinantes
  }

  public modalAlterarAssinante = new FormGroup({
    papel: new FormControl('', [Validators.required, Validators.maxLength(20)]),
    cpf: new FormControl('', [Validators.maxLength(20)]),
    nome: new FormControl('', [Validators.maxLength(100)]),
    telefone: new FormControl('', [Validators.required, Validators.maxLength(20)]),
    email: new FormControl('', [Validators.required, Validators.maxLength(100)]),
  
  });

  constructor(
    private readonly _formBuilder: FormBuilder,
    private readonly _loadingService: LoadingService,
    public readonly messageService: MessageService,
    private servico: InclusaoFluxoAssinaturaService,
    //private datePipe: DatePipe,
    private dialog: MatDialog
   
  ) { }

  ngOnInit() {
    this._buildCompleteForm();
    this._initStepperHorizontal();
    this.mockDados();
  }

  ngAfterViewInit(): void {
    this.setTooltipFormAtual();
  }
  
  public incluirDocumentos(inputFile:any) {
    this.insertDocuments(inputFile)
  }

  insertDocuments(input:any) {
    if (input) {
       input.click();
    }
  }

  getNomeUsuario() {
    return this.servico.getNomeUsuario();
  }

  alterouProduto(evento:any) {
    this.produtoSelecionado = evento.value
  }

  alterouNumeroContrato(evento:any) {
    this.numeroContrato =  this.firstFormGroup.controls['numeroContrato'].value
  }

  async abrirModalPosicionarSelo(item:any) {
    this.modalPosicionarSelo.documentos = []
    this.modalPosicionarSelo.assinantes = this.assinantes
    this.modalPosicionarSelo.documentos.push(item)
    
    const dialogo = this.dialog.open(ModalPosicionarSeloComponent, {
      disableClose: true,
      data: { dados: this.modalPosicionarSelo }
    })
  
    dialogo.componentInstance.salvarEvent.subscribe((data: any) => {
      //console.log('Evento recebido do modal:', data);
      let documento:any = data.documentos[0].arquivo
      //documento.push( data.documentos[0].arquivo)
      let assinantes = data.assinantes
      let interessados:any = []
      let ordem = 1
      data.documentos[0].assinantes.forEach((element:any) => {
        let dados = assinantes.find((assinante:any) => assinante.cpf == element.assinante)
        
        let assinante = {
            nome: dados.nome.trimEnd(),
            cpf: dados.cpf,
            email: dados.email,
            celular: dados.telefone,
            selo: {
              pagina: element.pagina,
              x: element.x,
              y: element.y,
              largura: 200,
              altura: 80
            },
            ordem: ordem,
            papel: dados.papel.toUpperCase()
        }
        interessados.push(assinante)
        ordem += 1
      });
      let dados_solicitacao: any = {
        nome: "Fluxo Completo",
        descricao: "Teste sem assinar",
        tipoAssinatura: "QUALIFICADA",
        dataLimiteAssinatura: "2025-05-20T16:01:12", //this.datePipe.transform(this.getDataValidade(), 'yyyy-MM-ddTHH:mm:ss'),
        interessados: interessados,
        sequencial: true,
        interrompeSeNegativo: true
      }
      
      let form = new FormData()
      //console.log(documento)
      form.append('dados_solicitacao', JSON.stringify(dados_solicitacao))
      form.append('documento', documento)
      console.log('dados_solicitacao', JSON.stringify(dados_solicitacao))
      this.servico.incluirFluxoAssinatura(form).subscribe({
       next: async (retorno:any) => {
        await this.exibirRetornoInclusao(retorno)
        
       },
       error: async (err:any) => {
        await this.exibirErroInclusao(err)
       }

      });
     // Aqui você pode adicionar a lógica que deseja executar quando o evento for recebido
    });
    
  }

  async exibirRetornoInclusao(dados:any) {
    const dialogo = this.dialog.open(ModalSucessoInclusaoComponent, {
      disableClose: true,
      data: { dados: dados }
    })
  }

  async exibirErroInclusao(err:any) {
    const dialogo = this.dialog.open(ModalErroInclusaoComponent, {
      disableClose: true,
      data: { dados: err }
    })
  }

  fileChanged(evt:any) {
    const files = evt.target.files;
    for (let i = 0, f:any; f = files[i]; i++) {
      const reader = new FileReader();
      reader.onload = () => {
        const conteudo =  reader.result?.toString()
        const dados:any = conteudo?.split(',')
         
          if(dados[0].indexOf('pdf') > 0) {
            const mime = dados[0].split(";")
                        
            let documento:Documento = {
              nome: f.name,
              mimeType: f.type,
              tamanho: f.size,
              conteudo: conteudo,
              arquivo: f
            }
            this.incluirDocumentosTabela(documento)
          }
       };
      reader.readAsDataURL(f)
    }
  }

  openModal() {
    this.modalIncluirAssinante.reset()
    const dialogo = this.dialog.open(ModalAssinanteComponent, {
        disableClose: true,
        data: { form: this.modalIncluirAssinante }
    })
    
      dialogo.componentInstance.salvarEvent.subscribe((data: string) => {
      //console.log('Evento recebido do modal:', data);
      this.incluirAssinante(data)
       // Aqui você pode adicionar a lógica que deseja executar quando o evento for recebido
      });
  }

  private getDataValidade() {
    let validade = this.hoje.getTime();
    validade = validade + (30 * 86400000);
    let novaData = new Date(validade)
   
    return new Date(novaData)
  } 

  public closeModal() {
    this.dialog.closeAll()
  }

  public modalConsultarAssinante() {

  }

  public cancelarModalAssinante() {

  }

  public salvarModalAssinante() {
      //console.log("Salvou assinante")
  }
  private mockDados() {
    this.tableAssinantesColumns = this._criaColunasAssinantes();
    this.tableAssinantesResumoColumns = this._criaColunasResumoAssinantes();
    this.tableDocumentosColumns = this._criaColunasDocumentos();
    this.tableDocumentosResumoColumns = this._criaColunasResumoDocumentos();
   
  }  

  public editarAssinante(item:any) {
    this.modalAlterarAssinante.controls['cpf'].setValue(item.cpf)
    this.modalAlterarAssinante.controls['nome'].setValue(item.nome)
    this.modalAlterarAssinante.controls['papel'].setValue(item.papel)
    this.modalAlterarAssinante.controls['telefone'].setValue(item.telefone)
    this.modalAlterarAssinante.controls['email'].setValue(item.email)

    const dialogo = this.dialog.open(ModalAlterarAssinanteComponent, {
      disableClose: true,
      data: { form: this.modalAlterarAssinante }
    })
  
    dialogo.componentInstance.salvarEvent.subscribe((data: any) => {
    //console.log('Evento recebido do modal:', data);
    
      const novoArray = this.assinantes.map((element:any) => {
        if (element.cpf == data.controls['cpf'].value) {
          return { ...element, telefone: data.value.telefone, email: data.value.email };
        }
        return element;
      });

      this.assinantes = novoArray
    });
  }

  public incluirAssinante(item:any) {
    let newArray = this.assinantes.filter((obj:any) => obj.cpf != '9')
    newArray.push(item)
    this.assinantes = newArray
   
  }

  public excluirAssinante(item:any) {
    let newArray = this.assinantes.filter((obj:any) => obj.cpf !== item.cpf);
    this.assinantes = newArray
  }

  public incluirDocumentosTabela(documento: Documento) {
    let array = this.documentos.map(item => {
      return item
    })
    array.push(documento)
    this.documentos = array
  }

  public excluirDocumentos(item:any) {
    let newArray = this.documentos.filter((obj:any) => obj.nome !== item.nome);
    this.documentos = newArray
  }

  public editarDocumentos(item:any) {

  }
 
  private _criaColunasAssinantes() {
      const colunas: DscCustomTableColumn[] = [
        { 
          property: 'nome', 
          title: 'NOME', 
          width: 300, 
          value: (obj: Assinante) => obj.nome
        },
        { 
          property: 'telefone', 
          title: 'TELEFONE', 
          width: 200, 
          value: (obj: Assinante) => obj.telefone
        },
        { 
          property: 'email', 
          title: 'EMAIL', 
          width: 300, 
          value: (obj: Assinante) => obj.email 
        },
        
        { 
          property: 'cpf', 
          title: 'CPF', 
          width: 200, 
          value: (obj: Assinante) => obj.cpf 
        },
        { 
          property: 'btnEditar', 
          title: 'Ações', 
          template: this.btnsEditarExcluirAssinantes, 
          bodyCellAlign: 'center', 
          width: 120 
        }
        
      ];
      return colunas.map(coluna => {
        const builder = DscTableColumnBuilder.instance()
          .property(coluna.property)
          .title(coluna.title)
          .headerFixed(true)
          .width(coluna.width)
          .value(coluna.value);
  
        if (coluna.template) {
          builder.template(coluna.template);
        }
        if (coluna.bodyCellAlign) {
          builder.bodyCellAlign(coluna.bodyCellAlign);
        }
        return builder.build();
      });
    }

    private _criaColunasResumoAssinantes() {
      const colunas: DscCustomTableColumn[] = [
        { 
          property: 'nome', 
          title: 'NOME', 
          width: 300, 
          value: (obj: Assinante) => obj.nome
        },
        { 
          property: 'cpf', 
          title: 'CPF', 
          width: 200, 
          value: (obj: Assinante) => obj.cpf 
        },
        { 
          property: 'papel', 
          title: 'Papel', 
          width: 200, 
          
          value: (obj: Assinante) => obj.papel
        },
        { 
          property: 'status', 
          title: 'Status', 
          width: 300, 
          template: this.statusAssinatura,
          value: (obj: Assinante) => 'Pendente' 
        },
        { 
          property: 'validade', 
          title: 'Validade', 
          width: 300, 
          value: (obj: Assinante) => this.validadeAssinatura  
        },
        
        
      ];
      return colunas.map(coluna => {
        const builder = DscTableColumnBuilder.instance()
          .property(coluna.property)
          .title(coluna.title)
          .headerFixed(true)
          .width(coluna.width)
          .value(coluna.value);
  
        if (coluna.template) {
          builder.template(coluna.template);
        }
        if (coluna.bodyCellAlign) {
          builder.bodyCellAlign(coluna.bodyCellAlign);
        }
        return builder.build();
      });
    }

    private _criaColunasDocumentos() {
      const colunas: DscCustomTableColumn[] = [
        { 
          property: 'nome', 
          title: 'NOME', 
          width: 1000, 
          value: (obj: Assinante) => obj.nome
        },
        { 
          property: 'btnEditar', 
          title: 'Ações', 
          template: this.btnsEditarExcluirDocumentos, 
          bodyCellAlign: 'center', 
          width: 120 
        }
        
        
      ];
      return colunas.map(coluna => {
        const builder = DscTableColumnBuilder.instance()
          .property(coluna.property)
          .title(coluna.title)
          .headerFixed(true)
          .width(coluna.width)
          .value(coluna.value);
  
        if (coluna.template) {
          builder.template(coluna.template);
        }
        if (coluna.bodyCellAlign) {
          builder.bodyCellAlign(coluna.bodyCellAlign);
        }
        return builder.build();
      });
    }

    private _criaColunasResumoDocumentos() {
      const colunas: DscCustomTableColumn[] = [
        { 
          property: 'nome', 
          title: 'NOME', 
          width: 1000, 
          value: (obj: Assinante) => obj.nome
        },
        { 
          property: 'posicionarSelo', 
          title: 'Ações', 
          template: this.posicionarSelo, 
          bodyCellAlign: 'center', 
          width: 200 
        }
        
        
      ];
      return colunas.map(coluna => {
        const builder = DscTableColumnBuilder.instance()
          .property(coluna.property)
          .title(coluna.title)
          .headerFixed(true)
          .width(coluna.width)
          .value(coluna.value);
  
        if (coluna.template) {
          builder.template(coluna.template);
        }
        if (coluna.bodyCellAlign) {
          builder.bodyCellAlign(coluna.bodyCellAlign);
        }
        return builder.build();
      });
    }

    formatarData(data:any) {
       
       let dia = data.getDate();
       let mes = data.getMonth() + 1; // Os meses são indexados a partir de 0
       let ano = data.getFullYear();
      
       // Adicionar zero à esquerda se o dia ou mês for menor que 10
       dia = dia < 10 ? '0' + dia : dia;
       mes = mes < 10 ? '0' + mes : mes;
      
       return `${dia}/${mes}/${ano}`;
      }

/**
   * Inicializa os campos (FormControl) de cada FormGroup (divididos por etapa), e os anexa ao completeForm.
   */
  private _buildCompleteForm(): void {
    this.firstFormGroup = this._formBuilder.group({
      produto: [null],
      numeroContrato: [null],
  
    });
    this.completeForm.addControl('first', this.firstFormGroup);

    this.secondFormGroup = this._formBuilder.group({
      assinantes: this.assinantes,
      documentos: this.documentos,
      
    });
    this.completeForm.addControl('second', this.secondFormGroup);
  }

  /**
   * Define as etapas do Stepper, associando um formGroup e um template a cada uma.
   * 
   * A propriedade 'linear: true' impede que o usuário avance de etapa caso o formulário não esteja válido.
   */
  private _initStepperHorizontal(): void {
    this.stepperHorizontal = {
      selectedIndex: 0,
      linear: true,
      steps: [
        {
          label: 'Inclusão de Fluxo',
          formGroup: this.firstFormGroup,
          contentTemplate: this.firstStep
        },
        {
          label: 'Edição de Fluxo',
          formGroup: this.secondFormGroup,
          contentTemplate: this.secondStep
        },
        {
          label: 'Preparar Documento',
          formGroup: this.secondFormGroup,
          contentTemplate: this.thirdStep
        },
        {
          label: 'Enviar para Assinatura',
          formGroup: this.secondFormGroup,
          contentTemplate: this.thirdStep
        }
      ]
    };
  }

  /**
   * Método vinculado ao Output selectedIndexChange do DSC-Stepper.
   * 
   * É executado sempre que a etapa do Stepper é alterada.
   * @param index O novo selectedIndex do DSC-Stepper
   */
  public onSelectedIndexChange(index: number) {
    if (index === this.stepperHorizontal.steps.length - 1) {
      this.completeForm.updateValueAndValidity();

      if (this.completeForm.invalid) {
        this.messageService.showAlertMessage(
          'Formulário incompleto, favor verificar os campos obrigatórios', 'Erro', 'danger');
      } else {
        this.messageService.showAlertMessage(
          'Formulário concluído com sucesso!', 'Sucesso', 'success');
      }
    }
  }

  public isFormPassoAtualValid(): boolean {
    
    const passoAtual = this.stepperHorizontal.steps[Number(this.stepperHorizontal.selectedIndex) || 0];
    const formGroup = passoAtual.formGroup;
    return formGroup?.valid || false;
  }

  /**
   * Estabelece o tooltip do botão de Avançar, quando o formulário estiver inválido
   */
  public setTooltipFormAtual(): void {
    this.subscription.add(this.completeForm?.statusChanges.subscribe({
      next: (status: string) => {
        const isFormValid = this.isFormPassoAtualValid();
        const tooltip = isFormValid ? "" : "Há campos obrigatórios não preenchidos";
        this.tooltipFormAtual = tooltip;
      }
    }));
  }

  public formReset(ev: Event): void {
    this._loadingService.setIsCustomLoading(true);
    this.completeForm.reset();
    this.completeForm.markAsPristine();
    this.completeForm.markAsUntouched();
    this._initStepperHorizontal();

    // loading manual ate q a pagina seja renderizada novamente
    setTimeout(() => {
      this._loadingService.setIsCustomLoading(false);
    }, 1000);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }


}