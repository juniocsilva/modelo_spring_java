import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DscCrudModule } from 'src/app/shared/dsc-crud.module';
import { Option } from 'sidsc-components/dsc-select';
import { MatDialogRef } from '@angular/material/dialog';

import { MAT_DIALOG_DATA } from '@angular/material/dialog';

/**
 * Componente criado para isolar o formulário de criação/edição de itens
 */
@Component({
  selector: 'app-modal-assinante',
  templateUrl: './modal-alterar-assinante.component.html',
  styleUrls: ['./modal-alterar-assinante.component.scss'],
  standalone: true,
  imports: [CommonModule, DscCrudModule]
})
export class ModalAlterarAssinanteComponent {
  @Output() salvarEvent = new EventEmitter<FormGroup>();
  @Output() cancelarEvent = new EventEmitter<void>();

  public readonly BTN_SALVAR_TEXT = "Salvar";
  public readonly BTN_CANCELAR_TEXT = "Cancelar";

  public form = new FormGroup<any>({});

  public papeis: Option[] = [
    {
      label: 'Assinante', value: 'Assinante'
    },
    
  ];

  constructor(private dialogRef: MatDialogRef<ModalAlterarAssinanteComponent>, 
   @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.form = data.form
    this.form.controls['cpf'].disable()
    this.form.controls['nome'].disable()
  }

  public salvar(): void {
    this.salvarEvent.emit(this.form);
    this.cancelar()
  }

  public cancelar(): void {
    this.dialogRef.close()
  }

  public consultar(): void {
    
  }

}
