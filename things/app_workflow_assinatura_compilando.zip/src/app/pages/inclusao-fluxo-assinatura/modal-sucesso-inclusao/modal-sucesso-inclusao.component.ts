import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, Inject } from '@angular/core';
import { DscCrudModule } from 'src/app/shared/dsc-crud.module';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { InclusaoFluxoAssinaturaService } from '../inclusao-fluxo-assinatura.service';
import { LoadingService } from 'src/app/services/loading.service';

/**
 * Componente criado para isolar o formulário de criação/edição de itens
 */
@Component({
  selector: 'app-modal-sucesso-inclusao',
  templateUrl: './modal-sucesso-inclusao.component.html',
  styleUrls: ['./modal-sucesso-inclusao.component.scss'],
  standalone: true,
  imports: [CommonModule, DscCrudModule]
})
export class ModalSucessoInclusaoComponent {
  
  @Output() cancelarEvent = new EventEmitter<void>();

  public readonly BTN_CANCELAR_TEXT = "Fechar";
  public exibirMensagem = false
  public mensagemErro = ''
  public dados:any;


  constructor(private dialogRef: MatDialogRef<ModalSucessoInclusaoComponent>, 
    private readonly loadingService: LoadingService,

    private service: InclusaoFluxoAssinaturaService,
     @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.dados = data.dados
    console.log(data)
    
  }

  public cancelar(): void {
    this.dialogRef.close()
  }

}
