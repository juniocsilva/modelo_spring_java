import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable()
export class LoadingService {

  /**
   * Valor que define se o loading deverá aparecer ou não na tela
   * É atualizado no método 'setHasToShowLoading'
   */
  private readonly _hasToShowLoading = new BehaviorSubject<boolean>(false);
  public hasToShowLoading$ = this._hasToShowLoading.asObservable();

  /**
   * Indica se existe alguma requisição HTTP pendente
   * É tratado no arquivo request.interceptor.ts
   */
  private readonly _hasReqHttpPendente = new BehaviorSubject<boolean>(false);
  public _hasReqHttpPendente$ = this._hasReqHttpPendente.asObservable();

  /**
   * Indica se está mudando de rota
   * É tratado no arquivo app.component.ts
   */
  private readonly _isChangingRoute = new BehaviorSubject<boolean>(false);
  public isChangingRoute$ = this._isChangingRoute.asObservable();

  /**
   * Indicador customizado, para uso pontual em determinadas situações
   * É importante ter cuidado ao usar esse indicador, pois ele pode ser esquecido em true, travando a aplicação
   */
  private readonly _isCustomLoading = new BehaviorSubject<boolean>(false);
  public _isCustomLoading$ = this._isCustomLoading.asObservable();


  public setHasReqHttpPendente(status: boolean) {
    this._hasReqHttpPendente.next(status);
    this.setHasToShowLoading();
  }

  public setIsChangingRoute(status: boolean) {
    this._isChangingRoute.next(status);
    this.setHasToShowLoading();
  }

  public setIsCustomLoading(status: boolean) {
    this._isCustomLoading.next(status);
    this.setHasToShowLoading();
  }

  private setHasToShowLoading() {
    if (this._hasReqHttpPendente.value || this._isChangingRoute.value || this._isCustomLoading.value) {
      this._hasToShowLoading.next(true);
    } else {
      this._hasToShowLoading.next(false)
    }
  }

}
