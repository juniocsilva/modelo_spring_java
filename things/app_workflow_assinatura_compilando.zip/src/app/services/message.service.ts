import { Injectable, TemplateRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DscAlertVariant } from 'sidsc-components/dsc-alert';
import { DscDialogActionButton, DscDialogService } from 'sidsc-components/dsc-dialog';
import { DscSnackbarActionButton, DscSnackbarService } from 'sidsc-components/dsc-snackbar';
import { Utils } from '../utils/utils';
import { Logger } from '../utils/logger';

export interface AlertMessage {
    title: string,
    message: string,
    showIcon: boolean,
    variant: DscAlertVariant
}

/**
 * Serviço middleware que intermedia três tipos diferentes de mensageria, tornando suas implementações transparentes
 */
@Injectable({
  providedIn: 'root'
})
export class MessageService {

private readonly _defaultVariant: DscAlertVariant = "info";
private readonly _defaultType: "alert" | "snackbar" | "dialog" = "snackbar";

private readonly alertMessage = new BehaviorSubject<AlertMessage | null | undefined>(null);
public alertMessage$ = this.alertMessage.asObservable();

constructor(
  private readonly _snackbarService: DscSnackbarService,
  private readonly _dialogService: DscDialogService
) { }

  public show(message: string, 
              title: string = "", 
              type: "alert" | "snackbar" | "dialog" | 'dialog-template' = this._defaultType, 
              variant: DscAlertVariant = this._defaultVariant, 
              template?: TemplateRef<any>,
              button?: DscDialogActionButton | DscSnackbarActionButton,
              highlightVariant: boolean = false): void 
  {
    switch (type) {
      case "alert":
        this.showAlertMessage(message, title, variant);
        break;
      case "snackbar":
        this.showSnackbarMessage(message, variant, button as DscSnackbarActionButton);
        break;
      case "dialog":
        this.showDialogMessage(message, title, variant, button as DscDialogActionButton, highlightVariant);
        break;
      case "dialog-template":
        this.showDialogTemplate(message, title, template as TemplateRef<any>, variant, button as DscDialogActionButton, highlightVariant);
        break;
    }
  }

  public showAlertMessage(message: string, title: string, variant: DscAlertVariant): void {
    this.alertMessage.next({ title, message, showIcon: true, variant });
  }

  public showSnackbarMessage(message: string, variant: DscAlertVariant, snackbarActionButton?: DscSnackbarActionButton): void {
    this._snackbarService.add({
      data: { message, variant, showIcon: true, button: snackbarActionButton }
    });
  }

  public showDialogMessage(message: string, title: string, variant: DscAlertVariant, actionButton?: DscDialogActionButton, highlightVariant: boolean = false): void {
    this._dialogService.confirm({
      data: {
        title: {
          text: title,
          showCloseButton: true,
          highlightVariant,
          icon: Utils.getMaterialIconByVariant(variant)
        },
        message,
        actionButton
      }
    });
  }

  public showDialogTemplate(message: string, title: string, template: TemplateRef<any>, variant: DscAlertVariant, actionButton?: DscDialogActionButton, highlightVariant: boolean = false): void {
    this._dialogService.confirm({
      data: {
        title: {
          text: title || message,
          showCloseButton: true,
          highlightVariant,
          icon: Utils.getMaterialIconByVariant(variant)
        },
        template,
        actionButton
      }
    });
  }

  public showSucessoOperacao(mensagem: string, response?: any): void {
    Logger.info(mensagem, response);
    this.showSnackbarMessage(mensagem, 'success');
  }

  public showErroOperacao(mensagem: string, err: any, callback?: Function): void {
    Logger.error(mensagem, err);
    this.showSnackbarMessage(mensagem, 'danger');
    if (callback) callback();
  }

  public closeAllDialogs(): void {
    this._dialogService.dialog.closeAll();
  }

}
