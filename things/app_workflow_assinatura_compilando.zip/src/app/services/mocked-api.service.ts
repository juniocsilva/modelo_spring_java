import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { getJsonPlaceholderAPI } from "src/environments/environment.model";
import { Photo } from "../models/random-api-data.model";

/**
 * Simulação de chamadas a uma API real para alimentar a TabelaCrud
 */
@Injectable({
  providedIn: "root"
})
export class MockedApiService {

  private readonly API_URL;

  constructor(
    private readonly http: HttpClient,
  ) {
    /**
     * Use essa implementação num cenário real
     * */ 
    // this.API_URL = Utils.getApiUrlByAmbiente();
    
    this.API_URL = getJsonPlaceholderAPI();
  }

  // CRUD PHOTOS
  public listaFotos(): Observable<Photo[]> {     
    return this.http.get<Photo[]>(
      `${this.API_URL}/photos`
    );
  }

  public atualizaFoto(foto: Photo): Observable<null> {     
    return this.http.put<null>(
      `${this.API_URL}/photos/${foto.id}`, foto
    );
  }

  public criaFoto(foto: Photo): Observable<null> {     
    return this.http.post<null>(
      `${this.API_URL}/photos`, foto
    );
  }

  public deletaFoto(id: number): Observable<null> {     
    return this.http.delete<null>(
      `${this.API_URL}/photos/${id}`
    );
  }

}