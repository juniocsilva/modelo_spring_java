import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Observable, of } from 'rxjs';
import { KeycloakService, Tokens } from './keycloak-service/keycloak.service';
import { DecodedToken } from '../models/token.model';

export interface User {
  nome: string;
  email: string;
  matricula: string;
  roles: string[];
  unidade: string;
  sistema: string;
}

/**
 * Serviço que disponibiliza informações do token do usuário logado
 */
@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  /**
   * Objeto com propriedades padrão de um token decodificado
   */
  private _decodedToken: DecodedToken = {};

  /**
   * Observable com os dados do usuário logado
   */
  user$!: Observable<User>;


  constructor(
    private readonly keycloakService: KeycloakService
  ) {
    this.getToken();
  }

  public logout(): void {
    this.keycloakService.logout();
  }

  private getToken(): void {
    this.keycloakService.getTokens().then((tokens: Tokens) => {
      if (tokens.accessToken !== undefined && tokens.accessToken !== "") {
        this._decodedToken = new JwtHelperService().decodeToken(KeycloakService.keycloakAuth.token)!;

        const user: User = {
          nome: this._decodedToken.name!,
          email: this._decodedToken.email!,
          matricula: this._decodedToken.preferred_username!,
          roles: this._decodedToken.realm_access!.roles!,
          unidade: this._decodedToken["co-unidade"]!,
          sistema: this._decodedToken.azp!
        }
        this.user$ = of(user);
      }
    });
  }

}