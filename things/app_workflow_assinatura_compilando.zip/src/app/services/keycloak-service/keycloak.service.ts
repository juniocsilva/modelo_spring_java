/*
 * Copyright 2017 Red Hat, Inc. and/or its affiliates
 * and other contributors as indicated by the @author tags.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import {Injectable} from "@angular/core";
import * as Keycloak from "keycloak-js";
import { Observable } from "rxjs";
import { SessionStorageValues } from "src/app/models/enums/session-storage.enum";
import { environment } from "src/environments/environment";

// If using a local keycloak.js, uncomment this import.  With keycloak.js fetched
// from the server, you get a compile-time warning on use of the Keycloak()
// method below.  I'm not sure how to fix this, but it's certainly cleaner
// to get keycloak.js from the server.
//



@Injectable()
export class Tokens {
  public idToken!: string;
  public accessToken!: string;
}

@Injectable()
export class KeycloakService {
  static keycloakAuth: any;

  /**
   * Configure and initialize the Keycloak adapter.
   *
   * @param configOptions Optionally, a path to keycloak.json, or an object containing
   *                      url, realm, and clientId.
   * @returns {Promise<T>}
   */
  static init(
    configOptions?: string | {}
  ): Promise<any> {
    //@ts-ignore
    KeycloakService.keycloakAuth = new Keycloak(environment.ssoConfig);
    return KeycloakService.keycloakAuth.init(configOptions);
  }

  authenticated(): boolean {
    return KeycloakService.keycloakAuth.authenticated;
  }

  login(options?: any) {
    KeycloakService.keycloakAuth.login(options);
  }

  logout(redirectUri?: string) {
    KeycloakService.keycloakAuth.logout({redirectUri: redirectUri});
  }

  account() {
    KeycloakService.keycloakAuth.accountManagement();
  }

  authServerUrl(): string {
    return KeycloakService.keycloakAuth.authServerUrl;
  }

  realm(): string {
    return KeycloakService.keycloakAuth.realm;
  }

  getToken(): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      if (KeycloakService.keycloakAuth.token) {
        KeycloakService.keycloakAuth
          .updateToken(5)
          .then(() => {
            resolve(<string>KeycloakService.keycloakAuth.token);
          }, (error: any) => {
            console.error("Failed to refresh id token", error);
          });
      } else {
        console.error("Not loggen in");
      }
    });
  }

  getTokens(): Promise<Tokens> {
    return new Promise<Tokens>((resolve, reject) => {
      if (KeycloakService.keycloakAuth.idToken) {
        KeycloakService.keycloakAuth
          .updateToken(5)
          .then(() => {
            const tokens: Tokens = {
              accessToken: <string>KeycloakService.keycloakAuth.token,
              idToken: <string>KeycloakService.keycloakAuth.idToken
            };
            sessionStorage.setItem(SessionStorageValues.ACCESS_TOKEN, <string>KeycloakService.keycloakAuth.token);
            resolve(tokens);
          }, (error: any) => {
            console.error("Failed to refresh id token", error);
          });
      } else {
        console.error("Not loggen in");
      }
    });
  }

  refreshTokens(): Observable<Tokens> {
    return new Observable(observer => {

      if (KeycloakService.keycloakAuth.idToken) {
        KeycloakService.keycloakAuth
          .updateToken(5)
          .then(() => {
            const tokens: Tokens = {
              accessToken: <string>KeycloakService.keycloakAuth.token,
              idToken: <string>KeycloakService.keycloakAuth.idToken
            };
            sessionStorage.setItem(SessionStorageValues.ACCESS_TOKEN, <string>KeycloakService.keycloakAuth.token);
            observer.next(tokens);
          }, (error: any) => {
            console.error("Failed to refresh id token", error);
          });
      } else {
        console.error("Not loggen in");
      }
    });
  }

}
