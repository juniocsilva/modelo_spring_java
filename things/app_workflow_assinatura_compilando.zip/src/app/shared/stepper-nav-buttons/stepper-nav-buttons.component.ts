import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import { DscButtonComponent } from 'sidsc-components/dsc-button';
import { DscStepperModel } from 'sidsc-components/dsc-stepper';
import { DscTooltipModule } from 'sidsc-components/dsc-tooltip';

/**
 * Botões de navegação para o DSC-Stepper
 * 
 * Inclui 'voltar', 'avançar', 'concluir' e 'resetar'
 */
@Component({
  selector: 'app-stepper-nav-buttons',
  templateUrl: './stepper-nav-buttons.component.html',
  styleUrls: ['./stepper-nav-buttons.component.scss'],
  standalone: true,
  imports: [CommonModule, DscButtonComponent, DscTooltipModule]
})
export class StepperNavButtonsComponent {

  @Input() tooltipFormAtual = "";
  @Input() isFormPassoAtualValid = false;
  @Input() stepper: DscStepperModel | undefined | null;
  @Input() stepperForm: FormGroup | FormArray | undefined | null;
  @Output() formReset = new EventEmitter();

  constructor(
    private readonly _changeDetectorRef: ChangeDetectorRef
  ) { }

  public voltar(): void {
    if (!this.stepper) return;

    if (this.stepper?.selectedIndex != 0) {
      const stepAnterior = Number(this.stepper.selectedIndex) - 1;
      this.stepper.selectedIndex = stepAnterior;
      this._changeDetectorRef.markForCheck();
    }
  }

  public resetar(): void {
    if (!this.stepper) return;

    this.stepper.selectedIndex = 0;
    this.formReset.emit(true); 
  }

  public avancar(): void {
    if (!this.isFormPassoAtualValid || !this.stepper) return;

    const proximoStep = Number(this.stepper.selectedIndex) + 1;
    this.stepper.selectedIndex = proximoStep;
  }

  public isFirstStep(): boolean {
    if (!this.stepper?.steps?.length) return false;
    return this.stepper?.selectedIndex === 1;
  }

  public isSecondToThirdStep(): boolean {
    if (!this.stepper?.steps?.length) return false;
    const secondToThirdStep = this.stepper.steps.length - 3;
    return this.stepper?.selectedIndex === secondToThirdStep;
  }

  public isThirdToFourthdStep(): boolean {
    if (!this.stepper?.steps?.length) return false;
    const thirdToFourthStep = this.stepper.steps.length - 2;
    return this.stepper?.selectedIndex === thirdToFourthStep;
  }

  public isSecondToLastStep(): boolean {
    if (!this.stepper?.steps?.length) return false;
    const secondToLastStep = this.stepper.steps.length - 2;
    return this.stepper?.selectedIndex === secondToLastStep;
  }

  public isLastStep(): boolean {
    if (!this.stepper?.steps?.length) return false;
    const lastStep = this.stepper.steps.length - 1;
    return this.stepper?.selectedIndex === lastStep;
  }

}
