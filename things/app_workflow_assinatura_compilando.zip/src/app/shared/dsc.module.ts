import { NgModule } from "@angular/core"
import { CommonModule } from "@angular/common";

import { DscAccordionComponent } from "sidsc-components/dsc-accordion";
import { DscAlertComponent } from "sidsc-components/dsc-alert";
import { DscButtonComponent } from "sidsc-components/dsc-button";
import { DscInputFileComponent } from "sidsc-components/dsc-input-file"
import { DscInputComponent } from "sidsc-components/dsc-input"
import { DscCheckboxComponent } from "sidsc-components/dsc-checkbox";
import { DscSelectComponent } from "sidsc-components/dsc-select";
import { DscCardComponent } from "sidsc-components/dsc-card";
import { DscDatepickerComponent } from "sidsc-components/dsc-datepicker";
import { DscDialogModule } from "sidsc-components/dsc-dialog";
import { DscInputCurrencyComponent } from "sidsc-components/dsc-input-currency";
import { DscTextareaComponent } from "sidsc-components/dsc-textarea";
import { DscPaginatorComponent } from "sidsc-components/dsc-paginator";
import { DscRadioButtonComponent } from "sidsc-components/dsc-radio-button";
import { DscStepperComponent } from "sidsc-components/dsc-stepper";
import { DscSwitchComponent } from "sidsc-components/dsc-switch";
import { DscTabGroupComponent, DscTabComponent } from "sidsc-components/dsc-tab-group";
import { DscTooltipModule } from "sidsc-components/dsc-tooltip";
import { DscTableComponent } from "sidsc-components/dsc-table";
import { DscSnackbarModule } from 'sidsc-components/dsc-snackbar';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DscDialogModule,
    DscButtonComponent,
    DscInputFileComponent,
    DscInputComponent,
    DscAccordionComponent,
    DscCheckboxComponent,
    DscAlertComponent,
    DscSelectComponent,
    DscCardComponent,
    DscDatepickerComponent,
    DscInputCurrencyComponent,
    DscTextareaComponent,
    DscPaginatorComponent,
    DscRadioButtonComponent,
    DscStepperComponent,
    DscSwitchComponent,
    DscTabGroupComponent,
    DscTabComponent,
    DscTooltipModule,
    DscTableComponent,
    DscSnackbarModule
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    DscButtonComponent,
    DscInputFileComponent,
    DscInputComponent,
    DscAccordionComponent,
    DscCheckboxComponent,
    DscAlertComponent,
    DscSelectComponent,
    DscCardComponent,
    DscDatepickerComponent,
    DscInputCurrencyComponent,
    DscTextareaComponent,
    DscPaginatorComponent,
    DscRadioButtonComponent,
    DscStepperComponent,
    DscSwitchComponent,
    DscTabGroupComponent,
    DscTabComponent,
    DscTooltipModule,
    DscTableComponent,
    DscSnackbarModule
  ]
})
export class DscModule { }
