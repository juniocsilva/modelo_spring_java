import { Component, Input, OnInit } from '@angular/core';
import { appRoutes } from 'src/app/app.module';

/**
 * Cabeçalho padrão para as páginas que já preenche o título conforme definido na variável appRoutes do app.module
 */
@Component({
  selector: 'app-page-header',
  template: `
      <h1 class="head-huge-600 textcolor-secondary">{{ pageHeader }}</h1>
      <p>{{ pageDescription }}.</p>
  `,
  standalone: true
})
export class PageHeaderComponent implements OnInit {

  constructor() { }

  @Input() pageRoute = "";
  public pageHeader = "";
  public pageDescription = "";

  ngOnInit() {
    appRoutes.forEach(route => {
      if (!this.pageRoute) {
        this.pageHeader = "Início";
      } else if (route.path?.includes(this.pageRoute)) {
        //this.pageHeader = route.data?.['title'];
        //this.pageDescription = route.data?.['description'];
      }
    });
  }

}
