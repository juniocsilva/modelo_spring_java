import { CommonModule } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { DscProgressSpinnerComponent } from "sidsc-components/dsc-progress-spinner";
import { LoadingService } from "src/app/services/loading.service";

@Component({
  selector: "app-loading-caixa",
  templateUrl: "./loading-caixa.component.html",
  styleUrls: ["./loading-caixa.component.scss"],
  standalone: true,
  imports: [CommonModule, DscProgressSpinnerComponent]
})
export class LoadingCaixaComponent implements OnInit {

  public loading: boolean = false;
  public loading$ = new Observable<boolean>()

  constructor(
    private readonly loadingService: LoadingService
  ) { }

  ngOnInit() {
    this.loading$ = this.loadingService.hasToShowLoading$;
  }

}
