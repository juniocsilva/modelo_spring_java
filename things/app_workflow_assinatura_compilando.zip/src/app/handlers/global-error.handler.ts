import { HttpErrorResponse } from "@angular/common/http";
import { ErrorHandler, Injectable } from "@angular/core";
import { MessageService } from "../services/message.service";
import { Logger } from "../utils/logger";
import { AlertException } from "../models/custom-error.model";

/**
 * Captura qualquer Exception ocorrida na aplicação e loga no formato definido pelo Logger.
 * 
 * Caso a Exception seja do tipo customizado AlertException, este handler exibe um snackbar de erro com a mensagem da Exception.
 */
@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    constructor(
        private readonly _messageService: MessageService
    ) { }

    handleError(error: Error) {
        const name = error.name;
        let message = error.message;

        if (error instanceof HttpErrorResponse) {
            message = `${error.message}`;
        }

        Logger.error(message, name, error)

        if (error instanceof AlertException) {
            this._messageService.showSnackbarMessage(message, 'danger');
        }
    }

}
