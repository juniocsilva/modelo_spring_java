import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { DscMenu, DscSidenavComponent } from 'sidsc-components/dsc-sidenav';
import { appRoutes } from './app.module';
import { LoadingService } from './services/loading.service';
import { UserService } from './services/user.service';
import { DscBreadcrumbComponent, DscBreadcrumbItem } from 'sidsc-components/dsc-breadcrumb';
import { filter, map } from 'rxjs';
import { Utils } from './utils/utils';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  constructor(
    public readonly userService: UserService,
    private readonly _loadingService: LoadingService,
    private readonly _router: Router,
    private readonly _activatedRoute: ActivatedRoute
  ) { }

  @ViewChild('sidenav') sidenav: DscSidenavComponent | undefined;
  @ViewChild('breadcrumb') breadcrumb: DscBreadcrumbComponent | undefined;

  public title = 'Quickstart Angular DSC';
  public itemsMenuLateral: DscMenu[] = [];

  urls: DscBreadcrumbItem[] = [];

  ngOnInit(): void {
    this._router.navigate(['/']);
    this.setMenu();
    this.setBreadcrumbUrls();
    this.configLoadingOnRouteChange();
  }

  /**
   * Realiza o logout do usuário
   * 
   * Será exibida a tela de login do SSO/login.caixa
  */
  public logout(): void {
    this.userService.logout();
  }

  /**
   * Alterna o estado do menu lateral, entre expandido e recolhido
  */
  public toggleMenu(ev: any): void {
    if (this.sidenav) this.sidenav.opened = !this.sidenav.opened;
  }

  /**
   * Define os itens do menu lateral
   * 
   * Este método utiliza as rotas mapeadas no arquivo app.module.ts para criar os itens do menu lateral
   * Para funcionar corretamente o atributo data deve estar devidamente preenchido no objeto routes
  */
  private setMenu(): void {
    this.itemsMenuLateral = appRoutes.map(route => {
      if (route.path === "*") return {
        title: ""
      };

      return {
        title: route.data?.['title'] || '',
        url: route.path ? `/${route.path}` : '',
        icon: route.data?.['icon'],
        disabled: false
      }
    });

    this.itemsMenuLateral.push(
      {
        title: "Início",
        url: "/",
        icon: "home",
        disabled: false
      }
    );
    this.itemsMenuLateral = this.itemsMenuLateral
      .filter(item => item.title !== "")
      .sort((a, b) => {
        if (a.title == "Início") return -1;
        if (a.title.localeCompare(b.title)) return 1;
        return 1;
      });
  }

  private setBreadcrumbUrls(): void {
    this._router.events.pipe(
      filter(event => event instanceof NavigationEnd),
      map(() => Utils.buildBreadcrumb(this._activatedRoute.root))
    ).subscribe((breadcrumbs: DscBreadcrumbItem[]) => {
      this.urls = breadcrumbs;
      if (this.breadcrumb) {
        this.breadcrumb.urls = this.urls;
        this.breadcrumb?.ngOnInit();
      }
    });
  }

  /**
   * Configura o serviço de loading para exibir o ícone de carregamento quando a rota estiver mudando
   * 
   * No arquivo request.interceptor.ts é configurado o segundo aspecto do loading, quando uma requisição HTTP está pendente
   * Nesta configuração padrão da aplicação, o ícone de carregamento é exibido quando uma requisição HTTP está pendente ou quando a rota está mudando
  */
  private configLoadingOnRouteChange(): void {
    this._router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this._loadingService.setIsChangingRoute(true);
      }
      if (event instanceof NavigationEnd) {
        this._loadingService.setIsChangingRoute(false);
      }
    });
  }
}