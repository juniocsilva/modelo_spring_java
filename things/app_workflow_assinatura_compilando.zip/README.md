# Quickstart Angular DSC

Este projeto Quickstart oferece um template para novas aplicações SPA construídas em Angular com uso da biblioteca de componentes do SIDSC (Design.caixa).  
Alguns recursos presentes: 
- Integração com SSO;
- *User service* para gestão dos dados do token;
- Páginas prontas com casos de uso comuns, como tabelas interativas e formulários extensos;
- Controle automático de exibição de ícone de carregamento, considerando requisições HTTP pendentes e mudanças de rota;
- Breadcrumb, página inicial e menu lateral preenchidos automaticamente conforme rotas cadastradas;
- *Message Service* com opções de Snackbar, Dialog e Alert;
- Captura e tratamento global de exceptions;
- Interceptação de requisições HTTP;
- Entre outros!

## Instalação

Na pasta raiz do projeto (onde está o package.json), instalar normalmente.

```bash
npm install
```

## Utilização

Após a instalação, para rodar localmente em **http://localhost:4200**, executar qualquer um dos comandos abaixo.

```bash
npm start
```
```bash
ng serve
```
Para logar, utilize o usuário de testes do SIPNC:  
Login: c897998  
Senha: c897998

## Estrutura

Os componentes, serviços e demais recursos do projeto estão organizados em pastas conforme seu tipo (/pages, /services, /models, /handlers, etc.).  

Todas as páginas do app, incluindo o layout principal, foram construídas priorizando a implementação da [biblioteca do SIDSC](https://design.caixa/components/web-components). 

Alguns ajustes de estilo, presentes no arquivo *styles.scss*, e componentes adicionais, encontrados na pasta /shared, foram desenvolvidos para complementar o que ainda não está disponível na biblioteca.

## Notas e Orientações
- Os principais pontos do código estão comentados. Em caso de dúvidas, verifique se os comentários podem ajudar.
- A integração com o SSO foi realizada com o client-id do SIPNC (Plataforma.caixa). A alteração para o client de seu sistema deve ser feita nos arquivos *environment.ts*.
- Este projeto é apenas um template e não representa um modelo oficial que deve ser seguido. Seu propósito é facilitar e simplificar o trabalho das equipes que precisam construir novas soluções do zero, ou até mesmo refatorar alguma solução existente.
- Arquivos de teste (spec.ts) não estão inclusos.

## Contribuição

Sugestões, elogios e críticas são bem vindos.  
Favor entrar em contato com a equipe do Design.caixa / SIDSC pelo link: [https://design.caixa/support/questions-suggestions](https://design.caixa/support/questions-suggestions)

## Licença

[MIT](https://choosealicense.com/licenses/mit/)
