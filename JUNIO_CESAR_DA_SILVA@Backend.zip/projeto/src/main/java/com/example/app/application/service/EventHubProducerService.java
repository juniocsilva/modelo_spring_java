// src/main/java/com/example/app/integracao/EventHubProducerService.java
package com.example.app.application.service;

import com.azure.messaging.eventhubs.EventData;
import com.azure.messaging.eventhubs.EventDataBatch;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EventHubProducerService {

    private final EventHubProducerClient producerClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /** Envia uma simulação como JSON para o Event Hub. */
    public void grava(Object simulacao) {
        try {
            String payload = objectMapper.writeValueAsString(simulacao);

            // cria um batch e tenta adicionar o evento
            EventDataBatch batch = producerClient.createBatch();
            boolean added = batch.tryAdd(new EventData(payload));

            if (added) {
                producerClient.send(batch);
            } else {
                // fallback: se for grande demais p/ um batch, manda direto em lista
                producerClient.send(List.of(new EventData(payload)));
            }

            log.info("Simulação inserida no EventHub");
            log.debug("JSON gravado no EventHub: {}", payload);

        } catch (Exception e) {
            log.error("Não foi possível gravar no EventHub.", e);
            throw new RuntimeException("Falha ao enviar para Event Hub", e);
        }
    }
}
