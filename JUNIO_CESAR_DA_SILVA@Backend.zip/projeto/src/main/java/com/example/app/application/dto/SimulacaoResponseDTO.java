package com.example.app.application.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.*;

import java.math.BigDecimal;
import java.util.List;

import static com.fasterxml.jackson.annotation.JsonProperty.Access.READ_ONLY;

@Value @Builder
public class SimulacaoResponseDTO {
    @JsonProperty("idSimulacao")    Long idSimulacao;
    @JsonProperty("codigoProduto")  Integer codigoProduto;
    @JsonProperty("descricaoProduto") String descricaoProduto;
    @JsonProperty("taxaJuros")      BigDecimal taxaJuros; // fração (0.0179)
    @Singular("tabela")
    @JsonProperty("resultadoSimulacao") List<TabelaAmortizacaoDTO> resultadoSimulacao;
}
