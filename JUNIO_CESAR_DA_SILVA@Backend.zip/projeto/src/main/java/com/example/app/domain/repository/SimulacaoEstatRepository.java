package com.example.app.domain.repository;

import com.example.app.domain.model.SimulacaoEstatEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SimulacaoEstatRepository extends JpaRepository<SimulacaoEstatEntity, Long> { }

