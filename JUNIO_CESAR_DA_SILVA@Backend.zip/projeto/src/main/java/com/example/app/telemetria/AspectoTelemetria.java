package com.example.app.telemetria;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AspectoTelemetria {

    private final ApiRegistroTelemetria registry;

    @Around("@annotation(track)")
    public Object around(ProceedingJoinPoint pjp, TrilhaTelemetria track) throws Throwable {
        long start = System.nanoTime();
        boolean success = false;
        try {
            Object result = pjp.proceed();
            success = true; // chegamos a retornar (HTTP 200 na maior parte)
            return result;
        } catch (Throwable t) {
            // exceção → não-200 (vai para @ControllerAdvice com 4xx/5xx)
            throw t;
        } finally {
            long elapsed = System.nanoTime() - start;
            registry.record(track.name(), elapsed, success);
        }
    }
}

