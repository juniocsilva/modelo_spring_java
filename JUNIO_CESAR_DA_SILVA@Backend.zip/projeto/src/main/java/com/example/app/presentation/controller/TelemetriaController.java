package com.example.app.presentation.controller;


import com.example.app.application.dto.TelemetriaResponseDTO;
import com.example.app.application.service.TelemetriaService;
import com.example.app.application.service.TelemetriaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/telemetria")
public class TelemetriaController {

    private final TelemetriaService service;

    @GetMapping("/simulacoes")
    public ResponseEntity<TelemetriaResponseDTO> getTelemetriaSimulacoes() {
        return ResponseEntity.ok(service.obterTelemetriaSimulacoes());
    }
}

