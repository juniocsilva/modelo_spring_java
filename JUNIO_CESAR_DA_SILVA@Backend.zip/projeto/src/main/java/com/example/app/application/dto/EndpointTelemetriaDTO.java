package com.example.app.application.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

@Value
@Builder
public class EndpointTelemetriaDTO {
    @JsonProperty("nomeApi")          String nomeApi;
    @JsonProperty("qtdRequisicoes")   long qtdRequisicoes;
    @JsonProperty("tempoMedio")       long tempoMedio;      // ms
    @JsonProperty("tempoMinimo")      long tempoMinimo;     // ms
    @JsonProperty("tempoMaximo")      long tempoMaximo;     // ms
    @JsonProperty("percentualSucesso") BigDecimal percentualSucesso; // ex.: 0.98
}

