package com.example.app.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

import java.math.BigDecimal;

@Value
@Builder
public class ProdutoDTO {
	@JsonProperty("codigoProduto")
	Integer codigoProduto;

	@JsonProperty("descricaoProduto")
	String descricaoProduto;

	@JsonProperty("taxaJuros") // fração por período (ex.: 0.0179)
	BigDecimal taxaJuros;

	@JsonProperty("valorMin")
	BigDecimal valorMin;

	@JsonProperty("valorMax")
	BigDecimal valorMax;

	@JsonProperty("prazoMin")
	Integer prazoMin;

	@JsonProperty("prazoMax")
	Integer prazoMax;
}

