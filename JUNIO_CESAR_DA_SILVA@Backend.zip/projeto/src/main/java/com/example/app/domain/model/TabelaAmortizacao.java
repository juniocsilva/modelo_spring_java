package com.example.app.domain.model;

import java.util.List;

public record TabelaAmortizacao(
        String tipo,                // "SAC" | "PRICE"
        List<Parcela> parcelas
) {}

