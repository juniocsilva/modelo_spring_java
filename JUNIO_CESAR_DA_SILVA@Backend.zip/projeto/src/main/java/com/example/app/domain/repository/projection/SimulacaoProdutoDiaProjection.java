// src/main/java/com/example/app/domain/repository/projection/SimulacaoProdutoDiaProjection.java
package com.example.app.domain.repository.projection;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface SimulacaoProdutoDiaProjection {
    Integer    getCodigoProduto();
    String     getDescricaoProduto();
    BigDecimal getTaxaMediaJuro();
    BigDecimal getValorMedioPrestacao();
    BigDecimal getValorTotalDesejado();
    BigDecimal getValorTotalCredito();
}
