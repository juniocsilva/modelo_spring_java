package com.example.app.telemetria;


import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;

@Component
public class ApiRegistroTelemetria {

    private final Map<String, Stats> byName = new ConcurrentHashMap<>();

    public void record(String apiName, long durationNanos, boolean success) {
        byName.computeIfAbsent(apiName, k -> new Stats()).record(durationNanos, success);
    }

    public Snapshot snapshot(String apiName) {
        Stats s = byName.get(apiName);
        return s == null ? Snapshot.empty(apiName) : s.toSnapshot(apiName);
    }

    public Snapshot[] snapshotAll() {
        return byName.entrySet().stream()
                .map(e -> e.getValue().toSnapshot(e.getKey()))
                .sorted((a,b) -> a.nomeApi().compareToIgnoreCase(b.nomeApi()))
                .toArray(Snapshot[]::new);
    }

    // ----- tipos internos -----

    public record Snapshot(
            String nomeApi,
            long qtdRequisicoes,
            long tempoMedioMs,
            long tempoMinimoMs,
            long tempoMaximoMs,
            BigDecimal percentualSucesso
    ) {
        static Snapshot empty(String name) {
            return new Snapshot(name, 0, 0, 0, 0, BigDecimal.ZERO.setScale(2));
        }
    }

    private static final class Stats {
        private final LongAdder total = new LongAdder();
        private final LongAdder success = new LongAdder();
        private final LongAdder totalNanos = new LongAdder();
        private final AtomicLong minNanos = new AtomicLong(Long.MAX_VALUE);
        private final AtomicLong maxNanos = new AtomicLong(0L);

        void record(long nanos, boolean ok) {
            total.increment();
            if (ok) success.increment();
            totalNanos.add(nanos);
            updateMin(nanos);
            updateMax(nanos);
        }

        Snapshot toSnapshot(String name) {
            long cnt = total.sum();
            if (cnt == 0) {
                return Snapshot.empty(name);
            }
            long avgMs = Math.round((double) totalNanos.sum() / cnt / 1_000_000.0);
            long minMs = Math.round(minNanos.get() / 1_000_000.0);
            long maxMs = Math.round(maxNanos.get() / 1_000_000.0);
            BigDecimal pct = BigDecimal.valueOf(success.doubleValue() / cnt)
                    .setScale(2, RoundingMode.HALF_UP);
            return new Snapshot(name, cnt, avgMs, minMs, maxMs, pct);
        }

        private void updateMin(long nanos) {
            long prev;
            do {
                prev = minNanos.get();
                if (nanos >= prev) return;
            } while (!minNanos.compareAndSet(prev, nanos));
        }

        private void updateMax(long nanos) {
            long prev;
            do {
                prev = maxNanos.get();
                if (nanos <= prev) return;
            } while (!maxNanos.compareAndSet(prev, nanos));
        }
    }
}

