package com.example.app.application.service;

import com.example.app.application.dto.*;
import com.example.app.domain.model.TipoTabela;
import com.example.app.domain.model.SimulacaoEntity;
import com.example.app.domain.model.SimulacaoParcelaEntity;
import com.example.app.domain.model.SimulacaoResultadoEntity;
import com.example.app.domain.repository.SimulacaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SimulacaoConsultaService {

    private final SimulacaoRepository simulacaoRepo;

    public EstatisticaPageDTO listar(int pagina1Based, int tamanho, String ordenarPor, String direcao) {
        int pagina = Math.max(1, pagina1Based);
        int size   = Math.max(1, tamanho);

        Sort sort = "desc".equalsIgnoreCase(direcao)
                ? Sort.by(ordenarPor).descending()
                : Sort.by(ordenarPor).ascending();

        Pageable pageable = PageRequest.of(pagina - 1, size, sort);

        Page<SimulacaoEntity> page = simulacaoRepo.findAll(pageable);

        List<EstatRegistroDTO> itens = page.getContent().stream()
                .map(this::toResumo)
                .toList();

        return EstatisticaPageDTO.builder()
                .pagina(pagina)
                .qtdRegistros(page.getTotalElements())
                .qtdRegistrosPagina(page.getNumberOfElements())
                .registros(itens)
                .build();
    }

    private EstatRegistroDTO toResumo(SimulacaoEntity sim) {
        // 1) escolher o resultado (PRICE preferencial)
        Optional<SimulacaoResultadoEntity> price = sim.getResultados() == null ? Optional.empty()
                : sim.getResultados().stream()
                .filter(r -> r.getTipo() == TipoTabela.PRICE)
                .findFirst();

        SimulacaoResultadoEntity escolhido = price.orElseGet(() ->
                (sim.getResultados() == null ? List.<SimulacaoResultadoEntity>of() : sim.getResultados())
                        .stream()
                        .min(Comparator.comparing(r -> r.getTipo().name()))
                        .orElse(null)
        );

        // 2) somar prestações do resultado escolhido (se houver)
        BigDecimal totalPrest = BigDecimal.ZERO;
        if (escolhido != null && escolhido.getParcelas() != null && !escolhido.getParcelas().isEmpty()) {
            for (SimulacaoParcelaEntity p : escolhido.getParcelas()) {
                totalPrest = totalPrest.add(nvl(p.getValorPrestacao()));
            }
        }

        // 3) usar valorDesejado e prazo DIRETAMENTE da entidade raiz
        return EstatRegistroDTO.builder()
                .idSimulacao(sim.getIdSimulacao())
                .valorDesejado(nvl(sim.getValorDesejado()))
                .prazo(sim.getPrazo() == null ? 0 : sim.getPrazo())
                .valorTotalParcelas(totalPrest)
                .build();
    }

    private static BigDecimal nvl(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }
}
