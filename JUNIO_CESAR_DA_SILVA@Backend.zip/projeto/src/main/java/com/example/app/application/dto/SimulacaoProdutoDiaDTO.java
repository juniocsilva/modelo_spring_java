// src/main/java/com/example/app/application/dto/SimulacaoProdutoDiaDTO.java
package com.example.app.application.dto;

import lombok.*;
import java.math.BigDecimal;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SimulacaoProdutoDiaDTO {
    private Integer codigoProduto;
    private String  descricaoProduto;
    private BigDecimal taxaMediaJuro;       // média de SIMULACAO.TAXA_JUROS
    private BigDecimal valorMedioPrestacao; // média de SIMULACAO_PARCELA.VALOR_PRESTACAO
    private BigDecimal valorTotalDesejado;  // soma de SIMULACAO.VALOR_DESEJADO
    private BigDecimal valorTotalCredito;   // soma de SIMULACAO_PARCELA.VALOR_PRESTACAO
}
