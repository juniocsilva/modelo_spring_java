package com.example.app.domain.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static jakarta.persistence.CascadeType.ALL;
import static jakarta.persistence.FetchType.LAZY;

@Entity
@Table(name = "SIMULACAO", schema = "dbo")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class SimulacaoEntity {

    @Id
    @Column(name = "ID_SIMULACAO", nullable = false)
    @EqualsAndHashCode.Include
    private Long idSimulacao;

    @Column(name = "CODIGO_PRODUTO", nullable = false)
    private Integer codigoProduto;

    @Column(name = "DESCRICAO_PRODUTO", nullable = false, length = 200)
    private String descricaoProduto;

    @Column(name = "TAXA_JUROS", nullable = false, precision = 12, scale = 9)
    private BigDecimal taxaJuros;

    @Column(name = "CRIADO_EM", insertable = false, updatable = false)
    @Generated(GenerationTime.INSERT)
    private LocalDateTime criadoEm;

    @Column(name = "VALOR_DESEJADO", precision = 18, scale = 2)
    private BigDecimal valorDesejado;

    @Column(name = "PRAZO")
    private Integer prazo;

    @OneToMany(mappedBy = "simulacao",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.LAZY)
    @Builder.Default
    private List<SimulacaoResultadoEntity> resultados = new ArrayList<>();

    public void addResultado(SimulacaoResultadoEntity r) {
        if (resultados == null) resultados = new ArrayList<>();
        r.setSimulacao(this);
        resultados.add(r);
    }
}
