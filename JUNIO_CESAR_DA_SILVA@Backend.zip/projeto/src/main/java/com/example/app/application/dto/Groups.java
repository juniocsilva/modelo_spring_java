package com.example.app.application.dto;

public interface Groups {
    public interface FabricanteId {}
}
