package com.example.app.presentation.controller;

import com.example.app.application.dto.SimulacaoRequestDTO;
import com.example.app.application.dto.SimulacaoResponseDTO;
import com.example.app.application.exception.EntidadeNaoEncontradaException;
import com.example.app.application.service.SimulacaoService;
import com.example.app.telemetria.TrilhaTelemetria;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/simulacao")
public class SimulacaoController {

    @Autowired
    private SimulacaoService simulacaoService;

    @TrilhaTelemetria(name = "Simulacao")
    @PostMapping("/simular")
    public ResponseEntity<SimulacaoResponseDTO> buscar(@Valid @RequestBody SimulacaoRequestDTO req) {

        return ResponseEntity.ok(simulacaoService.simular(req));

    }

    @GetMapping("/{id}")
    public ResponseEntity<SimulacaoResponseDTO> obterPorId(@PathVariable("id") Long id) {
        try {
            return ResponseEntity.ok(simulacaoService.obterDetalhe(id));
        } catch (EntidadeNaoEncontradaException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
