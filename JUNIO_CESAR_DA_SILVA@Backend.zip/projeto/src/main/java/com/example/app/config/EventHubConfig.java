// src/main/java/com/example/app/config/EventHubConfig.java
package com.example.app.config;

import com.azure.messaging.eventhubs.EventHubClientBuilder;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EventHubConfig {

    @Value("${eh.string.conexao}")
    private String connectionString;

    @Value("${eh.nome:}")
    private String eventHubName;

    @Bean
    public EventHubProducerClient eventHubProducerClient() {
        EventHubClientBuilder builder = new EventHubClientBuilder();

        // Se a connection string já inclui EntityPath=, não precisa do nome.
        if (eventHubName != null && !eventHubName.isBlank()) {
            return builder.connectionString(connectionString, eventHubName)
                    .buildProducerClient();
        }
        return builder.connectionString(connectionString)
                .buildProducerClient();
    }
}
