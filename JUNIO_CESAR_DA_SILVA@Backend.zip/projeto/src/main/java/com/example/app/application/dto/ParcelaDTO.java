package com.example.app.application.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.*;

import java.math.BigDecimal;

import static com.fasterxml.jackson.annotation.JsonProperty.Access.READ_ONLY;

@Value @Builder
public class ParcelaDTO {
    @JsonProperty("numero") Integer numero;
    @JsonProperty("valorAmortizacao") @JsonSerialize(using = DuasCasasSerializer.class) BigDecimal valorAmortizacao;
    @JsonProperty("valorJuros")       @JsonSerialize(using = DuasCasasSerializer.class) BigDecimal valorJuros;
    @JsonProperty("valorPrestacao")   @JsonSerialize(using = DuasCasasSerializer.class) BigDecimal valorPrestacao;
}
