package com.example.app.domain.model;

public enum TipoTabela {
    SAC, PRICE
}
