package com.example.app.domain.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

import static jakarta.persistence.CascadeType.ALL;
import static jakarta.persistence.FetchType.LAZY;

@Entity
@Table(name = "SIMULACAO_RESULTADO", schema = "dbo")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class SimulacaoResultadoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_RESULTADO")
    @EqualsAndHashCode.Include
    private Long idResultado;

    @ManyToOne(fetch = LAZY, optional = false)
    @JoinColumn(name = "ID_SIMULACAO", nullable = false)
    private SimulacaoEntity simulacao;

    @Enumerated(EnumType.STRING)
    @Column(name = "TIPO", nullable = false, length = 16)
    private TipoTabela tipo;

    @OneToMany(mappedBy = "resultado",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    @Builder.Default
    private List<SimulacaoParcelaEntity> parcelas = new ArrayList<>();

    public void addParcela(SimulacaoParcelaEntity p) {
        if (parcelas == null) parcelas = new ArrayList<>();
        p.setResultado(this);
        parcelas.add(p);
    }
}
