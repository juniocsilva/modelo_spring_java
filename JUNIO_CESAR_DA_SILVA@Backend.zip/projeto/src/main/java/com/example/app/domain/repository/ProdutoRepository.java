package com.example.app.domain.repository;

import com.example.app.domain.model.ProdutoEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.*;

public interface ProdutoRepository extends JpaRepository<ProdutoEntity, Integer> {

    @Query("""
        select p
          from ProdutoEntity p
         where :valor between coalesce(p.valorMinimo, :valor) and coalesce(p.valorMaximo, :valor)
           and :prazo between coalesce(p.minimoMeses, :prazo) and coalesce(p.maximoMeses, :prazo)
         order by p.taxaJuros asc
    """)
    List<ProdutoEntity> findMatches(@Param("valor") BigDecimal valor,
                                    @Param("prazo") Integer prazo);

    default Optional<ProdutoEntity> findMatch(BigDecimal valor, Integer prazo) {
        return findMatches(valor, prazo).stream().findFirst();
    }
}
