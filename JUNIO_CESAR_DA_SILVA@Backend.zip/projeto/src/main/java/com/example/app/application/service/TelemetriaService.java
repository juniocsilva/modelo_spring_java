package com.example.app.application.service;

import com.example.app.application.dto.EndpointTelemetriaDTO;
import com.example.app.application.dto.TelemetriaResponseDTO;
import com.example.app.telemetria.ApiRegistroTelemetria;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;

@Service
@RequiredArgsConstructor
public class TelemetriaService {

    private static final ZoneId ZONE = ZoneId.of("America/Sao_Paulo");

    private final ApiRegistroTelemetria registry;

    public TelemetriaResponseDTO obterTelemetriaSimulacoes() {
        var snap = registry.snapshot("Simulacao");
        var endpoint = EndpointTelemetriaDTO.builder()
                .nomeApi(snap.nomeApi())
                .qtdRequisicoes(snap.qtdRequisicoes())
                .tempoMedio(snap.tempoMedioMs())
                .tempoMinimo(snap.tempoMinimoMs())
                .tempoMaximo(snap.tempoMaximoMs())
                .percentualSucesso(snap.percentualSucesso())
                .build();

        return TelemetriaResponseDTO.builder()
                .dataReferencia(LocalDate.now(ZONE))
                .listaEndpoints(Arrays.asList(endpoint))
                .build();
    }
}
