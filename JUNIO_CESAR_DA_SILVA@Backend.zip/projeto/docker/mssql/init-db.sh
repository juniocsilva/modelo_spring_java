#!/usr/bin/env bash
set -euo pipefail

# detecta sqlcmd 18 (novo) ou 17 (antigo)
SQLCMD="/opt/mssql-tools18/bin/sqlcmd"
if [ ! -x "$SQLCMD" ]; then
  SQLCMD="/opt/mssql-tools/bin/sqlcmd"
fi

echo "[init-db] aguardando SQL Server aceitar conexões..."
for i in {1..180}; do
  if [ -x "$SQLCMD" ]; then
    # -C para confiar no cert self-signed
    if "$SQLCMD" -S localhost -U sa -P "$SA_PASSWORD" -C -Q "SELECT 1" &>/dev/null; then
      echo "[init-db] SQL Server pronto."
      break
    fi
  else
    # fallback: porta aberta
    if (echo >/dev/tcp/127.0.0.1/1433) &>/dev/null; then
      echo "[init-db] porta 1433 aberta."
      break
    fi
  fi
  sleep 2
done

echo "[init-db] criando database 'hack' se não existir..."
if [ -x "$SQLCMD" ]; then
  "$SQLCMD" -S localhost -U sa -P "$SA_PASSWORD" -C -Q "IF DB_ID('hack') IS NULL CREATE DATABASE hack;"
else
  echo "[init-db] sqlcmd não encontrado; a aplicação criará objetos (schema) ao conectar."
fi
echo "[init-db] ok."
