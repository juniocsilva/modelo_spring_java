package br.gov.caixa.siidx.config;



import io.quarkus.runtime.Startup;
import jakarta.annotation.PostConstruct;
import jakarta.inject.Singleton;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

@Startup
@Singleton
public class PdfBoxWarmUp {
    @PostConstruct
    void warm() {
        try {
            new PDType1Font(Standard14Fonts.FontName.HELVETICA).getEncoding();
            new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD).getEncoding();
            // adicione outras se usar
        } catch (Exception e) {
            //throw new IllegalStateException("Falha ao pré-aquecer fontes PDFBox", e);
        }
    }
}