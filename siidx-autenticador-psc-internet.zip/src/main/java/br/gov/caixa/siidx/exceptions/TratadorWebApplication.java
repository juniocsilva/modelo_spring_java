package br.gov.caixa.siidx.exceptions;

import br.gov.caixa.siidx.exceptions.dto.RetornoErroDTO;
import br.gov.caixa.siidx.exceptions.enums.ErrosComunsEnum;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import lombok.extern.slf4j.Slf4j;

/**
 * Mapper para tratar exceptions em chamadas a APIs. Faz log do máximo de informação possível dos
 * problemas e retorna uma mensagem mais amigável.
 * 
 * @author c134596
 *
 */
// @Provider
@Slf4j
public class TratadorWebApplication implements ExceptionMapper<WebApplicationException> {
    @Override
    public Response toResponse(WebApplicationException exc) {
        return tratarWebApplicationException(exc);
    }

    static Response tratarWebApplicationException(WebApplicationException exc) {
        // log.error("Erro WebApplicationException", exc);
        if (exc instanceof NotFoundException) {
            return Response.status(ErrosComunsEnum.NOT_FOUND.getStatus())
                    .entity(new RetornoErroDTO(ErrosComunsEnum.NOT_FOUND)).build();
        }
        if (exc.getCause() instanceof JsonParseException
                || exc.getCause() instanceof JsonMappingException) {
            return Response.status(ErrosComunsEnum.ERRO_EM_PARSE.getStatus())
                    .entity(new RetornoErroDTO(ErrosComunsEnum.ERRO_EM_PARSE)).build();
        }

        throw exc;


    }

}
