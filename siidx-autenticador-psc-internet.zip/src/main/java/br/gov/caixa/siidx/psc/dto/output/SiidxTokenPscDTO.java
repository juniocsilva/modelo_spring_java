package br.gov.caixa.siidx.psc.dto.output;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SiidxTokenPscDTO {
    private String token;
}
