package br.gov.caixa.siidx.psc.resources.impl;


import br.gov.caixa.siidx.psc.dto.input.MensagemDTO;
import br.gov.caixa.siidx.psc.utilitarios.Util;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
@Path("/api/util")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UtilResourceImpl {

    @ConfigProperty(name = "secret_dados_token_siidx")
    String secret_dados_token;

    @POST
    @Path("/encripta")
    public Response encripta(MensagemDTO mensagem) throws Exception {
        String cripto = Util.encrypt(mensagem.getMensagem(), secret_dados_token);
        MensagemDTO retorno = new MensagemDTO();
        retorno.setMensagem(cripto);
        return Response
                .status(Response.Status.OK)
                .entity(retorno)
                .build();
    }

    @POST
    @Path("/desencripta")
    public Response desencripta(MensagemDTO mensagem) throws Exception {
        String cripto = Util.decrypt(mensagem.getMensagem(), secret_dados_token);
        MensagemDTO retorno = new MensagemDTO();
        retorno.setMensagem(cripto);
        return Response
                .status(Response.Status.OK)
                .entity(retorno)
                .build();
    }
}
