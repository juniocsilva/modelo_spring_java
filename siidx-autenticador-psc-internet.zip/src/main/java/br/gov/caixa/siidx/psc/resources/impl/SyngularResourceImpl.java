package br.gov.caixa.siidx.psc.resources.impl;

import br.gov.caixa.siidx.exceptions.dto.MensagemErroDTO;
import br.gov.caixa.siidx.psc.dto.input.SolicitaTokenDTO;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import br.gov.caixa.siidx.psc.resources.SyngularResource;
import br.gov.caixa.siidx.psc.service.SyngularService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;

@Slf4j
@ApplicationScoped
@Path("/api/syngular")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SyngularResourceImpl implements SyngularResource {

	@Inject
	private SyngularService service;

	@POST
	@Path("/token")
	@Operation(summary = "End point utilizado para obtenção do token de acesso a Syngular")
	@APIResponse(responseCode = "200", description = "Token de Acesso recuperado com sucesso.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = SiidxTokenPscDTO.class)))
	@APIResponse(responseCode = "400", description = "Parâmetros informados estão inválidos.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MensagemErroDTO.class)))

	public Response getToken(SolicitaTokenDTO corpo) {
		log.warn(corpo.toString());
		SiidxTokenPscDTO siidxTokenPscDTO = service.getToken(corpo.getCode(), corpo.getCode_verifier());
		return Response
				.status(Response.Status.OK)
				.entity(siidxTokenPscDTO)
				.build();

 	}
}
