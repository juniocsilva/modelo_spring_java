package br.gov.caixa.siidx.pdfsign.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SerproIdHashesDTO {
    private String id;
    private String alias;
    private String hash;
    private String hash_algorithm;
    private String signature_format;
}
