package br.gov.caixa.siidx.pdfsign.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SolicitaTokenItiDTO {
	String code;
}
