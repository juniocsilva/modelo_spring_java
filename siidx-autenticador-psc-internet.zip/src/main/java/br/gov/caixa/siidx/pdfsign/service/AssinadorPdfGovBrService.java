package br.gov.caixa.siidx.pdfsign.service;

import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

public interface AssinadorPdfGovBrService {

    public byte [] assinar (MultipartFormDataInput pdf) throws Exception;
    public SiidxTokenPscDTO getTokenIti(String code) throws Exception;
}
