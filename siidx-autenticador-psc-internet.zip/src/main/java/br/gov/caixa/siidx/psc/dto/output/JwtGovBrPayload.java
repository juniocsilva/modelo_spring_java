package br.gov.caixa.siidx.psc.dto.output;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JwtGovBrPayload {
    private String aud;
    private String sub;
    private String [] scope;
    private String [] amr;
    private String iss;
    private String preferred_username;
    private long exp;
    private long iat;
    private String jti;
}
