package br.gov.caixa.siidx.pdfsign.resources.impl;

import br.gov.caixa.siidx.exceptions.dto.MensagemErroDTO;
import br.gov.caixa.siidx.pdfsign.dto.PdfAssinadoDTO;
import br.gov.caixa.siidx.pdfsign.dto.SolicitaTokenItiDTO;
import br.gov.caixa.siidx.pdfsign.resources.AssinadorPdfGovBrResource;
import br.gov.caixa.siidx.pdfsign.service.AssinadorPdfGovBrService;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

@Slf4j
@ApplicationScoped
@Path("/api/assinador/govbr")
public class AssinadorPdfGovBrResourceImpl implements AssinadorPdfGovBrResource {

    @Inject
    private AssinadorPdfGovBrService servico;





    @POST
    @Path("/assinar")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces("application/json")
    @Operation(summary = "End point utilizado para fazer assinatura em pdf no gov.br")
    @APIResponse(responseCode = "200", description = "Assinatura realizada com sucesso.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = SiidxTokenPscDTO.class)))
    @APIResponse(responseCode = "400", description = "Parâmetros informados estão inválidos.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MensagemErroDTO.class)))

    public Response assinaGovBr(MultipartFormDataInput  corpo) throws Exception {
        //SiidxTokenPscDTO siidxTokenPscDTO = service.getToken(corpo.getCode(), corpo.getCode_verifier());
        byte [] pdfAssinado = servico.assinar(corpo);
        PdfAssinadoDTO pdfAssinadoDTO = new PdfAssinadoDTO();
        pdfAssinadoDTO.setConteudo(Base64.encodeBase64String(pdfAssinado));
        pdfAssinadoDTO.setNome("documento-assinado.pdf");
        return Response
                .ok(pdfAssinadoDTO)
                //.type("application/pdf")
                //.header("Content-Disposition", "attachment; filename=\"documento-assinado.pdf\"")
                .build();
    }

    @POST
    @Path("/token")
    @Consumes(MediaType.APPLICATION_JSON)
    @Operation(summary = "End point utilizado para obter o token de assinatura no ITI")
    @APIResponse(responseCode = "200", description = "Assinatura realizada com sucesso.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = SiidxTokenPscDTO.class)))
    @APIResponse(responseCode = "400", description = "Parâmetros informados estão inválidos.", content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = MensagemErroDTO.class)))

    public Response getTokenIti(@NotNull SolicitaTokenItiDTO corpo) throws Exception {
        SiidxTokenPscDTO siidxTokenPscDTO = servico.getTokenIti(corpo.getCode());
        return Response
                .status(Response.Status.OK)
                .entity(siidxTokenPscDTO)
                .build();

    }
}


