package br.gov.caixa.siidx.exceptions.enums;

import br.gov.caixa.siidx.exceptions.ErrosComunsInterface;
import br.gov.caixa.siidx.exceptions.dto.RetornoErroDTO;
import jakarta.ws.rs.core.Response;

public enum ErrosComunsEnum implements ErrosComunsInterface {
    NOT_FOUND("Endereço não existe", Response.Status.NOT_FOUND, "404", ErroNiveisEnum.INFO),
    ERRO_INTERNO_SERVIDOR("O servidor apresesentou um problema. Tente novamente mais tarde.", Response.Status.INTERNAL_SERVER_ERROR, "IDX_ARQ_0000", ErroNiveisEnum.ERRO),
    ERRO_AUTENTICACAO_USUARIO("Não foi possível fazer a autenticação do usuario.", Response.Status.UNAUTHORIZED, "IDX_PSC_0001", ErroNiveisEnum.ERRO),
    ERRO_ASSINATURA_DIGITAL("Não foi possível fazer a assinatura digital deste documento.", Response.Status.BAD_REQUEST, "IDX_SIGN_0001", ErroNiveisEnum.ERRO),
    ERRO_VALIDACAO_TOKEN("O token enviado é inválido.", Response.Status.BAD_REQUEST, "IDX_TOKEN_0001", ErroNiveisEnum.ERRO),
    ERRO_EM_CAMPOS("Erro em campos", Response.Status.BAD_REQUEST, "IDX_ARQ_0001", ErroNiveisEnum.WARN),
    ERRO_EM_TOKEN("Erro em token", Response.Status.BAD_REQUEST, "IDX_ARQ_0002", ErroNiveisEnum.WARN),	
    CONSULTA_NAO_RETORNOU_RESULTADOS("Nenhum registro encontrado.", Response.Status.NOT_FOUND, "IDX_ARQ_0003", ErroNiveisEnum.INFO),
    BUSCAR_DADOS("Não foi possível buscar os dados do Certificado", Response.Status.INTERNAL_SERVER_ERROR, "IDX_ARQ_0004", ErroNiveisEnum.ERRO), 
    ERRO_EM_PARSE("Erro ao fazer o parse do JSON", Response.Status.BAD_REQUEST, "IDX_ARQ_0005", ErroNiveisEnum.WARN),
    ERRO_NA_GRAVACAO("Erro ao gravar o arquivo", Response.Status.INTERNAL_SERVER_ERROR, "IDX_ARQ_0006", ErroNiveisEnum.ERRO),
    ERRO_NA_GRAVACAO_BLOB("Erro ao gravar o arquivo no Blob", Response.Status.INTERNAL_SERVER_ERROR, "IDX_ARQ_0007", ErroNiveisEnum.ERRO),
    AZURE_URL_INVALIDA("URL inválida para renovação", Response.Status.BAD_REQUEST, "IDX_ARQ_0008", ErroNiveisEnum.WARN),
    AZURE_ARQUIVO_NAO_ENCONTRADO("Arquivo não encontrado", Response.Status.NOT_FOUND, "IDX_ARQ_0009", ErroNiveisEnum.INFO),
    AZURE_FALHA_AO_MOVIMENTAR("Falha ao movimentar o arquivo", Response.Status.INTERNAL_SERVER_ERROR, "IDX_ARQ_0010", ErroNiveisEnum.ERRO),
    ;
    
    private final String mensagens;
    private final Response.Status status;
    private final String id;
    private final String nivel;
    
    ErrosComunsEnum(String mensagem, Response.Status status, String id, ErroNiveisEnum nivel) {
        this.mensagens = mensagem;
        this.status = status;
        this.id = id;
        this.nivel = nivel.getNivel();
    }

    @Override
    public Response.Status getStatus() {
        return this.status;
    }

    @Override
    public String getMensagens() {
        return this.mensagens;
    }

    @Override
    public String getId() {
        return this.id;
    }

    @Override
    public String getNivel() {
        return this.nivel;
    }

    @Override
    public Response response() {
        return Response.status(this.getStatus())
                .entity(new RetornoErroDTO(this))
                .build();
    }
    
}