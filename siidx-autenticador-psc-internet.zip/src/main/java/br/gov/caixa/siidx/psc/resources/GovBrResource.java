package br.gov.caixa.siidx.psc.resources;

import br.gov.caixa.siidx.psc.dto.input.SolicitaTokenDTO;
import jakarta.ws.rs.core.Response;

public interface GovBrResource {
    public Response getToken(SolicitaTokenDTO corpo) throws Exception;
    //public Response getTokenIti(SolicitaTokenDTO corpo) throws Exception;

}
