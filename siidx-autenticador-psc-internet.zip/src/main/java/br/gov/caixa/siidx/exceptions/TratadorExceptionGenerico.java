package br.gov.caixa.siidx.exceptions;

import br.gov.caixa.siidx.exceptions.dto.RetornoErroDTO;
import br.gov.caixa.siidx.exceptions.enums.ErrosComunsEnum;

import io.quarkus.hibernate.validator.runtime.jaxrs.ResteasyReactiveViolationException;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import lombok.extern.slf4j.Slf4j;




/**
 * Mapper para tratar exceptions que não tenham sido tratadas em outro lugar da aplicação. Faz log
 * do máximo de informação possível dos problemas e retorna uma mensagem mais amigável.
 */
@Provider
@Slf4j
public class TratadorExceptionGenerico implements ExceptionMapper<Exception> {

    @Override
    public Response toResponse(Exception exc) {
        try {
            // Muitas vezes a detalhe exception fica "escondida"
            // dentro de uma cadeia de "Caused by". Este método
            // faz uma busca nessa cadeia para tentar encontrar uma
            // Detalhe exception. Se encontrar, segue o fluxo de tratamento
            // da Detalhe Exception.
            DetalheException de = buscarDetalheException(exc);
            if (de != null) {
                return TratadorExceptionDetalhe.tratarDetalheException(de);
            } else if (exc instanceof ConstraintViolationException) {
                return TratadorConstraintViolationException
                        .tratarConstraintViolationException((ConstraintViolationException) exc);
            } else if (exc instanceof ResteasyReactiveViolationException) {
                return TratadorResteasyReactiveViolationException
                        .tratarValidationException((ResteasyReactiveViolationException) exc);
            } else if (exc.getCause() instanceof WebApplicationException
                    || exc instanceof WebApplicationException) {
                // ResteasyWebApplicationException: erros em chamadas a APIs rest
                return TratadorWebApplication
                        .tratarWebApplicationException((WebApplicationException) exc.getCause());
            }
        } catch (Exception excecaoNoTratamento) {
            // log.error("Ocorreu um erro durante o tratamento da exceção: ", exc);
            return responseErroGenerico(excecaoNoTratamento);
        }

        return responseErroGenerico(exc);
    }



    static Response responseErroGenerico(Exception exc) {
        // Demais erros que não atendam aos critérios acima
        // log.error("Exceção não tratada na aplicação.", exc);

        return Response.status(500)
                .entity(new RetornoErroDTO(ErrosComunsEnum.ERRO_INTERNO_SERVIDOR)).build();
    }

    /**
     * Buscar dentro da cadeia de causas da exception se há alguma que seja DetalheException.
     * 
     * @param e
     * @return
     */
    static DetalheException buscarDetalheException(Throwable e) {
        int limiteLoop = 10;
        while (limiteLoop > 0 && e != null && !(e instanceof DetalheException)) {
            e = e.getCause();
            limiteLoop--;
        }
        if (!(e instanceof DetalheException))
            return null;
        return (DetalheException) e;
    }
}
