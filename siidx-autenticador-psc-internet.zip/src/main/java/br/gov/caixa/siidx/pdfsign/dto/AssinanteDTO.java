package br.gov.caixa.siidx.pdfsign.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AssinanteDTO {
    private String nome;
    private String cpf;
}
