package br.gov.caixa.siidx.pdfsign.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ItiTokenRetornoDTO {
	private String access_token;
	private String token_type;
	private int expires_in;
}
