package br.gov.caixa.siidx.pdfsign.service.impl;

import br.gov.caixa.siidx.exceptions.DetalheException;
import br.gov.caixa.siidx.exceptions.enums.ErrosComunsEnum;
import br.gov.caixa.siidx.pdfsign.dto.*;
import br.gov.caixa.siidx.pdfsign.resources.restclient.AssinadorSerproIdAssinatura;
import br.gov.caixa.siidx.pdfsign.service.AssinadorPdfSerproIdService;
import br.gov.caixa.siidx.pdfsign.utilitarios.CertUtil;
import br.gov.caixa.siidx.pdfsign.utilitarios.PDFBoxUtil;
import br.gov.caixa.siidx.psc.utilitarios.JwtUtil;
import br.gov.caixa.siidx.psc.utilitarios.Util;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.ExternalSigningSupport;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.SignatureOptions;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import java.io.ByteArrayOutputStream;
import java.util.*;

@Slf4j
@ApplicationScoped
public class AssinadorPdfSerproIdServiceImpl implements AssinadorPdfSerproIdService {
    @ConfigProperty(name = "serproid.clientId")
    String clientId;

    @ConfigProperty(name = "serproid.secret")
    String serproIdPass;

    @ConfigProperty(name = "serproid.redirectUri")
    String redirectUri;

    @Inject
    @RestClient
    AssinadorSerproIdAssinatura assinadorSerproIdAssinatura;

    @Inject
    ObjectMapper mapper;

    @ConfigProperty(name = "secret.token.siidx")
    String secret_token;

    @ConfigProperty(name = "secret.dados_token.siidx")
    String secret_dados_token;

    private static final String PROVEDOR = "SERPROID";

    public byte [] assinar(MultipartFormDataInput inputForm) throws Exception {
        try {
            var map = inputForm.getFormDataMap();
            //RECUPERA OS DADOS DO FORM DA REQUISIÇÃO
            //=====================================================================================
            var arq = map.get("arquivo").get(0);
            var tokenMap = map.get("token").get(0);
            var signer = map.get("assinante").get(0);
            var page = map.get("pagina").get(0);
            var x = map.get("coordx").get(0);
            var y = map.get("coordy").get(0);
            var pagina = page.getBody(String.class, String.class);
            var coordX = x.getBody(String.class, String.class);
            var coordY = y.getBody(String.class, String.class);
            byte[] arquivoPdf = arq.getBody(byte[].class, byte[].class);
            var tokenSiidx = tokenMap.getBody(String.class, String.class);
            var assinante = signer.getBody(String.class, String.class);

            //FAZ A VERIFICAÇÃO DO TOKEN ENVIADO PELO FRONT
            //========================================================================================
            if (!JwtUtil.validarTokenComSecret(tokenSiidx, secret_token)) {
                log.error("O token enviado é invalido");
                throw new DetalheException(ErrosComunsEnum.ERRO_VALIDACAO_TOKEN);
            }
            //========================================================================================

            //=====================================================================================
            //DECODIFICA O TOKEN DO SIIDX ENVIADO PELO FRONT E DECRIPTOGRAFA O TOKEN DE ASSINATURA
            //DO ITI QUE ESTÁ INSERIDO NELE
            //=====================================================================================
            String payload = JwtUtil.jwtDecode(tokenSiidx);
            SiidxTokenIti tokenCriptografado = mapper.readValue(payload, SiidxTokenIti.class);
            var token = Util.decrypt(tokenCriptografado.getAccess_token(), secret_dados_token);
            //=====================================================================================
            //PAGINA - 1, PORQUE O PDDocument começa as páginas em zero.
            //=====================================================================================
            byte[] pdfAssinado = assinarPdf(arquivoPdf, assinante, token, Integer.parseInt(pagina) - 1, Float.parseFloat(coordX), Float.parseFloat(coordY));

            return pdfAssinado;
        } catch (Exception e) {
            log.error("Não foi possível realizar a assinatura.");
            throw new DetalheException(ErrosComunsEnum.ERRO_ASSINATURA_DIGITAL);

        }
    }

    private String assinarNoSerproId(SerproIdHashParaAssinarDTO hash, String token) {
        String retorno = assinadorSerproIdAssinatura.getAssinar("Bearer " + token, hash);
        return  retorno;
    }

    public byte[] assinarPdf(byte[] pdfBytes, String nomeAssinante, String token, int pagina, float coordX, float coordY) throws Exception{
        try (PDDocument doc = Loader.loadPDF(pdfBytes);
            SignatureOptions opts = new SignatureOptions();
            ByteArrayOutputStream out = new ByteArrayOutputStream(pdfBytes.length + 131072)) {

            // 1) Dicionário de assinatura: PAdES = CAdES no PDF
            PDSignature sig = new PDSignature();
            sig.setFilter(PDSignature.FILTER_ADOBE_PPKLITE);
            // Tente primeiro ETSI (PAdES). Se seu validador reclamar, teste adbe.pkcs7.detached.
            sig.setSubFilter(PDSignature.SUBFILTER_ETSI_CADES_DETACHED); // ou: PDSignature.SUBFILTER_ADBE_PKCS7_DETACHED
            if (nomeAssinante != null && !nomeAssinante.isBlank()) {
                sig.setName(nomeAssinante);
            }

            //PREPARAÇÃO DA ASSINATURA VISUAL
            //**************************************
           PDRectangle rect = PDFBoxUtil.rectTopLeft(doc, pagina, 160f, 65f, coordX, coordY);

            // 2) Placeholder generoso (PDF armazena DER como HEX -> ~2x bytes)
            opts.setPreferredSignatureSize(120_000);
            opts.setVisualSignature(PDFBoxUtil.createVisualSignatureTemplate(doc, pagina ,rect, sig, nomeAssinante, PROVEDOR));
            doc.addSignature(sig, opts);

            // 3) Gera o conteúdo dos ByteRanges e calcula SHA-256 EXATO disso
            ExternalSigningSupport signing = doc.saveIncrementalForExternalSigning(out);
            byte[] hash = PDFBoxUtil.sha256Of(signing.getContent());
            String hashBase64 = Base64.getEncoder().encodeToString(hash);

            //PREPARANDO O DTO PARA ENVIAR PARA O SERPROID PARA SER ASSINADO
            SerproIdHashesDTO serproIdHashesDTO = new SerproIdHashesDTO();
            serproIdHashesDTO.setId(hashBase64);
            serproIdHashesDTO.setAlias("Documento PDF a ser assinado.");
            serproIdHashesDTO.setHash(hashBase64);
            serproIdHashesDTO.setHash_algorithm("2.16.840.1.101.3.4.2.1");
            serproIdHashesDTO.setSignature_format("CMS");
            SerproIdHashParaAssinarDTO dto = new SerproIdHashParaAssinarDTO();
            List <SerproIdHashesDTO> hashes = new ArrayList<>();
            hashes.add (serproIdHashesDTO);
            dto.setHashes(hashes);
            //*****************************************************************
            //CHAMA SERPROID PARA ASSINAR O HASH
            String payload = assinarNoSerproId(dto, token);
            //*****************************************************************
            SerproIdRetornoAssinaturasDTO dtoAssinatura = mapper.readValue(payload,SerproIdRetornoAssinaturasDTO.class);
            String pkcs7 = dtoAssinatura.getSignatures().get(0).getRaw_signature();
            // 4.1) Normalize para DER binário (PDFBox espera DER cru)
            byte[] pkcs7Der = CertUtil.normalizePkcs7ToDer(pkcs7.getBytes());

            // 5) Injeta o CMS no /Contents. PDFBox cuida de HEX + padding + ByteRange.
            signing.setSignature(pkcs7Der);

            byte[] signedPdf = out.toByteArray();

            return signedPdf;
        } catch (Exception e) {
            log.error("Falha ao assinar PAdES (verifique causa no stacktrace)" +  e.getMessage());
            throw new DetalheException(ErrosComunsEnum.ERRO_ASSINATURA_DIGITAL);

        }
    }




}





