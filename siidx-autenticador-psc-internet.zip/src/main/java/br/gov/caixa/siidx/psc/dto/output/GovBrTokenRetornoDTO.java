package br.gov.caixa.siidx.psc.dto.output;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GovBrTokenRetornoDTO {
	private String access_token;
	private String token_type;
	private int expires_in;
	private String scope;
	private String id_token;
}
