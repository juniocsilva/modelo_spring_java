package br.gov.caixa.siidx.pdfsign.resources.restclient;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "assinador.iti.token")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public interface AssinadorItiToken {
    @POST
    @Path("/token")
    String getToken(
            @FormParam("code") String code,
            @FormParam("client_id") String clientId,
            @FormParam("grant_type") String grantType,
            @FormParam("client_secret") String clientSecret,
            @FormParam("redirect_uri") String redirectUri);
}
