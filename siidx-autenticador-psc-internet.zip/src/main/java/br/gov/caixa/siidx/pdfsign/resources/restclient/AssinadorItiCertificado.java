package br.gov.caixa.siidx.pdfsign.resources.restclient;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "assinador.iti.certificado")
@RegisterProvider(WebApplicationException.class)
@Produces(MediaType.APPLICATION_JSON)
public interface AssinadorItiCertificado {
    @GET
    @Path("/certificadoPublico")
    String getCertificado(
            @HeaderParam(value="Authorization")  String authorizationHeader);
}
