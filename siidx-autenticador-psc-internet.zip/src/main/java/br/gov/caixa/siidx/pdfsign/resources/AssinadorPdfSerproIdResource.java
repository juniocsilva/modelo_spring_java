package br.gov.caixa.siidx.pdfsign.resources;

import jakarta.ws.rs.core.Response;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

public interface AssinadorPdfSerproIdResource {
    public Response assinaSerproId(MultipartFormDataInput corpo)  throws Exception;
}

