package br.gov.caixa.siidx.exceptions.enums;

public enum ErroNiveisEnum {
    ERRO("ERRO"),
    WARN("WARN"),
    INFO("INFO");

    private String nivel;

    ErroNiveisEnum(String nivel) {
        this.nivel = nivel;
    }

    public String getNivel() {
        return this.nivel;
    }

}
