package br.gov.caixa.siidx.psc.dto.input;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MensagemDTO {
	String mensagem;
}
