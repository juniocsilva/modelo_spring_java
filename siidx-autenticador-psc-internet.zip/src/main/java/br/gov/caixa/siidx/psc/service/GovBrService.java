package br.gov.caixa.siidx.psc.service;


import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;

public interface GovBrService {
    public SiidxTokenPscDTO getToken(String code, String codeVerifier) throws Exception;
    public SiidxTokenPscDTO getTokenIti(String code, String codeVerifier) throws Exception;
}
