package br.gov.caixa.siidx.psc.service.impl;


import br.gov.caixa.siidx.psc.dto.output.*;
import br.gov.caixa.siidx.psc.resources.restclient.GovBrNiveis;
import br.gov.caixa.siidx.psc.resources.restclient.GovBrToken;
import br.gov.caixa.siidx.psc.service.GovBrService;
import br.gov.caixa.siidx.psc.utilitarios.JwtUtil;
import br.gov.caixa.siidx.psc.utilitarios.Util;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Slf4j
@ApplicationScoped
public class GovBrServiceImpl implements GovBrService {

    private final String QUERY_PARAM = "ids";

    @ConfigProperty(name = "govbr.clientId")
    String clientId;

    @ConfigProperty(name = "govbr.secret")
    String secret;

    @ConfigProperty(name = "secret.token.siidx")
    String secret_token;

    @ConfigProperty(name = "secret.dados.token.siidx")
    String secret_dados_token;

//    @ConfigProperty(name = "govbr.verify.jwk")
//    String urlJwk;


    @ConfigProperty(name = "govbr.redirectUri")
    String redirectUri;

    @Inject
    @RestClient
    GovBrToken govBrToken;

    @Inject
    @RestClient
    GovBrNiveis govBrNiveis;

    public GovBrAcessosDTO buscarAcessos (String token) throws Exception {


        String payload = JwtUtil.jwtDecode(token);

        ObjectMapper mapper = new ObjectMapper();
        JwtGovBrPayload jwt = mapper.readValue(payload, JwtGovBrPayload.class);

        GovBrAcessosDTO govBrAcessosDTO = new GovBrAcessosDTO();
        List <GovBrNiveisConfiabilidadesDTO> retorno = this.getAcessos(token, jwt.getSub(), QUERY_PARAM, "niveis");
        govBrAcessosDTO.setNiveis(retorno);

        retorno = this.getAcessos(token, jwt.getSub(), QUERY_PARAM, "confiabilidades");
        govBrAcessosDTO.setConfiabilidades(retorno);
        verificaAcessos(govBrAcessosDTO, jwt);
        govBrAcessosDTO.setPodeAssinar(true);
        govBrAcessosDTO.setMensagem("Usuário habilitado para assinar documentos via gov.br");
        return govBrAcessosDTO;
    }

    public String chamaGovBr(String code, String codeVerifier) throws Exception {

        String credentials = clientId + ":" + secret;
        String encoded = Base64.getEncoder().encodeToString(credentials.getBytes());
        String authorization = "Basic " + encoded;
        String grantType = "authorization_code";


        String retorno = govBrToken.getToken(authorization,
                URLEncoder.encode(grantType, StandardCharsets.UTF_8),
                URLEncoder.encode(code, StandardCharsets.UTF_8),
                URLEncoder.encode(codeVerifier, StandardCharsets.UTF_8),
                redirectUri);
        return retorno;
    }

    @Override
    public SiidxTokenPscDTO getToken(String code, String codeVerifier) throws Exception {

        String retorno = chamaGovBr(code, codeVerifier);

        ObjectMapper mapper = new ObjectMapper();
        GovBrTokenRetornoDTO resposta = mapper.readValue(retorno, new TypeReference<GovBrTokenRetornoDTO>() {});
        //GovBrAcessosDTO acessos = buscarAcessos("Bearer " + resposta.getAccess_token());
        String payload = JwtUtil.jwtDecode(resposta.getAccess_token());

        //VERIFICA SE O TOKEN RETORNADO É UM TOKEN GERADO PELO GOV.BR
        // ****************************************************************
//            try {
//                if (!JwtUtil.validarToken(resposta.getAccess_token(), urlJwk)) {
//                    throw new GovBrException("401", "Token Gov.Br Inválido!");
//                }
//            } catch (Exception e) {
//                throw new GovBrException("401", "Token Gov.Br Inválido!");
//            }
        // ****************************************************************

        JwtGovBrPayload jwt = mapper.readValue(payload, JwtGovBrPayload.class);

        Map<String, Object> claims = new HashMap<>();
        claims.put("access_token", Util.encrypt(resposta.getAccess_token(), secret_dados_token));
        claims.put("cpf", Util.encrypt(jwt.getSub(), secret_dados_token));
        //claims.put("niveis", Util.encrypt(String.valueOf(acessos.getNiveis().get(0).getId()), secret_dados_token));
        //claims.put("confiabilidades", Util.encrypt(String.valueOf(acessos.getConfiabilidades().get(0).getId()), secret_dados_token));
        SiidxTokenPscDTO token = new SiidxTokenPscDTO();
        String jwtSiidx = JwtUtil.jwtEncode("govbr", claims,3600000, secret_token);
        token.setToken(jwtSiidx);

        return token;
    }

    @Override
    public SiidxTokenPscDTO getTokenIti(String code, String codeVerifier) throws Exception {

        String retorno = chamaGovBr(code, codeVerifier);

        ObjectMapper mapper = new ObjectMapper();
        GovBrTokenRetornoDTO resposta = mapper.readValue(retorno, new TypeReference<GovBrTokenRetornoDTO>() {});
        String payload = JwtUtil.jwtDecode(resposta.getAccess_token());

        JwtGovBrPayload jwt = mapper.readValue(payload, JwtGovBrPayload.class);

        Map<String, Object> claims = new HashMap<>();
        claims.put("access_token", Util.encrypt(resposta.getAccess_token(), secret_dados_token));
        claims.put("cpf", Util.encrypt(jwt.getSub(), secret_dados_token));
        //claims.put("niveis", Util.encrypt(String.valueOf(acessos.getNiveis().get(0).getId()), secret_dados_token));
        //claims.put("confiabilidades", Util.encrypt(String.valueOf(acessos.getConfiabilidades().get(0).getId()), secret_dados_token));
        SiidxTokenPscDTO token = new SiidxTokenPscDTO();
        String jwtSiidx = JwtUtil.jwtEncode("govbr", claims,3600000, secret_token);
        token.setToken(jwtSiidx);

        return token;
    }

    private List<GovBrNiveisConfiabilidadesDTO> getAcessos (String token, String  cpf, String param, String servico) throws Exception{
        String retorno = govBrNiveis.getAcessos(token, cpf, servico, param);

        ObjectMapper mapper = new ObjectMapper();
        List<GovBrNiveisConfiabilidadesDTO> lista = mapper.readValue(retorno, new TypeReference<List<GovBrNiveisConfiabilidadesDTO>>() {});
        return lista;
    }

    private void verificaAcessos(GovBrAcessosDTO acessos, JwtGovBrPayload jwt)  {
        acessos.setPodeAssinar(false);
        boolean contem = Arrays.stream(jwt.getAmr()).anyMatch(nome -> nome.equalsIgnoreCase("passwd"));

        if (contem) {
            acessos.setMensagem("Usuário deve logar Certificado Digital");
            throw new WebApplicationException("Usuário deve logar Certificado Digital");
        }
        long maiorNivel = 0;
        for (GovBrNiveisConfiabilidadesDTO nivel : acessos.getNiveis()) {
            if (nivel.getId() > maiorNivel) {
                maiorNivel = nivel.getId();
            }
        }
        for (GovBrNiveisConfiabilidadesDTO confiabilidade : acessos.getConfiabilidades()) {
            if (maiorNivel < 2 || confiabilidade.getId() != 801) {
                acessos.setMensagem("Usuário precisa ser PRATA ou OURO e deve ter logado com Certificado Digital");
                throw new WebApplicationException("Usuário precisa ser PRATA ou OURO e deve ter logado com Certificado Digital");
            }
        }
    }

}



