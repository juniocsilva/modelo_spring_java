package br.gov.caixa.siidx.pdfsign.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SerproIdAssinaturasDTO {
    private String id;
    private String raw_signature;
}
