package br.gov.caixa.siidx.pdfsign.utilitarios;

import jakarta.ws.rs.WebApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceStream;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.ExternalSigningSupport;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.SignatureOptions;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDSignatureField;
import org.apache.pdfbox.util.Matrix;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;


@Slf4j
public class PDFBoxUtil {
    static final String LOGO_ICP_BR = "/images/logo_icp_br.png";            // preferido
    static final String LOGO_GOV_BR = "/images/logo_gov_br.png";
    static final String LOGO_FALLBACK = "/images/logo_gov_br.png";    // opcional

    private static float shrinkToFit(
            PDFont font, String text, float preferred, float min, float maxWidth,
            java.util.function.BiFunction<PDFont, Float, java.util.function.Function<String, Float>> measure) {
        float fs = preferred;
        try {
            while (fs > min && measure.apply(font, fs).apply(text) > maxWidth) {
                fs -= 0.25f;
            }
        } catch (Exception ignore) {}
        return Math.max(fs, min);
    }

    public static Rectangle2D createHumanRectangle(Double posicaoX, Double posicaoY) {
        Rectangle2D.Double humanRect = new Rectangle2D.Double();
        humanRect.setRect(posicaoX,posicaoY,240.0,50.0);
        return humanRect;
    }

    public static PDRectangle createSignatureRectangle(PDDocument doc, Rectangle2D humanRect)
    {
        float x = (float) humanRect.getX();
        float y = (float) humanRect.getY();
        float width = (float) humanRect.getWidth();
        float height = (float) humanRect.getHeight();
        PDPage page = doc.getPage(0);
        PDRectangle pageRect = page.getCropBox();
        PDRectangle rect = new PDRectangle();

        switch (page.getRotation())
        {
            case 90:
                rect.setLowerLeftY(x);
                rect.setUpperRightY(x + width);
                rect.setLowerLeftX(y);
                rect.setUpperRightX(y + height);
                break;
            case 180:
                rect.setUpperRightX(pageRect.getWidth() - x);
                rect.setLowerLeftX(pageRect.getWidth() - x - width);
                rect.setLowerLeftY(y);
                rect.setUpperRightY(y + height);
                break;
            case 270:
                rect.setLowerLeftY(pageRect.getHeight() - x - width);
                rect.setUpperRightY(pageRect.getHeight() - x);
                rect.setLowerLeftX(pageRect.getWidth() - y - height);
                rect.setUpperRightX(pageRect.getWidth() - y);
                break;
            case 0:
            default:
                rect.setLowerLeftX(x);
                rect.setUpperRightX(x + width);
                rect.setLowerLeftY(pageRect.getHeight() - y - height);
                rect.setUpperRightY(pageRect.getHeight() - y);
                break;
        }
        return rect;
    }

public static InputStream createVisualSignatureTemplate(
        PDDocument srcDoc, int pageNum,
        PDRectangle rect, PDSignature signature, String name, String provedor
) throws Exception {

    try (PDDocument doc = new PDDocument()) {

        // 1) Validação da página
        if (srcDoc.getNumberOfPages() <= pageNum || Objects.isNull(srcDoc.getPage(pageNum))) {
            throw new Exception("Página informada para colocação da assinatura não encontrada");
        }

        // 2) Página "template" com o mesmo tamanho da página original
        PDPage page = new PDPage(srcDoc.getPage(pageNum).getMediaBox());
        doc.addPage(page);

        // 3) AcroForm e campo de assinatura
        PDAcroForm acroForm = new PDAcroForm(doc);
        doc.getDocumentCatalog().setAcroForm(acroForm);
        PDSignatureField signatureField = new PDSignatureField(acroForm);
        PDAnnotationWidget widget = signatureField.getWidgets().get(0);
        List<PDField> acroFormFields = acroForm.getFields();
        acroForm.setSignaturesExist(true);
        acroForm.setAppendOnly(true);
        acroForm.getCOSObject().setDirect(true);
        acroFormFields.add(signatureField);

        widget.setRectangle(rect);

        // 4) Appearance/Form XObject + rotação
        PDStream stream = new PDStream(doc);
        PDFormXObject form = new PDFormXObject(stream);
        PDResources res = new PDResources();
        form.setResources(res);
        form.setFormType(1);

        PDRectangle bbox = new PDRectangle(rect.getWidth(), rect.getHeight());
        float availH = bbox.getHeight();
        Matrix initialScale = null;

        switch (srcDoc.getPage(pageNum).getRotation()) {
            case 90 -> {
                form.setMatrix(AffineTransform.getQuadrantRotateInstance(1));
                initialScale = Matrix.getScaleInstance(
                        bbox.getWidth() / bbox.getHeight(),
                        bbox.getHeight() / bbox.getWidth()
                );
                availH = bbox.getWidth();
            }
            case 180 -> form.setMatrix(AffineTransform.getQuadrantRotateInstance(2));
            case 270 -> {
                form.setMatrix(AffineTransform.getQuadrantRotateInstance(3));
                initialScale = Matrix.getScaleInstance(
                        bbox.getWidth() / bbox.getHeight(),
                        bbox.getHeight() / bbox.getWidth()
                );
                availH = bbox.getWidth();
            }
            default -> {}
        }
        form.setBBox(bbox);

        // 5) Fontes Standard 14 (Helvetica) – você já pode ter feito warm-up antes
        PDFont fontRegular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        PDFont fontBold    = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        res.add(fontRegular);
        res.add(fontBold);

        // 6) Appearance stream no widget
        PDAppearanceDictionary appearance = new PDAppearanceDictionary();
        appearance.getCOSObject().setDirect(true);
        PDAppearanceStream appearanceStream = new PDAppearanceStream(form.getCOSObject());
        appearance.setNormalAppearance(appearanceStream);
        widget.setAppearance(appearance);

        // 7) Carrega logo (Caixa, senão fallback ICP)
        PDImageXObject logo = null;
        if (provedor == "GOVBR") {
            logo = loadLogo(doc, LOGO_GOV_BR, LOGO_FALLBACK);
        } else {
            logo = loadLogo(doc, LOGO_ICP_BR, LOGO_FALLBACK);
        }

        // 8) Texto
        final String heading = "Documento assinado digitalmente";
        final String signer  = (name == null ? "" : name).toUpperCase(Locale.ROOT);
        DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        final String dateStr = Instant.now().atZone(ZoneId.of("America/Sao_Paulo")).format(FMT);
        System.out.println("DATA DA ASSINATURA");
        System.out.println(dateStr);
//        final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
//        final String dateStr = CalendarUtils.toLocalDateTime(signature.getSignDate()).format(fmt);
        final String urlLine = "Verifique em https://validar.iti.gov.br";

        // 9) Layout: colunas (logo | texto), com gap menor e coluna de logo mais enxuta
        final float pad   = 6f;
        final float gap   = 4f;
        final float boxW  = bbox.getWidth();
        final float boxH  = availH;

        float logoColW = (logo != null)
                ? Math.min(boxW * 0.22f, boxH * 0.90f) // logo mais estreito, harmônico em retângulos pequenos
                : 0f;

        float textColX = pad + logoColW + (logoColW > 0 ? gap : 0);
        float textColW = boxW - textColX - pad;

        // Tamanhos base menores (ajudam quando você reduziu o rect em 50%)
        float fsHeading = 9.5f;
        float fsName    = 10.5f;
        float fsOther   = 9.0f;

        // "Shrink" mais agressivo para garantir que não corte no BBox
        fsHeading = shrinkToFit(fontRegular, heading, fsHeading, 6.5f, textColW);
        fsName    = shrinkToFit(fontBold,    signer,  fsName,    7.0f, textColW);
        // use a linha mais longa como referência de largura (normalmente a URL)
        fsOther   = shrinkToFit(fontRegular, urlLine, fsOther,   6.5f, textColW);

        // Verifica e quebra heading em 2 linhas se ainda assim estourar
        List<String> headingLines = new ArrayList<>();
        if (textWidth(fontRegular, heading, fsHeading) <= textColW) {
            headingLines.add(heading);
        } else {
            int cut = breakAtSpace(fontRegular, heading, fsHeading, textColW);
            headingLines.add(heading.substring(0, cut).trim());
            headingLines.add(heading.substring(cut).trim());
        }

        try (PDPageContentStream cs = new PDPageContentStream(doc, appearanceStream)) {
            if (initialScale != null) cs.transform(initialScale);

            // (opcional) fundo branco sutil dentro do bbox
            // cs.setNonStrokingColor(Color.WHITE);
            // cs.addRect(0, 0, boxW, boxH);
            // cs.fill();

            // 10) Desenha logo alinhado ao topo do heading
            if (logo != null && logoColW > 0) {
                float iw = logo.getWidth();
                float ih = logo.getHeight();
                float logoAvailW = logoColW;
                float logoAvailH = boxH - 2 * pad;

                float s = Math.min(logoAvailW / iw, logoAvailH / ih);
                float drawW = Math.min(iw * s, logoAvailW);
                float drawH = Math.min(ih * s, logoAvailH);

                float textTop  = boxH - pad;             // topo interno do bbox
                float baseY    = textTop - fsHeading;    // baseline da 1ª linha
                float ascent   = ascent(fontRegular, fsHeading);
                float headingTop = baseY + ascent;       // topo "óptico" da 1ª linha

                float logoX = pad + (logoColW - drawW) / 2f;
                float logoY = Math.max(pad, headingTop - drawH); // alinha topo do logo ao topo do heading

                cs.drawImage(logo, logoX, logoY, drawW, drawH);
            }

            // 11) Bloco de texto (1 ou 2 linhas de heading)
            float leadingFactor = 1.35f;
            float lineGapHeading = fsHeading * leadingFactor;
            float lineGapName    = fsName    * leadingFactor;
            float lineGapOther   = fsOther   * leadingFactor;

            float textTop = boxH - pad;

            cs.beginText();
            cs.setNonStrokingColor(Color.BLACK);

            // HEADINGS
            cs.setFont(fontRegular, fsHeading);
            cs.newLineAtOffset(textColX, textTop - fsHeading);
            cs.showText(headingLines.get(0));
            if (headingLines.size() > 1) {
                cs.newLineAtOffset(0, -lineGapHeading);
                cs.showText(headingLines.get(1));
            }

            // NOME
            cs.setFont(fontBold, fsName);
            cs.newLineAtOffset(0, -lineGapName);
            cs.showText(signer);

            // DATA
            cs.setFont(fontRegular, fsOther);
            cs.newLineAtOffset(0, -lineGapOther);
            cs.showText("Data: " + dateStr);

            // URL
            cs.newLineAtOffset(0, -lineGapOther);
            cs.showText("Verifique em https://validar.iti.gov.br");

            cs.endText();
        } catch (Exception e) {
            throw new Exception("Ocorreu um erro ao tentar criar um template de assinatura visual", e);
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        doc.save(baos);
        return new ByteArrayInputStream(baos.toByteArray());
    }
}

    // ----------------- Helpers -----------------

    /** Carrega logo preferido e, se falhar, tenta fallback; retorna null se nenhum for encontrado. */
    private static PDImageXObject loadLogo(PDDocument doc, String preferred, String fallback) {
        for (String path : new String[]{preferred, fallback}) {
            if (path == null) continue;
            try (InputStream in = PDFBoxUtil.class.getResourceAsStream(path)) {
                if (in != null) {
                    BufferedImage bi = ImageIO.read(in);
                    if (bi != null) {
                        return LosslessFactory.createFromImage(doc, bi);
                    }
                }
            } catch (IOException ignore) {}
        }
        return null;
    }

    /** Diminui o tamanho da fonte até caber na largura máxima; respeita um mínimo. */
    private static float shrinkToFit(PDFont font, String text,
                                     float preferred, float min, float maxWidth) throws IOException {
        float fs = preferred;
        while (fs > min && textWidth(font, text, fs) > maxWidth) {
            fs -= 0.25f;
        }
        return Math.max(fs, min);
    }

    private static float textWidth(PDFont font, String text, float fontSize) throws IOException {
        return font.getStringWidth(text) / 1000f * fontSize;
    }

    /** Retorna índice de quebra no último espaço que mantém o texto <= maxWidth. */
    private static int breakAtSpace(PDFont font, String text, float fs, float maxW) throws IOException {
        int lastSpace = -1;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c)) lastSpace = i;
            if (textWidth(font, text.substring(0, i + 1), fs) > maxW) {
                return (lastSpace > 0 ? lastSpace : i);
            }
        }
        return text.length();
    }

    /** Aproxima a altura de ascent para alinhar topo óptico do texto. */
    private static float ascent(PDFont font, float fontSize) {
        var fd = font.getFontDescriptor();
        if (fd != null && fd.getAscent() != 0) {
            return (fd.getAscent() / 1000f) * fontSize;
        }
        return fontSize * 0.8f; // fallback razoável para Type1
    }

    // ---- (opcional) Helpers para posicionamento do rect no A4 ----

    public static PDRectangle rectBottomRight(PDDocument srcDoc, int pageIndex,
                                              float width, float height,
                                              float marginRight, float marginBottom) {
        PDRectangle media = srcDoc.getPage(pageIndex).getMediaBox();
        float x = media.getWidth() - marginRight - width;
        float y = marginBottom;
        return new PDRectangle(x, y, width, height);
    }

    public static PDRectangle rectBottomLeft(PDDocument srcDoc, int pageIndex,
                                             float width, float height,
                                             float marginLeft, float marginBottom) {
        float x = marginLeft;
        float y = marginBottom;
        return new PDRectangle(x, y, width, height);
    }

    public static PDRectangle rectTopRight(PDDocument srcDoc, int pageIndex,
                                           float width, float height,
                                           float marginRight, float marginTop) {
        PDRectangle media = srcDoc.getPage(pageIndex).getMediaBox();
        float x = media.getWidth() - marginRight - width;
        float y = media.getHeight() - marginTop - height;
        return new PDRectangle(x, y, width, height);
    }

    public static PDRectangle rectTopLeft(PDDocument srcDoc, int pageIndex,
                                          float width, float height,
                                          float marginLeft, float marginTop) {
        PDRectangle media = srcDoc.getPage(pageIndex).getMediaBox();
        float x = marginLeft;
        float y = media.getHeight() - marginTop - height;
        return new PDRectangle(x, y, width, height);
    }

    public static byte[] sha256Of(InputStream is) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = is) {
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) != -1) md.update(buf, 0, r);
        }
        return md.digest();
    }


}
