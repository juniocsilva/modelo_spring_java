package br.gov.caixa.siidx.pdfsign.service;

import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

public interface AssinadorPdfSerproIdService {

    public byte [] assinar (MultipartFormDataInput pdf) throws Exception;
}
