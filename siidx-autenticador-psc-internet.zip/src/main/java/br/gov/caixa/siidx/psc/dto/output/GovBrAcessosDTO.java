package br.gov.caixa.siidx.psc.dto.output;


import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class GovBrAcessosDTO {
	private boolean podeAssinar;
	private String mensagem;
	private List<GovBrNiveisConfiabilidadesDTO>  niveis;
	private List<GovBrNiveisConfiabilidadesDTO>  confiabilidades;
}
