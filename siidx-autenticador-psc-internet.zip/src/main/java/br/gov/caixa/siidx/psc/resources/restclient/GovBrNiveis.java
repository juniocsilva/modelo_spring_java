package br.gov.caixa.siidx.psc.resources.restclient;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "govbr.acessos")
@RegisterProvider(WebApplicationException.class)
@Produces(MediaType.APPLICATION_JSON)
public interface GovBrNiveis {
    @GET
    @Path("/confiabilidades/v3/contas/{cpf}/{servico}")
    String getAcessos(
            @HeaderParam(value="Authorization")  String authorizationHeader,
            @PathParam("cpf") String cpf,
            @PathParam("servico") String servico,
            @QueryParam("response-type") String param);
}
