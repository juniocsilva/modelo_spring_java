package br.gov.caixa.siidx.pdfsign.resources.restclient;

import br.gov.caixa.siidx.pdfsign.dto.ItiHashParaAssinarDTO;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@RegisterRestClient(configKey = "assinador.iti.assinatura")
@RegisterProvider(WebApplicationException.class)
public interface AssinadorItiAssinatura {
    @POST
    @Path("/assinarPKCS7")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({"application/pkcs7-signature", MediaType.APPLICATION_OCTET_STREAM})
    byte[] getAssinar(
            @HeaderParam(value="Authorization")  String authorizationHeader,
            ItiHashParaAssinarDTO hashBase64);

}
