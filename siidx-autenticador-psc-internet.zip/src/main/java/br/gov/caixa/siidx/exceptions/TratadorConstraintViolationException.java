package br.gov.caixa.siidx.exceptions;

import br.gov.caixa.siidx.exceptions.dto.MensagemErroDTO;
import br.gov.caixa.siidx.exceptions.dto.RetornoErroDTO;
import br.gov.caixa.siidx.exceptions.enums.ErroNiveisEnum;

import java.util.HashMap;
import java.util.Map;

import static java.util.Objects.nonNull;

import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

@Provider
public class TratadorConstraintViolationException
        implements ExceptionMapper<ConstraintViolationException> {

    @Override
    public Response toResponse(ConstraintViolationException exception) {

        return tratarConstraintViolationException(exception);


    }

    /**
     * Este método é estático package&dash;private, para possibiltar que outros tratadores de
     * exception possam utiliza&dash;lo.
     * 
     * @param excDet
     * @return
     */
    static Response tratarConstraintViolationException(ConstraintViolationException exception) {
        Map<String, MensagemErroDTO> mensagens = new HashMap<>();

        if (nonNull(exception.getConstraintViolations())) {
            exception.getConstraintViolations().forEach(violation -> {
                String propertyPath = violation.getPropertyPath().toString();
                String message = violation.getMessage();
                mensagens.put(propertyPath,
                        new MensagemErroDTO("IDX0000", message, ErroNiveisEnum.ERRO.getNivel()));
            });
        }
        return Response.status(Response.Status.BAD_REQUEST)
                .entity(new RetornoErroDTO(mensagens.values())).build();
    }
}
