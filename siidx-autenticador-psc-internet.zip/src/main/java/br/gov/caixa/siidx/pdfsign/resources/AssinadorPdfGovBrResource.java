package br.gov.caixa.siidx.pdfsign.resources;

import br.gov.caixa.siidx.pdfsign.dto.SolicitaTokenItiDTO;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.core.Response;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

public interface AssinadorPdfGovBrResource {
    public Response assinaGovBr(MultipartFormDataInput corpo)  throws Exception;
    public Response getTokenIti(@NotNull SolicitaTokenItiDTO corpo) throws Exception;
}

