package br.gov.caixa.siidx.exceptions;

import jakarta.ws.rs.core.Response.Status;

public class GenericRestException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    private final Status status;
    private static final String MENSAGEM_GENERICA = "Erro interno do Sistema";
    private final String id;

    public GenericRestException(String errorMessage, Status status, Throwable causa) {
        super(errorMessage == null ? MENSAGEM_GENERICA : errorMessage, causa);
        this.status = status;
        this.id = null;
    }

    public GenericRestException(String errorMessage, Status status) {
        super(errorMessage == null ? MENSAGEM_GENERICA : errorMessage);
        this.status = status;
        this.id = null;
    }

    public GenericRestException(String errorMessage, Status status, Throwable causa, String id) {
        super(errorMessage == null ? MENSAGEM_GENERICA : errorMessage, causa);
        this.status = status;
        this.id = id;
    }

    public GenericRestException(String errorMessage, Status status, String id) {
        super(errorMessage == null ? MENSAGEM_GENERICA : errorMessage);
        this.status = status;
        this.id = id;
    }

    public Status getStatus() {
        return status;
    }

    public String getId() {
        return id;
    }
}
