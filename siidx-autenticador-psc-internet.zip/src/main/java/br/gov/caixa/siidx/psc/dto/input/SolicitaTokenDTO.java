package br.gov.caixa.siidx.psc.dto.input;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SolicitaTokenDTO {
	String code;
	String code_verifier;

}
