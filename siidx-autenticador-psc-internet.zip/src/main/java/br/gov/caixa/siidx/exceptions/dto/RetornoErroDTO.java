package br.gov.caixa.siidx.exceptions.dto;

import br.gov.caixa.siidx.exceptions.DetalheException;
import br.gov.caixa.siidx.exceptions.enums.ErrosComunsEnum;
import java.util.Collection;
import java.util.List;

public record RetornoErroDTO(Collection<MensagemErroDTO> mensagens) {

    public RetornoErroDTO(MensagemErroDTO mensagem) {
        this(List.of(mensagem));
    }

    public RetornoErroDTO(ErrosComunsEnum erroComum) {
        this(List.of(new MensagemErroDTO(erroComum.getId(), erroComum.getMensagens(),
                erroComum.getNivel())));
    }

    public RetornoErroDTO(DetalheException e) {
        // Response.status(500).entity(new
        // ErrorResponseDTO(ErrosComunsEnum.ERRO_INTERNO_SERVIDOR)).build();

        this(List.of(new MensagemErroDTO(e.getId(),
                e.getMessage() + (e.getDetalhe() != null ? " - " + e.getDetalhe() : ""),
                e.getId())));
    }

}
