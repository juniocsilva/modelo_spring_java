package br.gov.caixa.siidx.psc.dto.output;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SyngularTokenRetornoDTO {
    private String access_token;
    private String token_type;
    private int expires_in;
    private String scope;
    private String authorized_identification_type;
    private String authorized_identification;
}
