package br.gov.caixa.siidx.pdfsign.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SerproIdRetornoAssinaturasDTO {
    private List<SerproIdAssinaturasDTO> signatures;
    private String certificate_alias;
}
