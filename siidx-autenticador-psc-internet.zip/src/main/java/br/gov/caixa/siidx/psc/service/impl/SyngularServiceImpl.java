package br.gov.caixa.siidx.psc.service.impl;

import br.gov.caixa.siidx.psc.dto.output.SerproIdTokenRetornoDTO;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import br.gov.caixa.siidx.psc.resources.restclient.SyngularToken;
import br.gov.caixa.siidx.psc.service.SyngularService;
import br.gov.caixa.siidx.psc.utilitarios.JwtUtil;
import br.gov.caixa.siidx.psc.utilitarios.Util;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.WebApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@ApplicationScoped
public class SyngularServiceImpl implements SyngularService {

    @ConfigProperty(name = "syngular.clientId")
    String clientId;

    @ConfigProperty(name = "syngular.secret")
    String secret;

    @ConfigProperty(name = "secret.token.siidx")
    String secret_token;

    @ConfigProperty(name = "secret.dados.token.siidx")
    String secret_dados_token;

    @ConfigProperty(name = "syngular.redirectUri")
    String redirectUri;

    @Inject
    @RestClient
    SyngularToken syngularToken;

    @Override
    public SiidxTokenPscDTO getToken(String code, String codeVerifier)  {

        String grantType = "authorization_code";

        String retorno = syngularToken.getToken(
                    URLEncoder.encode(grantType, StandardCharsets.UTF_8),
                    URLEncoder.encode(code, StandardCharsets.UTF_8),
                    URLEncoder.encode(codeVerifier,StandardCharsets.UTF_8),
                    redirectUri,
                    clientId,
                    secret
        );

        try {
            ObjectMapper mapper = new ObjectMapper();
            SerproIdTokenRetornoDTO resposta = mapper.readValue(retorno, new TypeReference<SerproIdTokenRetornoDTO>() {});

            Map<String, Object> claims = new HashMap<>();
            claims.put("access_token", Util.encrypt(resposta.getAccess_token(), secret_dados_token));
            claims.put("cpf", Util.encrypt(resposta.getAuthorized_identification(), secret_dados_token));
            SiidxTokenPscDTO token = new SiidxTokenPscDTO();
            String jwtSiidx = JwtUtil.jwtEncode("syngular", claims,3600000, secret_token);
            token.setToken(jwtSiidx);
            return token;
        } catch (Exception e) {
            throw new WebApplicationException("Syngular respondeu com um erro");
        }

    }
}
