package br.gov.caixa.siidx.pdfsign.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SiidxTokenIti {
    private String sub;
    private String access_token;
    private String cpf;
    private String nome_assinante;
    private long exp;
    private long iat;
}
