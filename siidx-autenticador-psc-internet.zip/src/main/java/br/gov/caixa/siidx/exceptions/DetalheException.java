package br.gov.caixa.siidx.exceptions;

import jakarta.ws.rs.core.Response;
import lombok.Getter;

public class DetalheException extends GenericRestException {

    private static final long serialVersionUID = 1L;

    @Getter
    private final String detalhe;

    @Getter
    private ErrosComunsInterface detalheEnum = null;

    public DetalheException(String mensagem, String detalhe, Response.Status status) {
        super(mensagem, status);
        this.detalhe = detalhe;
    }

    public DetalheException(String mensagem, String detalhe, Response.Status status,
            Throwable causa) {
        super(mensagem, status, causa);
        this.detalhe = detalhe;
    }

    public DetalheException(ErrosComunsInterface detalheExceptionEnum) {
        this(detalheExceptionEnum.getMensagens(), null, detalheExceptionEnum.getStatus());
        this.detalheEnum = detalheExceptionEnum;
    }

    public DetalheException(ErrosComunsInterface detalheExceptionEnum, Throwable causa) {
        this(detalheExceptionEnum.getMensagens(), null, detalheExceptionEnum.getStatus(), causa);
        this.detalheEnum = detalheExceptionEnum;
    }
}
