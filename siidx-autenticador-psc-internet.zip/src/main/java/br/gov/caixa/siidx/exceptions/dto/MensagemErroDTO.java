package br.gov.caixa.siidx.exceptions.dto;

import br.gov.caixa.siidx.exceptions.DetalheException;
import br.gov.caixa.siidx.exceptions.enums.ErroNiveisEnum;

public record MensagemErroDTO(String id, String mensagem, String nivel) {

    private static final String NIVEL_PADRAO = ErroNiveisEnum.ERRO.getNivel();
    private static final String ID_PADRAO = "IDX0000";

    public MensagemErroDTO(DetalheException detalheException) {
        this(detalheException.getDetalheEnum().getId(), detalheException.getMessage(),
                detalheException.getDetalheEnum().getNivel());
    }

    public MensagemErroDTO(String mensagem) {
        this(ID_PADRAO, mensagem, NIVEL_PADRAO);
    }
}
