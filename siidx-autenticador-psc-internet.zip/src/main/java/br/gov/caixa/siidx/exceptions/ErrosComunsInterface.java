package br.gov.caixa.siidx.exceptions;

import jakarta.ws.rs.core.Response;

public interface ErrosComunsInterface {

    public Response.Status getStatus();

    public String getMensagens();

    public String getId();

    public String getNivel();

    public Response response();
}
