package br.gov.caixa.siidx.psc.utilitarios;

import jakarta.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.api.parallel.Execution;

import static org.junit.jupiter.api.Assertions.*;
@DisplayName("Operações de Criptografia")
class UtilTest {
    String secret_dados_token = "01234567890123456789012345678901";

    @Nested
    @DisplayName("Dado uma mensagem")
    public class dadoUmaMensagem {
        @Test
        @DisplayName("Encriptar a mensagem")
        public void fazEncriptacao() throws Exception {
            String mensagem = "30030030030";
            String encrypt = Util.encrypt(mensagem, secret_dados_token);
            assertEquals("NZtqW+AAJU/phCvCVLTC3Q==", encrypt);
        }

        @Test
        @DisplayName("Desencriptar a mensagem")
        public void fazDesencriptacao() throws Exception {
            String mensagem = "NZtqW+AAJU/phCvCVLTC3Q==";
            String encrypt = Util.decrypt(mensagem, secret_dados_token);
            assertEquals("30030030030", encrypt);
        }
    }

}