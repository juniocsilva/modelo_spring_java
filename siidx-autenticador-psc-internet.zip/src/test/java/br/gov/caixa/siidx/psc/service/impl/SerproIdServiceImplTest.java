package br.gov.caixa.siidx.psc.service.impl;

import br.gov.caixa.siidx.psc.dto.output.SerproIdTokenRetornoDTO;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import br.gov.caixa.siidx.psc.resources.restclient.SerproIdToken;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
class SerproIdServiceImplTest {
    @Mock
    SerproIdToken serproIdToken;

    @InjectMocks
    SerproIdServiceImpl servico;

    @Nested
    @DisplayName("Teste de obtenção token no SerproId")
    class testaObtencaoTokenSerproId {

        @Test
        @DisplayName("dado um code e um verfier obter o token da SerproId com Exception")
        public void requisitaTokenSerproIdComException() {
            String code = "eyJraWQiOiJjb2RlQ3J5cHRvZ3JhcGh5IiwiYWxnIjoiZGlyIiwiZW5jIjoiQTI1NkdDTSJ9..siItAIspSf0oVW1t.PAzFAGMZySQQ-wJgV6AzaIx8Zo9H15TcvmBsffHUx433lA.ADlKzsTTu5XrLUwj748FtQ";
            String verifier = "NTYwdGFzcUc2dXg1SkNHdWxEalNLcWNtS3p5Q0lkZn5ib3FSMGRWdXhKcmpx";
            SerproIdServiceImpl SerproService = new SerproIdServiceImpl();
            Assertions.assertThrows(Exception.class, () -> SerproService.getToken(code, verifier), "Parâmetro code expirado");

        }

        @Test
        @DisplayName("dado um code e um verfier obter o token da SerproId com Sucesso")
        public void requisitaTokenSerproIdComSucesso() throws Exception {
            String jsonResposta = "{\"access_token\":\"TokenSerproId\",\"token_type\":\"12345678900\",\"expires_in\":12345,\"scope\":\"12345678900\",\"authorized_identification_type\":\"cpf\",\"authorized_identification\":\"12345678900\"}";
            String secret = "12345678901234567890123456789012";
            servico.secret = secret;
            servico.secret_token = secret;
            servico.secret_dados_token = secret;

            Mockito.when(serproIdToken.getToken(anyString(), anyString(), anyString(), any(), any(), any())).thenReturn(jsonResposta);
            SiidxTokenPscDTO token = servico.getToken("code", "verifier");
            Assertions.assertNotNull(token);

        }
    }

}