package br.gov.caixa.siidx.psc.service.impl;

import br.gov.caixa.siidx.psc.dto.output.GovBrAcessosDTO;
import br.gov.caixa.siidx.psc.dto.output.GovBrNiveisConfiabilidadesDTO;
import br.gov.caixa.siidx.psc.dto.output.SiidxTokenPscDTO;
import br.gov.caixa.siidx.psc.resources.restclient.GovBrNiveis;
import br.gov.caixa.siidx.psc.resources.restclient.GovBrToken;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;


@ExtendWith(MockitoExtension.class)
class GovBrServiceImplTest {

    @Mock
    GovBrToken govBrToken;

    @Mock
    GovBrNiveis govBrNiveis;

    @InjectMocks
    GovBrServiceImpl servico;

    @Nested
    @DisplayName("Teste de obtenção token no Gov.Br")
    class testaObtencaoTokenSerproId {

        @Test
        @DisplayName("dado um code e um verfier obter o token da GovBr com Exception")
        public void requisitaTokenGovBrComException() {
            String code = "eyJraWQiOiJjb2RlQ3J5cHRvZ3JhcGh5IiwiYWxnIjoiZGlyIiwiZW5jIjoiQTI1NkdDTSJ9..siItAIspSf0oVW1t.PAzFAGMZySQQ-wJgV6AzaIx8Zo9H15TcvmBsffHUx433lA.ADlKzsTTu5XrLUwj748FtQ";
            String verifier = "NTYwdGFzcUc2dXg1SkNHdWxEalNLcWNtS3p5Q0lkZn5ib3FSMGRWdXhKcmpx";
            Assertions.assertThrows(Exception.class, () -> servico.getToken(code, verifier), "Parâmetro code expirado");

        }

        @Test
        @DisplayName("dado um code e um verifier obter o token de acesso ao Gov.Br")
        public void requisitaTokenGovBrSemNivelSucesso() throws Exception {

            String jsonNiveis = "[{\"id\":3,\"dataAtualizacao\":\"10/10/1910\"}]";
            String jsonConfiabilidades = "[{\"id\":801,\"dataAtualizacao\":\"10/10/1910\"}]";
            String tokenFake = "eyJraWQiOiJyc2ExIiwiYWxnIjoiUlMyNTYifQ.eyJhdWQiOiJoLXNpaWR4LmNhaXhhLmdvdi5iciIsInN1YiI6IjMzMzM2NTgwMTEwIiwic2NvcGUiOlsib3BlbmlkIiwiZ292YnJfY29uZmlhYmlsaWRhZGVzIiwicHJvZmlsZSIsImVtYWlsIl0sImFtciI6WyJjYXB0Y2hhIiwieDUwOSIsIng1MDlfbmVvaWQtcHJvZCJdLCJpc3MiOiJodHRwczpcL1wvc3NvLnN0YWdpbmcuYWNlc3NvLmdvdi5iclwvIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiMzMzMzY1ODAxMTAiLCJleHAiOjE3NTM5OTMyNzIsImlhdCI6MTc1Mzk4OTY3MiwianRpIjoiY2ViN2JjN2MtNmIwMS00ODc2LWI0ZGYtNDQwYmRjOWU3OTc3In0.A9RUX0rVam6e46uRcNSSTgDWioxmfNqFPGf3yoWaJdoY3PiGBKTQ4LMhzkUmYU3XSMcx97kiiLm7QAb1tnsLC4bvryGVtXzzDlXTkVbEL63DeizunlxPCWh8JP911dVkPsRDR3uwVj_JEGy85FobAkkzThXDY6jlEIjMY0mWy5HLhYFj1KDwD_vaJRKgtEvlDSc4GZvaLYpsTWqbuI7sBNX2KM_gl0ExoorptaPngAX1wghveAoq1wfT2gMlWLhYp3r0EpKoTy-CWfOBJSe2eKOuXwj9SjyA7oXy8og9yZCDkANiWVXit4Az9lSgG729vJKe69BrMIe2kf32Rd-_Yw";
            String jsonResposta = "{\"access_token\":\"" + tokenFake + "\",\"token_type\":\"12345678900\",\"expires_in\":12345,\"scope\":\"12345678900\",\"id_token\":\"idTokenGovBr\"}";
            long nivel = 3;
            String secret = "12345678901234567890123456789012";
            servico.secret = secret;
            servico.secret_token = secret;
            servico.secret_dados_token = secret;

            GovBrAcessosDTO acessos = new GovBrAcessosDTO();
            GovBrNiveisConfiabilidadesDTO niveis = new GovBrNiveisConfiabilidadesDTO();
            niveis.setId(3);
            niveis.setDataAtualizacao("10/10/1910");
            acessos.setNiveis(List.of(niveis));
            GovBrNiveisConfiabilidadesDTO conf = new GovBrNiveisConfiabilidadesDTO();
            conf.setId(801);
            conf.setDataAtualizacao("10/10/1910");
            acessos.setConfiabilidades(List.of(conf));
            Mockito.when(govBrToken.getToken(anyString(), anyString(), anyString(), anyString(), any())).thenReturn(jsonResposta);
            Mockito.when(govBrNiveis.getAcessos(anyString(), anyString(), anyString(), anyString())).thenReturn(jsonConfiabilidades);
            SiidxTokenPscDTO token = servico.getToken("code", "verifier");
            Assertions.assertNotNull(token.getToken());

        }
    }
}