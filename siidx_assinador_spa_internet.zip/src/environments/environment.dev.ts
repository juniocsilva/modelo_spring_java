export const environment = {
    production: false,
    secret_dados_token: 'UDKhvk8939jn#@!dkdh0894ndkgh67474qwt367%&30895',
    sso: {
        gov_br: {
            issuer: 'https://sso.staging.acesso.gov.br/',
            siidx: 'http://localhost:8080/api/govbr/',
            redirectUri: 'https://siidx.caixa.gov.br:4200/callback',
            clientId: 'h-siidx.caixa.gov.br',
            responseType: 'code',
            scope: 'openid email profile govbr_confiabilidades',
            showDebugInformation: true,
        },
        serpro_id: {
            issuer: 'https://serproid.serpro.gov.br/oauth/v0/oauth/', 
            siidx: 'http://localhost:8080/api/serproid/',
            redirectUri: 'https://siidx.caixa.gov.br/callback:4200',
            clientId: 'c175bd43-5304-4c26-a5d4-96603a939d1d',
            responseType: 'code',
            scope: 'multi_signature',
            showDebugInformation: true,
        },
        syngular: {
            issuer: 'https://psc.syngularid.com.br/v0/oauth/',
            siidx: 'http://localhost:8080/api/syngular/',
            redirectUri: 'https://assinador.siidx.des.caixa.gov.br/callback',
            clientId: '322e4918-b6d3-4437-8055-cc5543cd2c84',
            responseType: 'code',
            scope: 'multi_signature',
            showDebugInformation: true,
        }

    }
};
