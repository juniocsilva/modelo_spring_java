import { Component, OnInit } from '@angular/core';
import { DscMenu } from 'sidsc-components/dsc-sidenav';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {

  title = 'siidx-assinador-spa';
  itemsMenu: DscMenu[] = [];
  menuOpened = false;

  ngOnInit(): void {
    this.itemsMenu = [];
  }

  constructor() { }

  
}

