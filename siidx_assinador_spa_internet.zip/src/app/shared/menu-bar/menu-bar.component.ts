import { Component, OnInit } from '@angular/core';
import { DscMenu } from 'sidsc-components/dsc-sidenav';
import { MenuService } from '../service/menu.service';


@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.css']
})
export class MenuBarComponent implements OnInit {
  itemsMenu: DscMenu[] = [];

  constructor(public menuService : MenuService){}

  ngOnInit(): void {
   this.itemsMenu = [
    {title: 'Login', url: '/', icon: 'login'},
    {title: 'Assinatura Digital', url: 'assinatura', icon: 'assignment'}
    ];
  }
}
