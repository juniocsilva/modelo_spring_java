import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {} from '@angular/common/http'
import { Injectable } from '@angular/core';

import { jwtDecode } from 'jwt-decode';

import { Observable, timeout } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CallbackService {
  
  private headers = new HttpHeaders();
  private timeOut: number = 20000;
  private authorization: any = ''

  constructor(
    private http: HttpClient
   ) {
      
     }

  public getTokenGovBr(code: string, provedor: string): Observable<any> {
    let headers = new HttpHeaders({
         'Content-Type': 'application/json'
    }); 

    let url = environment.sso.gov_br.siidx + 'token';
    
    //CONFIGURA PARÂMETROS COMUNS DA CHAMADA AO TOKEN
    //=====================================================================
     const body = {
      'code': code,
      'code_verifier': sessionStorage.getItem("PKCE_verifier")!
    }
    
    //=====================================================================
            
    return this.http.post<any>(
      url, body
      
    ).pipe(
      timeout(this.timeOut)
    );
  }

  public getTokenOutros(code: string, provedor: string): Observable<any> {
    let url = '' 
    let headers = new HttpHeaders({
          'Content-Type': 'application/json'
    });  
    //CONFIGURA PARÂMETROS COMUNS DA CHAMADA AO TOKEN
    //=====================================================================
    const body = {
      'code': code,
      'code_verifier': sessionStorage.getItem("PKCE_verifier")!
    }

    //=====================================================================
    
    if (provedor.toUpperCase() == 'SYNGULAR') {
      url = environment.sso.syngular.siidx + 'token';
    } else {
        if (provedor.toUpperCase() == 'SERPROID') {
          url = environment.sso.serpro_id.siidx + 'token'; 
        }
    }
    
    return this.http.post<any>(
      url, body, { headers }
      
    ).pipe(
      timeout(this.timeOut)
    );
  }

  public decodificaToken(token:any) {
    return jwtDecode(token)
  }
}
