import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallbackService } from './callback.service';


import { Router } from '@angular/router';

@Component({
  selector: 'app-callback',
  templateUrl: './callback.component.html',
  styleUrls: ['./callback.component.css']
})
export class CallbackComponent {
  public code: string | null = null;
  public state: string | null = null;
  public logou: boolean = false
  public access_token:any 
  public id_token:any 
  public token_decode:any 
  public id_token_decode:any 
  private kms_type: string | null = null
  private verifier: string | null = null
  private provedor: string | null = null
  private redirect_uri: string | null = null
  constructor(private route: ActivatedRoute, 
    private router: Router,
    private servico:CallbackService) {
     
  }

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params => {
      this.code = params.get('code');
      this.state = params.get('state');
      console.log('code', this.code)
      console.log('verifier', sessionStorage.getItem("PKCE_verifier"))
      sessionStorage.setItem('code', this.code!)
      //RECUPERA DADOS DA SESSION STORAGE
      //==============================================================
      this.kms_type = sessionStorage.getItem('kms_type')
      this.provedor = sessionStorage.getItem('provedor')
      
      //==============================================================
      
      if (this.code && this.kms_type) {
        if (this.provedor?.toUpperCase() == 'GOVBR') {
          this.servico.getTokenGovBr(this.code, this.provedor!).subscribe({
            next: async (retorno:any) => {
              this.logou = true
              await this.exibirRetorno(retorno)
            },
            error: async (err:any) => {
              this.logou = false
              await this.exibirErro(err)
            }
          });   
        } else {
          this.servico.getTokenOutros(this.code, this.provedor!).subscribe({
            next: async (retorno:any) => {
              this.logou = true
              await this.exibirRetorno(retorno)
            },
            error: async (err:any) => {
              this.logou = false
              await this.exibirErro(err)
            }
          });   
        }
        
      } else {
        this.exibirErro
      }
     });
  }

   async exibirRetorno(dados:any) {
    console.log(dados)
    sessionStorage.setItem('token', dados.token)
    this.token_decode = this.servico.decodificaToken(dados.token)
    sessionStorage.setItem('cpf', this.token_decode.cpf )
    // if (this.kms_type?.toUpperCase() == 'GOVBR') {
    //   sessionStorage.setItem('cpf', this.token_decode.cpf )
    // }else {
    //   sessionStorage.setItem('cpf', dados.token.authorized_identification )
    // }
    this.router.navigate(['/documentos'])
  }

  async exibirErro(err:any) {
    console.log(err)
  }
}
