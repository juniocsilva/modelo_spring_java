import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  opened : boolean = false;
  constructor() { }

  toggle(){
    this.opened = !this.opened;
  }
}
