import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {} from '@angular/common/http'
import { Injectable } from '@angular/core';

import { jwtDecode } from 'jwt-decode';

import { Observable, timeout } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class BtService {
  
  private headers = new HttpHeaders();
  private timeOut: number = 20000;
  private authorization: any = ''

  constructor(private http: HttpClient) { }

  // public getToken(body: any): Observable<any> {
  //     let headers = new HttpHeaders({
  //         'Authorization': this.authorization,
  //         'Content-Type': 'application/x-www-form-urlencoded'
  //     }); 
      
  //     let url = environment.sso.gov_br.issuer + 'token';
  //     return this.http.post<any>(
  //       url, body, { headers }
        
  //     ).pipe(
  //       timeout(this.timeOut)
  //     );
  // }

  public authorize(parametros: any):any {
      
      const params = new URLSearchParams({
        response_type: parametros.response_type,
        client_id:  parametros.client_id,
        code_challenge:  parametros.code_challenge, 
        code_challenge_method: parametros.code_challenge_method,
        //redirect_uri:  parametros.redirect_uri, 
        scope: parametros.scope,
        state: parametros.state,
       });

        window.open(`${parametros.issuer}?${params.toString()}`, '_self'); 
  }

  public decodificaToken(token:any) {
    return jwtDecode(token)
  }
}
