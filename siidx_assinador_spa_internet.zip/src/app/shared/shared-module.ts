import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DscHeaderComponent } from 'sidsc-components/dsc-header';
import { CommonModule } from '@angular/common';
import { RouterOutlet, provideRouter } from '@angular/router';
import { DscSidenavComponent } from 'sidsc-components/dsc-sidenav';
import { DscButtonComponent } from 'sidsc-components/dsc-button'
import { DscCardComponent } from 'sidsc-components/dsc-card'
import {MatFormFieldModule} from '@angular/material/form-field';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import { DscCheckboxComponent } from 'sidsc-components/dsc-checkbox';
import { OAuthModule, OAuthService, UrlHelperService } from 'angular-oauth2-oidc';
import { HttpClientModule } from '@angular/common/http';
import { DscDialogModule} from 'sidsc-components/dsc-dialog';
import { MatDialogModule } from '@angular/material/dialog';
import { DscAlertComponent } from 'sidsc-components/dsc-alert';
import { DscInputComponent } from 'sidsc-components/dsc-input'
import { DscSelectComponent } from 'sidsc-components/dsc-select';

@NgModule({
  declarations: [
    
  ],
  imports: [
    BrowserModule,
    NoopAnimationsModule,
    MatFormFieldModule,
    RouterOutlet,
    CommonModule,
    DscHeaderComponent,
    DscSidenavComponent,
    DscButtonComponent,
    DscSelectComponent,
    DscSelectComponent,
    DscInputComponent,
    DscCardComponent,
    MatGridListModule,
    MatIconModule,
    DscCheckboxComponent,
    DscDialogModule,
    DscAlertComponent,
    MatDialogModule,
    OAuthModule.forRoot(),
    HttpClientModule
  ],
  providers: [
     
  ],
  
})
export class SharedModule{

}