import { Component, TemplateRef, ViewChild } from '@angular/core';
import { AuthConfig, OAuthService } from 'angular-oauth2-oidc';
import { DscDialogService   } from 'sidsc-components/dsc-dialog';
import { Option } from 'sidsc-components/dsc-select';
import { environment } from 'src/environments/environment';
import { BtService } from '../service/bt-service'

@Component({
  selector: 'bt-sign-in-psc',
  templateUrl: './bt-sign-in-psc.component.html',
  styleUrls: ['./bt-sign-in-psc.component.css'],
  
})
export class BtSignInPscComponent {
 @ViewChild('templateForm', { static: true })
 private templateForm!: TemplateRef<any>;
 retorno: any;
 verifier: any;
 code_chalenge: any;
 authCodeFlowConfig:any = {}
 provedor: string | null = null
 options: Option[] = [
  {
        label: 'SerproID',
        value: 'SERPROID'
      },
      {
        label: 'Syngular',
        value: 'SYNGULAR'
      },

 ];

  constructor(private _dialogService: DscDialogService, private servico: BtService) {

  }   
  
  async doLogin() {
    sessionStorage.clear() 
    await this.configuraPsc(this.provedor!)
    sessionStorage.setItem('kms_type', 'psc')
    sessionStorage.setItem('provedor', this.provedor!)
    sessionStorage.setItem('code_challenge', this.authCodeFlowConfig.code_challenge)
    sessionStorage.setItem('PKCE_verifier', this.verifier)
    
    this.servico.authorize(this.authCodeFlowConfig)

  }

  login(): void {    
    
    this._dialogService.confirm({
      data: {
        title: {
          text: 'Selecione o Provedor de Serviços',
          //variant: 'highlight'
        },
        template: this.templateForm,
        context: {
          provedor: this.provedor,
          
        },
        actionButton: {
          type: 'button',
          cancelText: 'Cancelar',
          confirmText: 'Confirmar',
          confirmFunction: (retorno: any) => {
            console.log(this.provedor)
            if(this.provedor) {
              sessionStorage.setItem('provedor', this.retorno)
              this.doLogin()
            }
          }
        }
      }
    });
  
  }

  async configuraPsc(nome: string) {
    this.verifier = await this.criaVerifier(60)
    this.authCodeFlowConfig = {
      response_type: 'code',
      code_challenge: await this.criaCodeChallenge(this.verifier),
      code_challenge_method: 'S256',
      state: 'assinador_siidx',
      
    };
    if (nome == 'SYNGULAR') {
        this.authCodeFlowConfig.client_id = environment.sso.syngular.clientId,
        this.authCodeFlowConfig.redirect_uri = environment.sso.syngular.redirectUri
        this.authCodeFlowConfig.scope = environment.sso.syngular.scope
        this.authCodeFlowConfig.issuer = environment.sso.syngular.issuer + 'authorize/'
    } else {    
      if (nome == 'SERPROID') {
        this.authCodeFlowConfig.client_id = environment.sso.serpro_id.clientId,
        this.authCodeFlowConfig.redirect_uri = environment.sso.serpro_id.redirectUri
        this.authCodeFlowConfig.scope = environment.sso.serpro_id.scope
        this.authCodeFlowConfig.issuer = environment.sso.serpro_id.issuer + 'authorize/'
      }
    }
    
  }

  async criaVerifier(tamanho:any) {
    const randomBytes = new Uint8Array(tamanho);
    crypto.getRandomValues(randomBytes);
    let base64String = btoa(String.fromCharCode(...randomBytes));
    base64String = base64String
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/, "");
    return base64String;
  }

  async criaCodeChallenge(verifier: any) {
    const encoder = new TextEncoder();
    const data = encoder.encode(verifier);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    let base64String = btoa(String.fromCharCode(...hashArray));
    base64String = base64String
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/, "");
    return base64String;
  }


  alterouPsc(evento:any) {
    this.provedor = evento.value
    
  }
}