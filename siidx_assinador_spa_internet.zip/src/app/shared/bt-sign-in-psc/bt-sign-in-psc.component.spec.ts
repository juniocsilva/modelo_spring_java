import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BtSignInPscComponent } from './bt-sign-in-psc.component';
import { AppModule } from 'src/app/app.module';

describe('BtSignInGovbrComponent', () => {
  let component: BtSignInPscComponent;
  let fixture: ComponentFixture<BtSignInPscComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AppModule],
      declarations: [BtSignInPscComponent]
    });
    fixture = TestBed.createComponent(BtSignInPscComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
