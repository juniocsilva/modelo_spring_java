import { inject } from "@angular/core";
import { MenuService } from "../service/menu.service";

export class BasePage{
    menuService : MenuService;

    constructor(){
        this.menuService = inject(MenuService)
        this.menuService.opened = false;
    } 
}