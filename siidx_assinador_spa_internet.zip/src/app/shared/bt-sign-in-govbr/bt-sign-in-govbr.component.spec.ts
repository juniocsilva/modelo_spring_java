import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BtSignInGovbrComponent } from './bt-sign-in-govbr.component';
import { AppModule } from 'src/app/app.module';

describe('BtSignInGovbrComponent', () => {
  let component: BtSignInGovbrComponent;
  let fixture: ComponentFixture<BtSignInGovbrComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AppModule],
      declarations: [BtSignInGovbrComponent]
    });
    fixture = TestBed.createComponent(BtSignInGovbrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
