import { Component } from '@angular/core';
import { AuthConfig, OAuthService } from 'angular-oauth2-oidc';
import { DscDialogService } from 'sidsc-components/dsc-dialog';
import { DscDialogComponent } from 'sidsc-components/dsc-dialog/dsc-dialog.component';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'bt-sign-in-govbr',
  templateUrl: './bt-sign-in-govbr.component.html',
  styleUrls: ['./bt-sign-in-govbr.component.css']
})
export class BtSignInGovbrComponent {

 authCodeFlowConfig: AuthConfig = {
    issuer: environment.sso.gov_br.issuer,
    redirectUri: environment.sso.gov_br.redirectUri,
    clientId: environment.sso.gov_br.clientId,
    responseType: environment.sso.gov_br.responseType,
    scope: environment.sso.gov_br.scope,
    showDebugInformation: environment.sso.gov_br.showDebugInformation
  };
  constructor(private oauthService: OAuthService,
    private _dialogService: DscDialogService) {
  }

  public doLogin() {
     this.oauthService.configure(this.authCodeFlowConfig);
    this.oauthService.loadDiscoveryDocument()
    sessionStorage.setItem('kms_type', 'govbr')
    sessionStorage.setItem('provedor', 'govbr')
    this.oauthService.initCodeFlow();
  }

  public logout() {
      this.oauthService.logOut();
  }

  public get userName() {

      var claims : any = this.oauthService.getIdentityClaims();
      if (!claims) return null;

      return claims.given_name;
  }

  login(): void {    
    this._dialogService.confirm({
      
      data: {
        title: {
          text: 'Login gov.br',
          showCloseButton: true
        },
      
        message: 'Você será direcionado ao portal gov.pt-br.',
        actionButton: {
          type: 'button',
          cancelText: 'Cancelar',
          confirmText: 'Entendi',
          confirmFunction: () => this.doLogin()
        }
      }
    });
  }


}