import {} from '@angular/common/http'
import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';


@Injectable({
  providedIn: 'root'
})
export class DocumentosService {
  
  constructor() { }

  public decodificaToken(token:any) {
    return jwtDecode(token)
  }
}
