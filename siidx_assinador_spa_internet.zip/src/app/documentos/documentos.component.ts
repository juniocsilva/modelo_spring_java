import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DocumentosService } from './documentos.service';


@Component({
  selector: 'app-documentos',
  templateUrl: './documentos.component.html',
  styleUrls: ['./documentos.component.css']
})
export class DocumentosComponent implements OnInit{
  public code: string | null = null;
  public state: string | null = null;
  public logou: boolean = false
  public token:any 
  public token_decode:any 
  public psc_access_token_decode:any 
  public psc: string | null = null
  private provedor: string | null = null

  constructor(private route: ActivatedRoute, private servico:DocumentosService) {
   
  }
  ngOnInit(): void {
    this.token = sessionStorage.getItem('token')
    //this.id_token = sessionStorage.getItem('id_token')
    this.psc = sessionStorage.getItem('psc')
    if (this.token) {
      this.logou = true
      this.exibirTokens()
    } else {
      this.exibirErro(new Error("Não foi possível recuperar os tokens!"))
      this.logou = false
    }
  }
  
  exibirTokens() {
    this.token_decode = this.servico.decodificaToken(this.token)
    // if (this.token_decode !=  'undefined') {
    //   this.psc_access_token_decode = this.servico.decodificaToken(this.token_decode.access_token)  
    // }
  }

  async exibirErro(err:any) {
    console.log(err)
  }
}


