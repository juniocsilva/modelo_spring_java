import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { DscHeaderComponent } from 'sidsc-components/dsc-header';
import { CommonModule } from '@angular/common';
import { RouterOutlet, provideRouter } from '@angular/router';
import { routes } from './app.routes';

import { DscSidenavComponent } from 'sidsc-components/dsc-sidenav';
import { DscButtonComponent } from 'sidsc-components/dsc-button'
import { DscCardComponent } from 'sidsc-components/dsc-card'
import { LoginComponent } from './login/login.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import { BtSignInGovbrComponent } from './shared/bt-sign-in-govbr/bt-sign-in-govbr.component';
import { MenuBarComponent } from './shared/menu-bar/menu-bar.component';

import {NoopAnimationsModule} from '@angular/platform-browser/animations';

import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import { DscCheckboxComponent } from 'sidsc-components/dsc-checkbox';
import { OAuthModule, OAuthService, UrlHelperService } from 'angular-oauth2-oidc';
import { HttpClientModule } from '@angular/common/http';
import { DscDialogModule} from 'sidsc-components/dsc-dialog';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DscAlertComponent } from 'sidsc-components/dsc-alert';
import { DocumentosComponent } from './documentos/documentos.component';
import { CallbackComponent } from './shared/callback/callback.component';
import { BtSignInPscComponent } from './shared/bt-sign-in-psc/bt-sign-in-psc.component';
import { DscInputComponent } from 'sidsc-components/dsc-input'
import { SharedModule } from './shared/shared-module';
import { DscSelectComponent } from 'sidsc-components/dsc-select';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    BtSignInGovbrComponent,
    BtSignInPscComponent,
    MenuBarComponent,
    DocumentosComponent,
    CallbackComponent,
  ],
  imports: [
    BrowserModule,
    NoopAnimationsModule,
    MatFormFieldModule,
    RouterOutlet,
    CommonModule,
    DscHeaderComponent,
    DscSidenavComponent,
    DscButtonComponent,
    DscInputComponent,
    DscSelectComponent,
    DscCardComponent,
    MatGridListModule,
    MatIconModule,
    DscCheckboxComponent,
    DscDialogModule,
    DscAlertComponent,
    MatDialogModule,
    SharedModule,
    OAuthModule.forRoot(),
    HttpClientModule
  ],
  providers: [
    provideRouter(routes)
  ],
  bootstrap: [AppComponent]
})
export class AppModule{

}
