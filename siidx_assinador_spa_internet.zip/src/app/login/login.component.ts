import { Component } from '@angular/core';
import { DscCardData } from 'sidsc-components/dsc-card';
import { BasePage } from '../shared/page/BasePage';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent extends BasePage {
  
}
