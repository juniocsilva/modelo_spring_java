import {Routes} from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DocumentosComponent } from './documentos/documentos.component';
import { CallbackComponent } from './shared/callback/callback.component';

export const routes = [
    {path: '', component: LoginComponent},
    {path: 'documentos', component: DocumentosComponent},
    {path: 'callback', component: CallbackComponent}
];

