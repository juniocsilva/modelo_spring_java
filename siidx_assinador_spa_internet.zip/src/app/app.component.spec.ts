import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { OAuthModule } from 'angular-oauth2-oidc';
import { provideHttpClient } from '@angular/common/http';
import { AppModule } from './app.module';

describe('AppComponent', () => {
  beforeEach(() => TestBed.configureTestingModule({

    declarations: [AppComponent],
    imports: [AppModule],
    providers: [
      provideHttpClient()
   ]

  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });


});
