# Demonstração de Template

Demonstração de Template

## Introdução

Comece a escrever sua documentação adicionando mais arquivos markdown (.md) a esta pasta (/docs) ou substitua o conteúdo deste arquivo.

## Tabela de Conteúdos

A Tabela de Conteúdos à direita é gerada automaticamente com base na hierarquia
de títulos. Use apenas um H1 (`#` no Markdown) por arquivo.

## Navegação do Site

Para que novas páginas apareçam na navegação à esquerda, é necessário editar o arquivo `mkdocs.yml` na raiz do seu repositório. A navegação também pode incluir links para outros sites.

Alternativamente, se não houver uma seção `nav` no arquivo `mkdocs.yml`, uma seção de navegação será criada para você. No entanto, você não poderá usar títulos alternativos para páginas ou incluir links para outros sites.

Observe que o MkDocs usa `mkdocs.yml`, não `mkdocs.yaml`, embora ambos funcionem. Consulte também <https://www.mkdocs.org/user-guide/configuration/>.
