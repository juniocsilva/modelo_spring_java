# Hackathon – Simulador de Crédito (Spring Boot + SQL Server em Docker)

Projeto de referência para simulação de crédito com **Spring Boot 3**, **SQL Server (Azure SQL Edge)** em **Docker**, persistência das simulações (com parcelas) e consultas de estatísticas, incluindo uma telemetria simples **em memória** (para Hackathon).

> ⚠️ Em produção, prefira **Micrometer + Prometheus + Grafana** para métricas/telemetria. Aqui deixamos **in-memory** por simplicidade (ver seção [Telemetria (in-memory)](#telemetria-in-memory)).

---

## Sumário

1. [Stack](#stack)
2. [Pré-requisitos](#pré-requisitos)
3. [Subindo com Docker Compose](#subindo-com-docker-compose)
4. [Configuração do Spring (profile `hack`)](#profile-utilizada-hack)
5. [Esquema do Banco & Scripts](#esquema-do-banco--scripts)
6. [Endpoints](#endpoints)
7. [Exemplos de uso (curl)](#exemplos-de-uso-curl)
8. [Uso do Insomnia](#uso-do-insomnia)
9. [Telemetria (in-memory)](#telemetria-in-memory)
10. [Dicas & Troubleshooting](#dicas--troubleshooting)
11. [Contato](#contato)
12. [Licença](#licença)

---

## Stack

- **Java 21** / **Spring Boot 3.4**
- **Spring Data JPA** (Hibernate)
- **SQL Server** (imagem `mcr.microsoft.com/azure-sql-edge`)
- **Docker / Docker Compose**
- **Lombok**, **Validation** etc.

---

## Pré-requisitos

- Docker Desktop (ou Docker Engine) instalado
- (Opcional) Maven 3.9+ e JDK 17+ se for rodar localmente fora do container
- Porta **14333** livre no host (mapeada para 1433 no container do SQL)
- Porta **8080** livre para a API

---

## Subindo com Docker Compose

### 1) `docker-compose.yml`

Este arquivo está na raiz do projeto.


### 2) Dockerfile

O Dockerfile está na raiz do projeto.


> **Importante:** garanta que seus `.properties` estejam em **UTF-8 (sem BOM)** e **sem comentários na mesma linha** de valores boolean (ex.: `spring.sql.init.continue-on-error=true` – sem comentários no final).

### 3) Subir

```bash
docker compose build --no-cache
docker compose up -d
```

A API deve ficar acessível em:  
**http://localhost:8080**

---
## Esquema do Banco & Scripts

Utilize o script abaixo para criar a estrutura e carga inicial da tabela Produtos no banco de dados do container mssql-hack. Este script está localizado na pasta setup. 

- `init-hack.sql`

Sugerimos o uso do client DBeaver para executar o script. Os dados para registro do banco no DBeaver são:

URL: jdbc:sqlserver://localhost:14333;serverName=localhost;databaseName=master
usuario: sa
Senha: H@ck2025

---

## Profile utilizada: `hack`

`src/main/resources/application-hack.properties`:

```properties
server.port=8080
server.address=0.0.0.0

#spring.datasource.url=jdbc:sqlserver://localhost:14333;encrypt=false;databaseName=hack
spring.datasource.url=jdbc:sqlserver://mssql-hack:1433;encrypt=false;databaseName=hack
spring.datasource.username=hack
spring.datasource.password=Password23
spring.datasource.driver-class-name=com.microsoft.sqlserver.jdbc.SQLServerDriver

spring.jpa.database-platform=org.hibernate.dialect.SQLServerDialect
spring.jpa.hibernate.ddl-auto=none
spring.jpa.show-sql=true

# se quiser rodar scripts no startup (opcional)
spring.sql.init.mode=never

#EVENTHUB
eh.string.conexao=Endpoint=sb://eventhack.servicebus.windows.net/;SharedAccessKeyName=hack;SharedAccessKey=HeHeVaVqyVkntO2FnjQcs2Ilh/4MUDo4y+AEhKp8z+g=;EntityPath=simulacoes

#HEALTHCHECK
# expõe /actuator/health (e /actuator/health/readiness, /actuator/health/liveness)
management.endpoints.web.exposure.include=health,info
management.endpoint.health.probes.enabled=true

# inclui checagem de DB no health
management.health.db.enabled=true

# se quiser separar porta de mgmt (opcional)
# management.server.port=8081
```

> Se quiser rodar localmente (sem Docker), use `localhost:14333` na URL.

---

## Endpoints

Base URL: `http://localhost:8080`

### 1) **Produtos**

- `GET /api/produto`  
  Lista todos os produtos.

- `GET /api/produto/{codigo}`  
  Produto por código.

### 2) **Simulação**

- `POST /api/simulacao/simular`  
  Calcula SAC e PRICE e **persiste** a simulação completa (resultados + parcelas).

  **Body (exemplo)**:
  ```json
  {
    "valorDesejado": 900.00,
    "prazo": 5
  }
  ```

  **Resposta (exemplo)**:
  ```json resumido
  {
    "idSimulacao": 1755993173936,
    "codigoProduto": 1,
    "descricaoProduto": "Produto 1",
    "taxaJuros": 0.0179,
    "resultadoSimulacao": [
      {
        "tipo": "SAC",
        "parcelas": [
          { "numero": 1, "valorAmortizacao": "180.00", "valorJuros": "16.11", "valorPrestacao": "196.11" }
        ]
      },
      {
        "tipo": "PRICE",
        "parcelas": [
          { "numero": 1, "valorAmortizacao": "173.67", "valorJuros": "16.11", "valorPrestacao": "189.78" }
        ]
      }
    ]
  }
  ```

- `GET /api/simulacao/{id}`  
  Retorna **todos os dados** de uma simulação (inclui resultados e parcelas).

### 3) **Estatísticas (listagem paginada)**

- `GET /api/simulacoes/estatisticas?pagina=1&tamanho=200&ordenarPor=idSimulacao&direcao=desc`  
  **Saída:**
  ```json
  {
    "pagina": 1,
    "qtdRegistros": 404,
    "qtdRegistrosPagina": 200,
    "registros": [
      {
        "idSimulacao": 20180702,
        "valorDesejado": 900.00,
        "prazo": 5,
        "valorTotalParcelas": 1243.28
      }
    ]
  }
  ```

> **Observação:** `valorDesejado` é o **pedido original** (coluna `SIMULACAO.VALOR_DESEJADO`). `valorTotalParcelas` é a **soma** das prestações do resultado escolhido (preferência pelo PRICE).

### 4) **Estatísticas por dia (agregadas)**

- `GET /api/simulacoes/por-dia?data=2025-08-24&tz=America/Sao_Paulo`

  **Saída:**
  ```json
  {
    "dataReferencia": "2025-08-24",
    "simulacoes": [{
      "codigoProduto": 1,
      "descricaoProduto": "Produto 1",
      "taxaMediaJuro": 0.0189,
      "valorMedioPrestacao": 300.00,
      "valorTotalDesejado": 12047.47,
      "valorTotalCredito": 16750.00
    }]
  }
  ```

  - `data` é a data **local** da sua timezone.
  - `tz` (opcional) define a timezone (default geralmente `America/Sao_Paulo`). Internamente convertemos para **UTC** (coluna `CRIADO_EM` é UTC).
  - **valorTotalCredito** = **soma** das **parcelas** (`SUM(p.VALOR_PRESTACAO)`) do período/agrupamento; **valorMedioPrestacao** = `AVG(p.VALOR_PRESTACAO)`.



### 5) **Telemetria (in-memory)**

- `GET /api/telemetria/simulacoes`

- Há um **Aspecto AOP** que mede tempo, contagem e sucesso/erro (por endpoint), armazenando **em memória**.
- Exemplo de saída (JSON):
  ```json
  {
	"dataReferencia": "2025-08-25",
	"listaEndpoints": [
		{
			"nomeApi": "Consultar produto pelo código",
			"qtdRequisicoes": 1,
			"tempoMedio": 26,
			"tempoMinimo": 26,
			"tempoMaximo": 26,
			"percentualSucesso": 1.00
		},
		{
			"nomeApi": "Consultar simulação pelo código",
			"qtdRequisicoes": 2,
			"tempoMedio": 16,
			"tempoMinimo": 11,
			"tempoMaximo": 21,
			"percentualSucesso": 1.00
		},
		{
			"nomeApi": "Consultar todos os produtos",
			"qtdRequisicoes": 1,
			"tempoMedio": 206,
			"tempoMinimo": 206,
			"tempoMaximo": 206,
			"percentualSucesso": 1.00
		},
		{
			"nomeApi": "Fazer simulação",
			"qtdRequisicoes": 5,
			"tempoMedio": 222,
			"tempoMinimo": 76,
			"tempoMaximo": 700,
			"percentualSucesso": 1.00
		},
		{
			"nomeApi": "Listar Todas as Simulações",
			"qtdRequisicoes": 1,
			"tempoMedio": 40,
			"tempoMinimo": 40,
			"tempoMaximo": 40,
			"percentualSucesso": 1.00
		},
		{
			"nomeApi": "Simulações por dia/produto",
			"qtdRequisicoes": 1,
			"tempoMedio": 56,
			"tempoMinimo": 56,
			"tempoMaximo": 56,
			"percentualSucesso": 1.00
		}
	]
  }
  ```
 **Aviso**: somente para Hackathon/demonstração. Em produção, utilize **Micrometer + Prometheus + Grafana**.

---
## Exemplos de uso (curl)

```bash
# Listar produtos
curl -s http://localhost:8080/api/produto | jq

# Buscar produto 1
curl -s http://localhost:8080/api/produto/1 | jq

# Simular (ex.: R$ 900 em 5 meses)
curl -s -X POST http://localhost:8080/api/simulacao/simular   -H "Content-Type: application/json"   -d '{"valorDesejado":900,"prazo":5}' | jq

# Estatística paginada
curl -s "http://localhost:8080/api/simulacoes/estatisticas?pagina=1&tamanho=200" | jq

# Por dia (agregado)
curl -s "http://localhost:8080/api/simulacoes/por-dia?data=2025-08-24&tz=America/Sao_Paulo" | jq

# Simulação por id
curl -s http://localhost:8080/api/simulacao/1756047700303 | jq

# Telemetria
curl -s http://localhost:8080/api/telemetria/simulacoes | jq

```

---
## Uso do Insomnia
Foi disponibilizado o arquivo Insomnia-Hackathon.yaml na pasta setup para ser importado no Insomnia, para permitir o teste de todos os endpoints disponibilizados no projeto.
---

## Dicas & Troubleshooting

- **Portas ocupadas**  
  Verifique se 14333 (SQL) e 8080 (API) não estão em uso.

- **“Failed to configure a DataSource: 'url' not specified / suitable driver class”**  
  Confirme o profile `hack` ativo e as propriedades em `application-hack.properties`.  
  No container, o host do SQL é **`mssql-hack`** (nome do serviço), não `localhost`.

- **Banco ‘hack’ não existe no DBeaver**  
  Crie manualmente:
  ```script
  Use o script init-hack.sql localizado na pasta setup no .zip disponibilizado.
  ```
  Em seguida, (uma vez) crie o usuário `hack` e conceda permissões (ver [Esquema do Banco & Scripts](#esquema-do-banco--scripts)).

- **Sem `sqlcmd` no container do SQL**  
  A imagem `azure-sql-edge` não traz as tools por padrão. Use DBeaver/ADS no host **ou** suba um container `mcr.microsoft.com/mssql-tools` temporário e aponte para `host.docker.internal,14333` passando `-Q "..."`.

- **Healthcheck do SQL**  
  Usamos um **TCP check** simples (`/dev/tcp`). Serve para orquestrar `depends_on: service_healthy`.

- **Conectar localmente vs. via container**  
  - Local (IDE): `jdbc:sqlserver://localhost:14333;encrypt=false;databaseName=hack`
  - Dentro do container: `jdbc:sqlserver://mssql-hack:1433;encrypt=false;databaseName=hack`

- **Limpar/Recriar tudo**
  ```bash
  docker compose down -v
  docker compose build --no-cache
  docker compose up -d 
  ```
  Usar o script init-hack.sql (pasta setup) para recriar o banco.
---
## Contato
Se houver alguma dúvida entre em contato pelo teams/email Júnio César (C025788), ou pelo celular (62) 98417-1850.

## Licença

Uso educacional/demonstração (Hackathon).
