package com.example.app.domain.repository;

import com.example.app.domain.model.SimulacaoParcelaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SimulacaoParcelaRepository extends JpaRepository<SimulacaoParcelaEntity, Long> {

    @Query("""
        select p
        from SimulacaoParcelaEntity p
        where p.resultado.id in :resultadoIds
        order by p.numero
    """)
    List<SimulacaoParcelaEntity> preloadByResultadoIds(@Param("resultadoIds") List<Long> resultadoIds);
}

