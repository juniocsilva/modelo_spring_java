// src/main/java/com/example/app/application/service/TelemetriaService.java
package com.example.app.application.service;

import com.example.app.application.dto.EndpointTelemetriaDTO;
import com.example.app.application.dto.TelemetriaResponseDTO;
import com.example.app.telemetria.ApiRegistroTelemetria;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TelemetriaService {

    private static final ZoneId ZONE = ZoneId.of("America/Sao_Paulo");
    private final ApiRegistroTelemetria registry;

    /** Retorna a telemetria de TODOS os endpoints anotados que já receberam ao menos uma chamada */
    public TelemetriaResponseDTO obterTelemetria() {
        List<EndpointTelemetriaDTO> endpoints = Arrays.stream(registry.snapshotAll())
                .map(snap -> EndpointTelemetriaDTO.builder()
                        .nomeApi(snap.nomeApi())
                        .qtdRequisicoes(snap.qtdRequisicoes())
                        .tempoMedio(snap.tempoMedioMs())
                        .tempoMinimo(snap.tempoMinimoMs())
                        .tempoMaximo(snap.tempoMaximoMs())
                        .percentualSucesso(snap.percentualSucesso())
                        .build())
                .toList();

        return TelemetriaResponseDTO.builder()
                .dataReferencia(LocalDate.now(ZONE))
                .listaEndpoints(endpoints)
                .build();
    }
}
