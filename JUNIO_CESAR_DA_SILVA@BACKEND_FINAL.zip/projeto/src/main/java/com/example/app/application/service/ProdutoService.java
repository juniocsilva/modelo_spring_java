package com.example.app.application.service;

import com.example.app.application.dto.ProdutoDTO;
import com.example.app.application.exception.ProdutoNaoEncontradoException;
import com.example.app.domain.model.ProdutoEntity;
import com.example.app.domain.repository.ProdutoRepository;
import com.example.app.mapper.SimulacaoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProdutoService {
	
	private static final String MSG_PRODUTO_EM_USO = "Produto de código %d não pode ser removido, pois está em uso";

	private static final String MSG_PRODUTO_NAO_ENCONTRADO = "Não existe um cadastro de produto com código %d";

	@Autowired
	ProdutoRepository produtoRepository;

	@Autowired
	private SimulacaoMapper modelMapper;

	public List<ProdutoDTO> getTodosProdutos() {
		return produtoRepository.findAll()
				.stream()
				.map(produto -> modelMapper.toDto(produto))
				.collect(Collectors.toList());
	}

	public ProdutoDTO buscarPorId(Integer id) {
		
			ProdutoEntity produto =  produtoRepository.findById(id)
					.orElseThrow(() -> new ProdutoNaoEncontradoException(
							String.format(MSG_PRODUTO_NAO_ENCONTRADO, id)));	
			ProdutoDTO produtoDTO = modelMapper.toDto(produto);
			return produtoDTO;
	}

}
