package com.example.app.application.service;

import com.example.app.application.dto.*;
import com.example.app.application.exception.EntidadeNaoEncontradaException;
import com.example.app.application.exception.NegocioException;
import com.example.app.domain.model.*;
import com.example.app.domain.repository.ProdutoRepository;
import com.example.app.domain.repository.SimulacaoParcelaRepository;
import com.example.app.domain.repository.SimulacaoRepository;
import com.example.app.mapper.SimulacaoMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode; // <-- adicionado
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class SimulacaoService {

    private final ProdutoRepository produtoRepo;
    private final SimulacaoCalculadora calc;
    private final SimulacaoMapper mapper;
    private final SimulacaoRepository simulacaoRepo;
    private final SimulacaoParcelaRepository parcelaRepo;
    private final EventHubProducerService eventHubProducerService;
    @Transactional
    public SimulacaoResponseDTO simular(SimulacaoRequestDTO req) {
        var valor = req.getValorDesejado();
        var prazo = req.getPrazo();

        var produto = produtoRepo.findMatch(valor, prazo)
                .orElseThrow(() -> new NegocioException(
                        "Não existem produtos que atendam ao prazo e valor informados."));

        var p = new Parametros(
                produto.getTaxaJuros(),
                produto.getCodigo(),
                produto.getNome()
        );

        TabelaAmortizacao sac   = calc.calculaSAC(valor, prazo, p.pcTaxaJuros());
        TabelaAmortizacao price = calc.calculaPRICE(valor, prazo, p.pcTaxaJuros());

        Long id = System.currentTimeMillis();
        var resp = mapper.toResponse(id, p, sac, price);

        log.info("Simulação ok. produto={}, taxa={}, valor={}, prazo={}",
                p.codigoProduto(), p.pcTaxaJuros(), valor, prazo);

        //PERSISTE SIMULAÇÃO
        salvarSimulacaoCompleta(resp, req);
        //GRAVA NO EVENTHUB
        eventHubProducerService.grava(resp);
        return resp;
    }

    // inclui valorDesejado e prazo na raiz
    private void salvarSimulacaoCompleta(SimulacaoResponseDTO resp, SimulacaoRequestDTO req) {
        var sim = SimulacaoEntity.builder()
                .idSimulacao(resp.getIdSimulacao())
                .codigoProduto(resp.getCodigoProduto())
                .descricaoProduto(resp.getDescricaoProduto())
                .taxaJuros(resp.getTaxaJuros())
                .valorDesejado(req.getValorDesejado())   // se estiver passando req
                .prazo(req.getPrazo())
                .build();
        // garantia extra (mesmo com @Builder.Default)
        if (sim.getResultados() == null) sim.setResultados(new ArrayList<>());

        if (resp.getResultadoSimulacao() != null) {
            for (TabelaAmortizacaoDTO tab : resp.getResultadoSimulacao()) {
                var res = SimulacaoResultadoEntity.builder()
                        .simulacao(sim)
                        .tipo(tab.getTipo())
                        .build();

                if (tab.getParcelas() != null) {
                    for (ParcelaDTO par : tab.getParcelas()) {
                        var parc = SimulacaoParcelaEntity.builder()
                                .numero(par.getNumero())
                                .valorAmortizacao(toBD(par.getValorAmortizacao()))
                                .valorJuros(toBD(par.getValorJuros()))
                                .valorPrestacao(toBD(par.getValorPrestacao()))
                                .build();
                        res.addParcela(parc); // helper com null-guard
                    }
                }

                sim.addResultado(res); // helper com null-guard
            }
        }

        simulacaoRepo.save(sim); // cascade ALL persiste os filhos
        log.info("Simulação {} persistida com {} resultados.",
                sim.getIdSimulacao(),
                sim.getResultados() == null ? 0 : sim.getResultados().size());
    }

    // ===== helpers =====

    private static BigDecimal toBD(Object v) {
        if (v == null) return BigDecimal.ZERO;
        if (v instanceof BigDecimal bd) return bd;
        return new BigDecimal(v.toString());
    }

    private Optional<BigDecimal> calcularTotalParcelas(SimulacaoResponseDTO response) {
        if (response.getResultadoSimulacao() == null || response.getResultadoSimulacao().isEmpty()) {
            return Optional.empty();
        }
        Optional<TabelaAmortizacaoDTO> price = response.getResultadoSimulacao().stream()
                .filter(t -> t.getTipo() == TipoTabela.PRICE)
                .findFirst();
        if (price.isPresent()) {
            return Optional.of(somarPrestacoes(price.get()));
        }
        TabelaAmortizacaoDTO primeira = response.getResultadoSimulacao().stream()
                .min(Comparator.comparing(t -> t.getTipo().name()))
                .orElse(response.getResultadoSimulacao().get(0));
        return Optional.of(somarPrestacoes(primeira));
    }

    private BigDecimal somarPrestacoes(TabelaAmortizacaoDTO tabela) {
        if (tabela.getParcelas() == null || tabela.getParcelas().isEmpty()) {
            return BigDecimal.ZERO;
        }
        return tabela.getParcelas().stream()
                .map(ParcelaDTO::getValorPrestacao)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    @Transactional(readOnly = true)
    public SimulacaoResponseDTO obterDetalhe(Long idSimulacao) {
        SimulacaoEntity s = simulacaoRepo.findWithResultados(idSimulacao)
                .orElseThrow(() -> new EntidadeNaoEncontradaException("Simulação não encontrada: " + idSimulacao));

        // 2º passo: carrega TODAS as parcelas dos resultados desta simulação em uma query
        List<Long> ids = s.getResultados().stream()
                .map(SimulacaoResultadoEntity::getIdResultado)
                .toList();
        parcelaRepo.preloadByResultadoIds(ids); // popula o 1º nível de cache; não precisa iterar size()

        return mapper.toDto(s);
    }
}
