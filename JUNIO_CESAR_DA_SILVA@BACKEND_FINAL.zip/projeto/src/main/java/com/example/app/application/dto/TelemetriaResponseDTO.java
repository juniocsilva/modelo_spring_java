package com.example.app.application.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Singular;
import lombok.Value;

import java.time.LocalDate;
import java.util.List;

@Value
@Builder
public class TelemetriaResponseDTO {
    @JsonProperty("dataReferencia")
    @JsonFormat(shape = JsonFormat.Shape.STRING) // "YYYY-MM-DD"
    LocalDate dataReferencia;

    @Singular("endpoint")
    @JsonProperty("listaEndpoints")
    List<EndpointTelemetriaDTO> listaEndpoints;
}

