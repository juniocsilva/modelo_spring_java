package com.example.app.application.dto;

import lombok.*;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EstatisticaPageDTO {
    private int pagina;                // 1-based
    private long qtdRegistros;         // total no banco
    private int qtdRegistrosPagina;    // elementos retornados nesta página
    private List<EstatRegistroDTO> registros;
}

