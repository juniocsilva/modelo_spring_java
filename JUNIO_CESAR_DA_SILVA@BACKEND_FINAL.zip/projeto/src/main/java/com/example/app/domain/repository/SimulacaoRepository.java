// src/main/java/com/example/app/domain/repository/SimulacaoRepository.java
package com.example.app.domain.repository;

import com.example.app.domain.model.SimulacaoEntity;
import com.example.app.domain.repository.projection.SimulacaoProdutoDiaProjection;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface SimulacaoRepository extends JpaRepository<SimulacaoEntity, Long> {

    @Query(value = """
        WITH s AS (
            SELECT ID_SIMULACAO, CODIGO_PRODUTO, DESCRICAO_PRODUTO, TAXA_JUROS, VALOR_DESEJADO, CRIADO_EM
            FROM dbo.SIMULACAO
            WHERE CRIADO_EM >= :inicio AND CRIADO_EM < :fim
        ),
        x AS (
            SELECT 
                CODIGO_PRODUTO,
                DESCRICAO_PRODUTO,
                AVG(TAXA_JUROS)     AS taxa_media_juro,
                SUM(VALOR_DESEJADO) AS valor_total_desejado
            FROM s
            GROUP BY CODIGO_PRODUTO, DESCRICAO_PRODUTO
        ),
        y AS (
            SELECT 
                s.CODIGO_PRODUTO,
                s.DESCRICAO_PRODUTO,
                AVG(p.VALOR_PRESTACAO) AS valor_medio_prestacao,
                SUM(p.VALOR_PRESTACAO) AS valor_total_credito
                -- ^ se quiser "somente principal", troque por: SUM(p.VALOR_AMORTIZACAO)
            FROM s
            CROSS APPLY (
                SELECT TOP (1) r.ID_RESULTADO
                FROM dbo.SIMULACAO_RESULTADO r
                WHERE r.ID_SIMULACAO = s.ID_SIMULACAO
                ORDER BY CASE WHEN r.TIPO = 'PRICE' THEN 0 ELSE 1 END, r.TIPO
            ) esc
            JOIN dbo.SIMULACAO_PARCELA p ON p.ID_RESULTADO = esc.ID_RESULTADO
            GROUP BY s.CODIGO_PRODUTO, s.DESCRICAO_PRODUTO
        )
        SELECT 
            x.CODIGO_PRODUTO                        AS codigoProduto,
            x.DESCRICAO_PRODUTO                     AS descricaoProduto,
            x.taxa_media_juro                       AS taxaMediaJuro,
            COALESCE(y.valor_medio_prestacao, 0)    AS valorMedioPrestacao,
            x.valor_total_desejado                  AS valorTotalDesejado,
            COALESCE(y.valor_total_credito, 0)      AS valorTotalCredito
        FROM x
        LEFT JOIN y
          ON y.CODIGO_PRODUTO = x.CODIGO_PRODUTO
         AND y.DESCRICAO_PRODUTO = x.DESCRICAO_PRODUTO
        ORDER BY x.CODIGO_PRODUTO
        """, nativeQuery = true)
    List<SimulacaoProdutoDiaProjection> resumoPorDia(
            @Param("inicio") LocalDateTime inicio,
            @Param("fim")     LocalDateTime fim
    );

    @Query("""
    select distinct s
    from SimulacaoEntity s
    left join fetch s.resultados r
    where s.idSimulacao = :idSimulacao
    """)
    Optional<SimulacaoEntity> findDetailedByIdSimulacao(@Param("idSimulacao") Long idSimulacao);

    @Query("""
        select distinct s
        from SimulacaoEntity s
        left join fetch s.resultados r
        where s.idSimulacao = :id
    """)
    Optional<SimulacaoEntity> findWithResultados(@Param("id") Long id);
}
