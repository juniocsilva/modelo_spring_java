package com.example.app.application.dto;

import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SimulacoesDiaResponseDTO {
    private LocalDate dataReferencia;
    private List<SimulacaoProdutoDiaDTO> simulacoes;
}