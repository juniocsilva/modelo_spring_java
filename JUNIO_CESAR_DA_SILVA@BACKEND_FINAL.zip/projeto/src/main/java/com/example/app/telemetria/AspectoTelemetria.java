package com.example.app.telemetria;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;

import java.lang.reflect.Method;

@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AspectoTelemetria {

    private final ApiRegistroTelemetria registry;

    // Intercepta TODO método de @RestController ou @Controller
    @Around("(within(@org.springframework.web.bind.annotation.RestController *) " +
            "|| within(@org.springframework.stereotype.Controller *)) " +
            "&& !within(@org.springframework.web.bind.annotation.ControllerAdvice *))")
    public Object aroundAnyController(ProceedingJoinPoint pjp) throws Throwable {
        TrilhaTelemetria ann = findAnno(pjp);
        if (ann == null) {
            return pjp.proceed(); // não anotado => não mede
        }
        String name = ann.name() == null || ann.name().isBlank()
                ? defaultName(pjp)
                : ann.name();

        long start = System.nanoTime();
        boolean ok = false;
        try {
            Object out = pjp.proceed();
            ok = true;
            return out;
        } finally {
            long elapsed = System.nanoTime() - start;
            registry.record(name, elapsed, ok);
            if (log.isDebugEnabled()) {
                log.debug("telemetria: {} took {} ms (ok={})",
                        name, Math.round(elapsed / 1_000_000.0), ok);
            }
        }
    }

    private TrilhaTelemetria findAnno(ProceedingJoinPoint pjp) {
        MethodSignature sig = (MethodSignature) pjp.getSignature();
        Method m = sig.getMethod();

        // 1) anotação no método (proxy)
        TrilhaTelemetria ann = AnnotationUtils.findAnnotation(m, TrilhaTelemetria.class);
        if (ann != null) return ann;

        // 2) método real da classe concreta
        try {
            Method targetMethod = pjp.getTarget()
                    .getClass()
                    .getMethod(m.getName(), m.getParameterTypes());
            ann = AnnotationUtils.findAnnotation(targetMethod, TrilhaTelemetria.class);
            if (ann != null) return ann;
        } catch (NoSuchMethodException ignored) {}

        // 3) anotação na CLASSE (controller inteiro)
        ann = AnnotationUtils.findAnnotation(pjp.getTarget().getClass(), TrilhaTelemetria.class);
        return ann;
    }

    private String defaultName(ProceedingJoinPoint pjp) {
        MethodSignature sig = (MethodSignature) pjp.getSignature();
        return sig.getDeclaringType().getSimpleName() + "#" + sig.getName();
    }
}
