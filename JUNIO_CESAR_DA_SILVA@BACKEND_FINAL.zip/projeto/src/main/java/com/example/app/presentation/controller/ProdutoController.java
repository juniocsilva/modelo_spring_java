package com.example.app.presentation.controller;

import com.example.app.application.dto.Groups;
import com.example.app.application.dto.ProdutoDTO;
import com.example.app.application.dto.SimulacaoRequestDTO;
import com.example.app.application.dto.SimulacaoResponseDTO;
import com.example.app.application.service.ProdutoService;
import com.example.app.application.service.SimulacaoService;
import com.example.app.telemetria.TrilhaTelemetria;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.util.ReflectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/produto")
public class ProdutoController {
	
	@Autowired
	private ProdutoService produtoService;

	@TrilhaTelemetria(name = "Consultar todos os produtos")
	@GetMapping
	public ResponseEntity<List<ProdutoDTO>> getProduto() {

		return ResponseEntity.ok(produtoService.getTodosProdutos());
	}

	@TrilhaTelemetria(name = "Consultar produto pelo código")
	@GetMapping("/{id}")
	public ProdutoDTO buscar(@PathVariable Integer id) {
		
			return produtoService.buscarPorId(id);
			
	}


}
