package com.example.app.application.dto;

import com.example.app.domain.model.TipoTabela;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

import java.util.List;

import static com.fasterxml.jackson.annotation.JsonProperty.Access.READ_ONLY;

@Value @Builder
public class TabelaAmortizacaoDTO {
    @JsonProperty("tipo")
    TipoTabela tipo;
    @Singular("parcela")
    @JsonProperty("parcelas") List<ParcelaDTO> parcelas;
}
