package com.example.app.domain.model;

import java.math.BigDecimal;

public record Parametros(
        BigDecimal pcTaxaJuros, // fração por período (ex.: 0.02)
        Integer codigoProduto,
        String descricaoProduto
) {}



