package com.example.app.domain.model;

import java.math.BigDecimal;

public record Parcela(
        int numero,
        BigDecimal valorAmortizacao,
        BigDecimal valorJuros,
        BigDecimal valorPrestacao
) {}

