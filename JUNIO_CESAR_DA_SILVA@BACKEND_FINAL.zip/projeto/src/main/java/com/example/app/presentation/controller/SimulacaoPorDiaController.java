// src/main/java/com/example/app/presentation/controller/SimulacaoPorDiaController.java
package com.example.app.presentation.controller;

import com.example.app.application.dto.SimulacoesDiaResponseDTO;
import com.example.app.application.service.SimulacaoPorDiaService;
import com.example.app.telemetria.TrilhaTelemetria;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.ZoneId;

@RestController
@RequestMapping("/api/simulacoes")
@RequiredArgsConstructor
public class SimulacaoPorDiaController {

    private final SimulacaoPorDiaService service;

    @GetMapping("/por-dia")
    @TrilhaTelemetria(name = "Simulações por dia/produto")
    public SimulacoesDiaResponseDTO porDia(
            @RequestParam(name = "data", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data,
            @RequestParam(name = "tz", required = false, defaultValue = "America/Sao_Paulo") String tz
    ) {
        return service.listar(data, ZoneId.of(tz));
    }
}
