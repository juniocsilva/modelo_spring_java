// src/main/java/com/example/app/presentation/controller/SimulacaoConsultaController.java
package com.example.app.presentation.controller;

import com.example.app.application.dto.EstatisticaPageDTO;
import com.example.app.application.service.SimulacaoConsultaService;
import com.example.app.telemetria.TrilhaTelemetria;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/simulacoes")
@RequiredArgsConstructor
public class SimulacaoConsultaController {

    private final SimulacaoConsultaService consultaService;

    @GetMapping("/estatisticas")
    @Transactional(readOnly = true)
    @TrilhaTelemetria(name = "Listar Todas as Simulações")
    public EstatisticaPageDTO listar(
            @RequestParam(name = "pagina",  defaultValue = "1")   int pagina,    // 1-based
            @RequestParam(name = "tamanho", defaultValue = "200") int tamanho,   // page size
            @RequestParam(name = "ordenarPor", defaultValue = "idSimulacao") String ordenarPor,
            @RequestParam(name = "direcao",   defaultValue = "desc")             String direcao
    ) {
        return consultaService.listar(pagina, tamanho, ordenarPor, direcao);
    }
}
