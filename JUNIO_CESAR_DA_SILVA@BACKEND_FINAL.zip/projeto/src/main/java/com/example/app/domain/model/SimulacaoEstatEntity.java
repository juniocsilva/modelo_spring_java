package com.example.app.domain.model;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.domain.Persistable;

import java.math.BigDecimal;

@Entity
@Table(name = "SIMULACAO_ESTAT", schema = "dbo") // database (catalog) vem da URL
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SimulacaoEstatEntity implements Persistable<Long> {

    @Id
    @Column(name = "ID_SIMULACAO")
    private Long idSimulacao;

    @Column(name = "VALOR_DESEJADO", nullable = false, precision = 18, scale = 2)
    private BigDecimal valorDesejado;

    @Column(name = "PRAZO", nullable = false)
    private Integer prazo;

    @Column(name = "VALOR_TOTAL_PARCELAS", nullable = false, precision = 18, scale = 2)
    private BigDecimal valorTotalParcelas;

    // ---- Persistable<Long> ----
    @Transient
    @Builder.Default                // <--- IMPORTANTE: garante true ao usar builder()
    private boolean _isNew = true;

    @Override
    public Long getId() { return idSimulacao; }

    @Override
    public boolean isNew() { return _isNew; }

    @PostLoad
    @PostPersist
    void markNotNew() { this._isNew = false; }
}
