package com.example.app.domain.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "SIMULACAO_PARCELA", schema = "dbo")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class SimulacaoParcelaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_PARCELA")
    @EqualsAndHashCode.Include
    private Long idParcela;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ID_RESULTADO", nullable = false)
    private SimulacaoResultadoEntity resultado;

    @Column(name = "NUMERO", nullable = false)
    private Integer numero;

    @Column(name = "VALOR_AMORTIZACAO", nullable = false, precision = 18, scale = 2)
    private BigDecimal valorAmortizacao;

    @Column(name = "VALOR_JUROS", nullable = false, precision = 18, scale = 2)
    private BigDecimal valorJuros;

    @Column(name = "VALOR_PRESTACAO", nullable = false, precision = 18, scale = 2)
    private BigDecimal valorPrestacao;
}
