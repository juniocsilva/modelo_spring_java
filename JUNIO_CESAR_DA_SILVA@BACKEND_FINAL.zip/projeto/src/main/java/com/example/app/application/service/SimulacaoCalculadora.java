package com.example.app.application.service;


import com.example.app.domain.model.Parcela;
import com.example.app.domain.model.TabelaAmortizacao;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@Component
public class SimulacaoCalculadora {
    private static final RoundingMode RM = RoundingMode.HALF_UP;
    private static final MathContext MC = MathContext.DECIMAL64;

    public TabelaAmortizacao calculaSAC(BigDecimal valor, int prazo, BigDecimal juros) {
        List<Parcela> parcelas = new ArrayList<>(prazo);
        BigDecimal amort = valor.divide(BigDecimal.valueOf(prazo), 2, RM); // 2 casas
        BigDecimal saldo = valor;

        for (int i = 1; i <= prazo; i++) {
            BigDecimal j   = saldo.multiply(juros, MC);
            BigDecimal prest = amort.add(j, MC);
            saldo = saldo.subtract(amort, MC);

            parcelas.add(new Parcela(
                    i,
                    amort,                         // já 2 casas
                    j.setScale(2, RM),             // toFixed(2)
                    prest.setScale(2, RM)          // toFixed(2)
            ));
        }
        return new TabelaAmortizacao("SAC", parcelas);
    }

    public TabelaAmortizacao calculaPRICE(BigDecimal valor, int prazo, BigDecimal juros) {
        List<Parcela> parcelas = new ArrayList<>(prazo);
        BigDecimal a = BigDecimal.ONE.add(juros, MC).pow(prazo, MC);
        BigDecimal prest = valor.multiply(a.multiply(juros).divide(a.subtract(BigDecimal.ONE), MC), MC)
                .setScale(2, RM); // 2 casas

        BigDecimal saldo = valor;
        for (int i = 1; i <= prazo; i++) {
            BigDecimal j    = saldo.multiply(juros, MC);
            BigDecimal amort = prest.subtract(j, MC);
            saldo = saldo.subtract(amort, MC);

            parcelas.add(new Parcela(
                    i,
                    amort.setScale(2, RM),
                    j.setScale(2, RM),
                    prest // já 2 casas
            ));
        }
        return new TabelaAmortizacao("PRICE", parcelas);
    }
}


