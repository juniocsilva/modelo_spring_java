package com.example.app.mapper;

// com/example/simulacao/mapper/SimulacaoMapper.java



import com.example.app.application.dto.*;
import com.example.app.domain.model.*;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public class SimulacaoMapper {
    private static BigDecimal nvl(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }
    public SimulacaoResponseDTO toResponse(Long id, Parametros p, TabelaAmortizacao sac, TabelaAmortizacao price) {
        return SimulacaoResponseDTO.builder()
                .idSimulacao(id)
                .codigoProduto(p.codigoProduto())
                .descricaoProduto(p.descricaoProduto())
                .taxaJuros(p.pcTaxaJuros())
                .tabela(toTabelaDTO(sac))
                .tabela(toTabelaDTO(price))
                .build();
    }

    private TabelaAmortizacaoDTO toTabelaDTO(TabelaAmortizacao t) {
        TipoTabela tipo = "SAC".equalsIgnoreCase(t.tipo()) ? TipoTabela.SAC : TipoTabela.PRICE;
        return TabelaAmortizacaoDTO.builder()
                .tipo(tipo)
                .parcelas(toParcelaDTOs(t.parcelas()))
                .build();
    }

    private List<ParcelaDTO> toParcelaDTOs(List<Parcela> parcelas) {
        return parcelas.stream().map(this::toParcelaDTO).toList();
    }

    private ParcelaDTO toParcelaDTO(Parcela p) {
        return ParcelaDTO.builder()
                .numero(p.numero())
                .valorAmortizacao(p.valorAmortizacao())
                .valorJuros(p.valorJuros())
                .valorPrestacao(p.valorPrestacao())
                .build();
    }
    public ProdutoDTO toDto(ProdutoEntity e) {
        if (e == null) return null;

        return ProdutoDTO.builder()
                .codigoProduto(e.getCodigo())
                .descricaoProduto(e.getNome())
                .taxaJuros(e.getTaxaJuros())
                .valorMin(e.getValorMinimo())
                .valorMax(e.getValorMaximo())
                .prazoMin(e.getMinimoMeses() == null ? null : e.getMinimoMeses().intValue())
                .prazoMax(e.getMaximoMeses() == null ? null : e.getMaximoMeses().intValue())
                .build();
    }

    //SIMULACÕES
    // ---- mapper simples entity -> DTO de resposta ----
    public SimulacaoResponseDTO toDto(SimulacaoEntity s) {
        List<TabelaAmortizacaoDTO> tabs = s.getResultados().stream()
                .map(this::toTabelaDto)
                .toList();

        return SimulacaoResponseDTO.builder()
                .idSimulacao(s.getIdSimulacao())
                .codigoProduto(s.getCodigoProduto())
                .descricaoProduto(s.getDescricaoProduto())
                .taxaJuros(s.getTaxaJuros() == null ? BigDecimal.ZERO : s.getTaxaJuros())
                .resultadoSimulacao(tabs)
                .build();
    }

    public TabelaAmortizacaoDTO toTabelaDto(SimulacaoResultadoEntity r) {
        List<ParcelaDTO> parcelas = r.getParcelas().stream()
                .map(p -> ParcelaDTO.builder()
                        .numero(p.getNumero())
                        .valorAmortizacao(nvl(p.getValorAmortizacao()))
                        .valorJuros(nvl(p.getValorJuros()))
                        .valorPrestacao(nvl(p.getValorPrestacao()))
                        .build())
                .toList();

        return TabelaAmortizacaoDTO.builder()
                .tipo(r.getTipo()) // enum TipoTabela
                .parcelas(parcelas)
                .build();
    }
}

