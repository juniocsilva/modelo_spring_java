// SimulacaoPorDiaService.java
package com.example.app.application.service;

import com.example.app.application.dto.SimulacaoProdutoDiaDTO;
import com.example.app.application.dto.SimulacoesDiaResponseDTO;
import com.example.app.domain.repository.SimulacaoRepository;
import com.example.app.domain.repository.projection.SimulacaoProdutoDiaProjection;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.*;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SimulacaoPorDiaService {

    private final SimulacaoRepository simulacaoRepo;

    public SimulacoesDiaResponseDTO listar(LocalDate dataLocal, ZoneId zona) {
        ZoneId zone = (zona != null ? zona : ZoneId.of("America/Sao_Paulo"));

        // dia na zona local
        LocalDate dia = (dataLocal != null) ? dataLocal : LocalDate.now(zone);

        // converte o intervalo do dia local -> UTC
        ZonedDateTime zStart = dia.atStartOfDay(zone);
        ZonedDateTime zEnd   = zStart.plusDays(1);

        LocalDateTime inicioUtc = zStart.withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();
        LocalDateTime fimUtc    = zEnd.withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();

        List<SimulacaoProdutoDiaProjection> rows = simulacaoRepo.resumoPorDia(inicioUtc, fimUtc);

        List<SimulacaoProdutoDiaDTO> itens = rows.stream().map(r ->
                SimulacaoProdutoDiaDTO.builder()
                        .codigoProduto(r.getCodigoProduto())
                        .descricaoProduto(r.getDescricaoProduto())
                        .taxaMediaJuro(nvl(r.getTaxaMediaJuro()))
                        .valorMedioPrestacao(nvl(r.getValorMedioPrestacao()))
                        .valorTotalDesejado(nvl(r.getValorTotalDesejado()))
                        .valorTotalCredito(nvl(r.getValorTotalCredito()))
                        .build()
        ).toList();

        return SimulacoesDiaResponseDTO.builder()
                .dataReferencia(dia)   // dia local solicitado
                .simulacoes(itens)
                .build();
    }

    private static BigDecimal nvl(BigDecimal v) { return v == null ? BigDecimal.ZERO : v; }
}
